<?php

namespace App\Models;

use App\Models\SystemState;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SystemCountry extends Model
{
    use HasFactory;

    protected $table='system_countries';


    public function states()
    {
    	return $this->hasMany(SystemState::class,'country_id');
    }
}
