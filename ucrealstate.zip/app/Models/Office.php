<?php

namespace App\Models;

use App\Models\SystemCountry;
use App\Models\SystemState;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Office extends Model
{
    use HasFactory,SoftDeletes;


    protected $fillable=[
    	'name',
    	'country',
    	'state',
    	'city',
    	'unit',
    	'road_number',
    	'road_name',
    	'road_type',
    	'location',
    	'latitude',
        'longitude',
        'logo',
    	'created_by'
    ];
    public const LOGO='office_logo';
    
    public const ROAD_TYPE=['Road','Way','Street','Avenue','Boulevard','Lane','Drive','Terrace','Place','Court','Crescent','Plaza','Square','Bay','Trail','Mews'];  
    public $append=['address'];

    public function getAddressAttribute(){
        return $this->getcity->name.' '.$this->getstate->name.','.$this->getcountry->name;
    }


    public function getcountry()
    {
        return $this->belongsTo(SystemCountry::class,'country')->withDefault();
    }

    public function getstate()
    {
        return $this->belongsTo(SystemState::class,'state')->withDefault();
    }

    public function getcity()
    {
        return $this->belongsTo(SystemCity::class,'city')->withDefault();
    }
}
