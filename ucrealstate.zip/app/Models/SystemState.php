<?php

namespace App\Models;

use App\Models\SystemCity;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SystemState extends Model
{
    use HasFactory;

    protected $table='system_states';

    public function cities()
    {
    	return $this->hasMany(SystemCity::class,'state_id');
    }
}
