<?php

namespace App\Models;

use App\Models\User;
use Carbon\Carbon;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StoryBoard extends Model
{
    use HasFactory,Sluggable,SoftDeletes;

    protected $fillable=
    [
    	'property_name',
    	'property_address',
    	'property_address_line',
        'unit',
        'road_number',
        'road_name',
        'road_type',
        'city',
    	'property_price',
    	'about_property',
    	'property_image',
    	'year',
    	'square_feets',
    	'bedroom',
        'bathroom',
        'p_high_resolution',
        'p_lms',
    	'p_video_link',
        'p_pdf',
        'p_no_brand',
    	'p_floor_plan',
    	'p_metterport',
        'panorama',
        'p_room_name',
    	'location',
        'latitude',
        'longitude',
    	'walkable',
    	'transit',
    	'bikeable',
    	'status',
    	'user_id',
    	'created_by',
    	'slug',
        'theme_color',
        'show_about',
        'p_download_link',
        'p_video_iframe',
        'p_email',
        'v_email',
        'f_email',
        'm_email',
        'pa_email',
        'flickr_photo_set_id',
        'dropbox_url',
        'invoice',
        'favorite'
    ];

    public const ROAD_TYPE=['Road','Way','Street','Avenue','Boulevard','Lane','Drive','Terrace','Place','Court','Crescent','Plaza','Square','Bay','Trail','Mews'];

    public const CITYS=['Abbotsford','Burnaby','Coquitlam','Langley','Chilliwack','Delta','Surrey','Port Coquitlam','Maple Ridge','Mission','New Westminster','North Vancouver','Richmond','Vancouver','West Vancouver','White Rock'];

    public const ROOM_NAMES=['Balcony','Bar','Bathroom','Bedroom','Carport','Deck','Den','Dining room','Eating Area','Ensuite','Family room','Fitness Room','Flex Area','Foyer','Games Room','Home Theatre','Kitchen','Kitchen / Dining Room','Laundry','Living room','Living / Dining Room','Loft','Master Bedroom','Media Room','Ofiice','Patio','Pool','Porch','Powder','Rec Room','Sauna','Solarium','Terrace','Wet Bar','Wine Cellar','Wok Kitchen'];

    public const STORY_FILES='story_file';

    public $append=['story_board_status','created_at_format','property_address'];

    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => ['unit','road_number','road_name','road_type','city']
            ]
        ];
    }


    public function user()
    {
        return $this->belongsTo(User::class,'user_id');
    }

    public function bannerImages()
    {
        return $this->hasMany(BannerImage::class,'story_board_id','id');
    }

    public function boardGalleries()
    {
        return $this->hasMany(StoryBoardGallery::class,'story_board_id','id');
    }

    public function panoramas()
    {
        return $this->hasMany(StoryBoardPanorama::class,'story_board_id','id');
    }

    public function service(){
        return $this->hasOne(StoryBoardService::class,'story_board_id','id');
    }
    public function allServices(){
        return $this->hasMany(StoryBoardService::class,'story_board_id','id');
    }

    public function getStoryBoardStatusAttribute()
    {
        $status=$this->status;
        if ($status==1) {
            return '<span class="badge badge-primary">Completed</span>';
        }else{
            return '<span class="badge badge-danger">Incompleted</span>';
        }
    }


    public function getPropertyAddressAttribute()
    {
        $property_address="";
        if (isset($this->unit)) {
           $property_address.=$this->unit.' ';
        }
        if (isset($this->road_number)) {
            $property_address.=$this->road_number.' ';
        }

        if (isset($this->road_name)) {
            $property_address.=$this->road_name.' ';
        }

        if (isset($this->road_type)) {
            $property_address.=$this->road_type;
        }
        if (isset($this->city)) {
            $property_address.=', '.$this->city;
        }

        return $property_address;
    }

    public function getUpdatedAtFormatAttribute()
    {
        $updated=$this->updated_at;
        return Carbon::createFromFormat('Y-m-d H:i:s', $updated)->format('Y-m-d');
    }


}
