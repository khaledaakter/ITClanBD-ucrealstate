<?php

namespace App\Models;

use App\Traits\Scopes\AppUserGlobalScope;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasFactory, Notifiable,HasRoles,SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'display_name',
        'user_name',
        'phone',
        'team_name',
        'photo',
        'background_image',
        'office_id',
        'website',
        'facebook',
        'twitter',
        'linkdin',
        'email',
        'cc_email',
        'password',
        'user_type',
        'title',
        'remember_token',
        'instragram',
        'youtube',
        'logo',
        'location',
        'latitude',
        'longitude',
        'g_email',
        'note'
    ];

    public $append=['full_name','username'];

    public const USER_TYPE=[
        0=>'client',
        1=>'admin'
    ];

    public const GET_USER_TYPE=[
        'client'=>0,
        'admin'=>1
    ];

    public const PROFILE_IMAGE='user';
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function getFullNameAttribute()
    {
        return ucfirst($this->first_name).' '.$this->last_name;
    }

    public function office()
    {
        return $this->belongsTo(Office::class,'office_id')->withDefault();
    }

    public function storyBoards()
    {
        return $this->hasMany(StoryBoard::class,'user_id','id');
    }

    public function themeColors()
    {
        return $this->hasMany(ThemeColor::class,'user_id','id');
    }
}
