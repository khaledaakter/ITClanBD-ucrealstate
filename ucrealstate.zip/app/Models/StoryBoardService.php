<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StoryBoardService extends Model
{
    use HasFactory;

    protected $fillable=['story_board_id','client_id','service_p','service_v','service_f','service_m','service_pa'];
}
