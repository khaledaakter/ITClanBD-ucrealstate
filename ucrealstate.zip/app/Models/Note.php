<?php

namespace App\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Note extends Model
{
    use HasFactory,SoftDeletes;

    protected $fillable=['title','note','created_by'];

    public function user()
    {
    	return $this->hasOne(User::class,'id','created_by')->withTrashed();
    }

}
