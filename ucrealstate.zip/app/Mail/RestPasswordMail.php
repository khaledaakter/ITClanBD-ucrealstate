<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class RestPasswordMail extends Mailable
{
    use Queueable, SerializesModels;
    public $uu_id;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($uu_id=null)
    {
        $this->uu_id=$uu_id;
        $this->subject('Reset Password');
        $this->replyTo('info@itclanbd.com','Reset Password');
        $this->from('dev@itclanbd.com','Reset Password');
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('email.reset_password',['uuid'=>$this->uu_id]);
    }
}
