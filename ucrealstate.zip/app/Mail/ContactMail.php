<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ContactMail extends Mailable
{
    use Queueable, SerializesModels;
    public $name='';
    public $phone='';
    public $email='';
    public $message='';
    public $address='';
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($request_all)
    {
        // dd($request_all);
        $this->name     =$request_all['name'];
        $this->phone    =$request_all['phone_number'];
        $this->email    =$request_all['from_email'];
        $this->message  =$request_all['message'];
        $this->address  =$request_all['address'];
        $this->subject('Contact Mail');
        $this->replyTo('info@itclanbd.com', 'Contact Mail');
        $this->from('dev@itclanbd.com', 'Contact Mail');
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('email.contact_email')->with(['name'=>$this->name,'phone'=>$this->phone,'email'=>$this->email,'mess'=>$this->message,'address'=>$this->address]);
    }
}
