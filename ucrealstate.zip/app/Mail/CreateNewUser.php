<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class CreateNewUser extends Mailable
{
    use Queueable, SerializesModels;
    public $dispaly_name,$email,$password;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($dispaly_name=null, $email=null, $password=null)
    {
        $this->dispaly_name=$dispaly_name;
        $this->email=$email;
        $this->password=$password;
        $this->subject('Create New Client');
        $this->replyTo('info@itclanbd.com', 'Create New Client');
        $this->from('dev@itclanbd.com', 'Create New Client');
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('email.createNewUser',['display_name'=>$this->dispaly_name,'email'=>$this->email,'password'=>$this->password]);
    }
}
