<?php

namespace App\Services\StoryBoard;

use GuzzleHttp\Client;
use App\Models\StoryBoard;
use App\Models\BannerImage;
use Illuminate\Http\Request;
use App\Models\StoryBoardGallery;
use App\Models\StoryBoardService as StoryBoardServiceModel;
use App\Models\StoryBoardPanorama;
use Illuminate\Support\Facades\DB;
use App\Services\Utils\FileUploadService;

class StoryBoardService
{

	public function __construct(FileUploadService $fileUploadService)
	{
		$this->fileUploadService=$fileUploadService;
	}

	public function createOrUpdate(Request $request, $id=null)
	{
		DB::beginTransaction();
		try {

			$propertyImage='';
			$floorPlanImage='';
			$panorama='';
			$status=0;
			$p_video_iframe='';
			$service_board_array=[];

			if (isset($id) && $request->hasFile('property_image')) {
				$propertyImage=imageUploadHandler($request->file('property_image'),StoryBoard::STORY_FILES,'540x526');

			}elseif($request->hasFile('property_image')){
				$propertyImage=imageUploadHandler($request->file('property_image'),StoryBoard::STORY_FILES,'540x526');

			}elseif(isset($id)){
				$propertyImage=StoryBoard::whereId($id)->first()->property_image;

			}

			if (isset($id) && $request->hasFile('p_floor_plan')) {
				$floorPlanImage=$this->fileUploadService->uploadFile($request,'p_floor_plan',StoryBoard::STORY_FILES);
			}elseif($request->hasFile('p_floor_plan')){
				$floorPlanImage=$this->fileUploadService->uploadFile($request,'p_floor_plan',StoryBoard::STORY_FILES);
			}elseif(isset($id)){
				$floorPlanImage=StoryBoard::whereId($id)->first()->p_floor_plan;
			}


			if(($request['p_video_link']))
			{
				$p_video_iframe=$this->getViemoVideoLink($request['p_video_link']);
			}


		    $storyBoard=StoryBoard::updateOrCreate(['id'=>$id],[
		    	'unit'						=>$request['unit'],
		    	'road_number'				=>$request['road_number'],
		    	'road_name'					=>$request['road_name'],
		    	'road_type'					=>$request['road_type'],
		    	'city'						=>$request['city'],
		    	'show_about'				=>isset($request['show_about'])?1:0,
		    	'property_price'			=>$request['property_price'],
		    	'about_property'			=>$request['about_property'],
		    	'property_image'			=>$propertyImage,
		    	'year'						=>$request['year'],
		    	'square_feets'				=>$request['square_feets'],
		    	'bedroom'					=>$request['bedroom'],
		    	'bathroom'					=>$request['bathroom'],
		    	'p_video_link'				=>$request['p_video_link'],
		    	'p_video_iframe'			=>isset($p_video_iframe)?$p_video_iframe:null,
		    	'p_download_link'			=>$request['p_download_link'],
		    	'p_floor_plan'				=>$floorPlanImage,
		    	'p_metterport'				=>$request['p_metterport'],
		    	'location'					=>$request['location'],
		    	'latitude'					=>$request['latitude'],
		    	'longitude'					=>$request['longitude'],
		    	'theme_color'				=>$request['theme_color'],
		    	'user_id'					=>$request['user_id'],
		    	'created_by'				=>auth()->user()->id,
                'flickr_photo_set_id'       =>$request['flickr_photo_set_id'],
                'dropbox_url'               =>$request['dropbox_url']
		    ]);



		   if ($request->hasfile('banner_image')) {
		       $banner_images=$request->file('banner_image');
		       foreach ($banner_images as $banner_image)
		       {
		           BannerImage::create([
		            'image'=>imageUploadHandler($banner_image,StoryBoard::STORY_FILES,'1920x850'),
		            'story_board_id'=>$storyBoard->id
		           ]);
		       }
		   }


		   if ($request->hasfile('p_photo')) {
		       $gallery_images=$request->file('p_photo');
		       foreach ($gallery_images as $gallery_image)
		       {
		           StoryBoardGallery::create([
		            'image'=>imageUploadHandler($gallery_image,StoryBoard::STORY_FILES,'3000x2000'),
		            'story_board_id'=>$storyBoard->id
		           ]);
		       }
		   }

		   if ($request->hasfile('panorama')) {
		       $panorames=$request->file('panorama');
		       foreach ($panorames as $key=>$panorama)
		       {
		           StoryBoardPanorama::create([
		           	'p_room_name'=>$request['p_room_name'][$key],
		            'panorama_photo'=>imageUploadHandler($panorama,StoryBoard::STORY_FILES,'1920x700'),
		            'story_board_id'=>$storyBoard->id
		           ]);
		       }
		   }

		if(count($storyBoard->boardGalleries)>0){
			array_push($service_board_array,'p');
		}

        if(($request->flickr_photo_set_id))
        {
            array_push($service_board_array,'p');
        }

		if($request['p_video_link']){
			array_push($service_board_array,'v');
		}

		if($floorPlanImage!=null){
			array_push($service_board_array,'f');
		}

		if(isset($storyBoard->p_metterport)){
			array_push($service_board_array,'m');
		}

		if(count($storyBoard->panoramas)>0){
			array_push($service_board_array,'pa');
		}


		if($id!=null){
			$storyBoardService=StoryBoardServiceModel::whereStoryBoardId($id)->first();
			$storyBoardService->delete();
		}

		StoryBoardServiceModel::create([
			'story_board_id'=>$storyBoard->id,
			'client_id'		=>$request['user_id'],
			'service_p'		=>$request['service']['p']??0,
			'service_v'		=>$request['service']['v']??0,
			'service_f'		=>$request['service']['f']??0,
			'service_m'		=>$request['service']['m']??0,
			'service_pa'	=>$request['service']['pa']??0
		]);

		// dd($service_board_array);
		if(array_keys($request['service'])==$service_board_array){
			$status=1;
		}else{
			$status=0;
		}



		// foreach($request['service'] as $key=>$servie){
		// 	if(in_array($key,$service_board_array)){
		// 		$status=1;
		// 	}else{
		// 		$status=0;
		// 	}
		// }

		$storyBoard->update([
			'status'=>$status
		]);

		DB::commit();

		return $storyBoard;

		} catch (\Exception $e) {
		    DB::rollback();
            dd($e->getMessage());
		    // throw $e;
		}
	}


	public function getViemoVideoLink($video_link)
	{
		try{
			$client = new Client();
			$response = $client->get("https://vimeo.com/api/oembed.json?url=".$video_link);
			return json_decode($response->getBody()->getContents())->html;
		}catch(\Exception $e){
			return null;
		}
	}





}
