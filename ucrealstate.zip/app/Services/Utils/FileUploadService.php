<?php

namespace App\Services\Utils;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Image;

class FileUploadService
{
    public function uploadBase64File(Request $request, $field_name, $upload_path = null, $delete_path = null)
    {
        try {
            // Upload image
            if ($request->$field_name) {
                // Delete old file
                if ($delete_path) {
                    $this->delete($delete_path);
                }
                // Upload new file
                return $this->uploadBase64($request->$field_name, $upload_path);
            }
            return null;
        } catch (\Exception $ex) {
            return null;
        }
    }

    public function uploadFile(Request $request, $field_name = null, $upload_path = null, $delete_path = null)
    {
        try {
            // Upload image
            if ($request->hasFile($field_name)) {
                // Delete old file
                if ($delete_path) {
                    $this->delete($delete_path);
                }
                // Upload new file
                return $this->upload($request->file($field_name), $upload_path);
            }
            return null;
        } catch (\Exception $ex) {
            return null;
        }
    }

    public function upload($file, $path = 'others')
    {
        try {
            $name = time() . Str::random(60) . '.' . $file->getClientOriginalExtension();
            // Store image to public disk
            $file->storeAs('public/' . $path, $name);
            return $name ?? '';
        } catch (\Exception $ex) {
            return '';
        }
    }

    public function uploadBase64($file, $path = 'others')
    {
        try {
            if ($file) {
                $name = time() . Str::uuid() . '.png';
                $img = substr($file, strpos($file, ",") + 1);
                Storage::disk('public')->put($path . '/' . $name, base64_decode($img));
                return $name;
            }
        } catch (\Exception $ex) {
            return '';
        }
    }

    public function delete($path = '')
    {
        try {
            // Delete image form public directory
            $path = storage_path("app/public/" . $path);
            if (file_exists($path)) unlink($path);
        } catch (\Exception $ex) {
        }
    }
}
