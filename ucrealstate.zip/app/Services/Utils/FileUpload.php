<?php

namespace App\Services\Utils;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

class FileUpload
{
    public function upload($file, $path = 'others')
    {
        try {
            $storedFile = $file->store($path);
            return $storedFile ?? '';
        } catch (\Exception $ex) {
            return '';
        }
    }

    public function delete($path = '')
    {
        try {
            Storage::delete($path);
        } catch (\Exception $ex) {
        }
    }
}
