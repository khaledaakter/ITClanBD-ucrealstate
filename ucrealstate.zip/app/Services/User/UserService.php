<?php

namespace App\Services\User;

use App\Models\ThemeColor;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;


class UserService{

public function updateOrCreate(Request $request,$id=null)
{
	// dd(isset($request['password']));
   
	try {
		$user=User::updateOrCreate(['id'=>$id],[
                'first_name'        =>$request['first_name'],
                'last_name'         =>$request['last_name'],
                'display_name'      =>$request['display_name'],
                'user_name'         =>$request['user_name'],
                'team_name'         =>$request['team_name'],
                'title'             =>$request['title'],
                'email'             =>$request['email'],
                'location'          =>$request['location'],
                'latitude'          =>$request['latitude'],
                'longitude'         =>$request['longitude'],
                'cc_email'          =>$request['cc_email'],
                'g_email'           =>$request['g_email'],
                'password'          =>(!empty($request['password']))?Hash::make($request['password']):User::whereId(auth()->user()->id)->first()->password,
                'phone'             =>$request['phone'],
                'office_id'         =>$request['office_id'],
                'website'           =>$request['website'],
                'facebook'          =>$request['facebook'],
                'linkdin'           =>$request['linkdin'],
                'twitter'           =>$request['twitter'],
                'instragram'        =>$request['instragram'],
                'youtube'           =>$request['youtube'],
                'photo'             =>$request->hasfile('photo')?imageUploadHandler($request->file('photo'),User::PROFILE_IMAGE,'240x240',User::whereId(auth()->user()->id)->first()->photo):User::whereId(auth()->user()->id)->first()->photo,
                'background_image'  =>$request->hasfile('background_image')?imageUploadHandler($request->file('background_image'),User::PROFILE_IMAGE,'1920x600',User::whereId(auth()->user()->id)->first()->background_image):User::whereId(auth()->user()->id)->first()->background_image,
                'logo'              =>$request->hasfile('logo')?imageUploadHandler($request->file('logo'),User::PROFILE_IMAGE,'160x34',User::whereId(auth()->user()->id)->first()->logo):User::whereId(auth()->user()->id)->first()->logo,
                'user_type'         =>User::whereId(auth()->user()->id)->first()->user_type
            ]);

            User::whereId($user->id)->first()->themeColors()->delete();

            foreach($request['color'] as $key=>$color)
            {
                ThemeColor::create([
                    'color'     =>$color,
                    'user_id'   =>$user->id
                ]);
            }
            return;
	} catch (Exception $e) {
		DB::rollback();
		throw $e;
	}
}


}



