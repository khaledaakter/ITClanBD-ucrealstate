<?php

namespace App\Traits\Scopes;

use App\Scopes\AppUserScope;

trait AppUserGlobalScope
{
    protected static function booted()
    {
        static::addGlobalScope(new AppUserScope());
    }
}
