<?php

namespace App\Http\Traits;

use GuzzleHttp\Client;
use Robiussani152\Settings\Facades\Settings;

trait FlickrApiTrait
{

    public function __construct()
    {
        $this->client = new Client();
        $this->userId = Settings::get('flickr_user_id');
        $this->secret = Settings::get('flickr_secret');
        $this->key    = Settings::get('flickr_key');
    }

    public function flickrApi($photoSetId)
    {
        $data          = $this->mainFlickr($photoSetId);
        $flickr_photos = [];
        if ($data['stat'] == 'ok') {
            foreach ($data['photoset']['photo'] as $key => $photo) {
                array_push($flickr_photos, "https://live.staticflickr.com/" . $photo['server'] . "/" . $photo['id'] . "_" . $photo['secret'] . ".jpg");
            }
        }
        return $flickr_photos;
    }

    public function flickrApiFirstImage($photoSetId)
    {
        $data = $this->mainFlickr($photoSetId);

        $flickr_photos = '';
        if ($data['stat'] == 'ok') {
            foreach ($data['photoset']['photo'] as $key => $photo) {
                if ($key == 0) {
                    $flickr_photos .= "https://live.staticflickr.com/" . $photo['server'] . "/" . $photo['id'] . "_" . $photo['secret'] . ".jpg";
                }
            }
        }
        return $flickr_photos;
    }

    public function mainFlickr($photoSetId)
    {
        $response = $this->client->get('https://www.flickr.com/services/rest?method=flickr.photosets.getPhotos&photoset_id=' . $photoSetId . '&user_id=' . $this->userId . '&api_key=' . $this->key . '&format=json');

        $data = ($response->getBody()->getContents());

        $data = str_replace('jsonFlickrApi(', '', $data);
        $data = str_replace(')', '', $data);
        $data = json_decode($data, true);
        return $data;
    }

    public function getOriginImage($photoSetId)
    {
        $data      = $this->mainFlickr($photoSetId);
        $photo_ids = [];
        if ($data['stat'] == 'ok') {
            foreach ($data['photoset']['photo'] as $key => $photo) {
                array_push($photo_ids, $photo['id']);
            }
        }
        return $this->getOriginalPhoto($photo_ids);
    }

    public function getOriginalPhoto($photoIds)
    {
        $orginal_imageurl = [];
        if (count($photoIds) > 0) {
            foreach ($photoIds as $key => $photoId) {
                $response = $this->client->get('https://www.flickr.com/services/rest?method=flickr.photos.getSizes&api_key=' . $this->key . '&photo_id=' . $photoId . '&format=json');
                $data     = ($response->getBody()->getContents());

                $data = str_replace('jsonFlickrApi(', '', $data);
                $data = str_replace(')', '', $data);
                $data = json_decode($data, true);
                if (count($data['sizes']['size']) > 0) {
                    foreach ($data['sizes']['size'] as $size) {
                        if ($size['label'] == 'Original') {
                            array_push($orginal_imageurl, $size['source']);
                        }
                    }
                }

            }

        }
        return $orginal_imageurl;

    }

}
