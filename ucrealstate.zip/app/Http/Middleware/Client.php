<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Client
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if((auth()->check()) && (auth()->user()->user_type == 0)){
            return $next($request);
        }
        Auth::logout();
        // flash('error',"You don'/t have access.");
        return redirect(route('home'));
    }
}
