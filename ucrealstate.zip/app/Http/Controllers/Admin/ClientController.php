<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Mail\CreateNewUser;
use App\Models\Office;
use App\Models\ThemeColor;
use App\Models\User;
use App\Services\Utils\FileUploadService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Spatie\Permission\Traits\syncRoles;

class ClientController extends Controller
{

    public function __construct(FileUploadService $fileUploadService)
    {
        $this->fileUploadService=$fileUploadService;

        $this->middleware(['permission:Add Client'])->only(['create']);
        $this->middleware(['permission:Edit Client'])->only(['edit','update']);
        $this->middleware(['permission:Show Client'])->only(['index']);
        $this->middleware(['permission:Delete Client'])->only(['destroy']);
        $this->middleware(['permission:Trashed Client'])->only(['trashedList']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $clients=User::whereUserType(User::GET_USER_TYPE['client'])->orderBy('updated_at','DESC')->get();
        return view('admin.client.index',compact('clients'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $offices=Office::orderBy('name')->get();
        return view('admin.client.create',compact('offices'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // return $request->all();

        $request->validate([
            'first_name'=>'required|string',
            'last_name'=>'required|string',
            'display_name'=>'required|string',
            'email'=>'required|unique:users,email',
            'password'=>'required|min:8',
            'user_name'=>'required|unique:users,user_name'
        ]);

        try {

            $user=User::create([
                'first_name'        =>$request->first_name,
                'last_name'         =>$request->last_name,
                'display_name'      =>$request->display_name,
                'user_name'         =>strtolower($request->user_name),
                'team_name'         =>$request->team_name,
                'title'             =>$request->title,
                'email'             =>$request->email,
                'location'          =>$request->location,
                'latitude'          =>$request->latitude,
                'longitude'         =>$request->longitude,
                'cc_email'          =>$request->cc_email,
                'g_email'           =>$request->g_email,
                'password'          =>Hash::make($request->password),
                'phone'             =>$request->phone,
                'office_id'         =>$request->office_id,
                'website'           =>$request->website,
                'facebook'          =>$request->facebook,
                'linkdin'           =>$request->linkdin,
                'twitter'           =>$request->twitter,
                'instragram'        =>$request->instragram,
                'youtube'           =>$request->youtube,
                'note'              =>$request->note,
                'photo'             =>$request->hasfile('photo')?imageUploadHandler($request->file('photo'),User::PROFILE_IMAGE,'240x240'):null,
                'background_image'  =>$request->hasfile('background_image')?imageUploadHandler($request->file('background_image'),User::PROFILE_IMAGE,'1920x600'):null,
                'logo'              =>$request->hasfile('logo')?imageUploadHandler($request->file('logo'),User::PROFILE_IMAGE,'160x34'):null,
                'user_type'         =>User::GET_USER_TYPE['client']
            ]);

            foreach($request->color as $key=>$color)
            {
                ThemeColor::create([
                    'color'     =>$color,
                    'user_id'   =>$user->id
                ]);
            }
            // Assain Client Role
            $user->syncRoles('Client');

            // send email
            // Mail::to($request->email)->later(now()->addSeconds(5), new CreateNewUser($request->display_name,$request->email,$request->password));

            sendFlash('Client Create Successfully');
            return redirect()->route('admin.client.index');

        } catch (Exception $e) {
            sendFlash($e->getMessage(),'error');
            return redirect()->route('admin.client.index');
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $client=User::findOrFail($id);
        $offices=Office::orderBy('name')->get();
        return view('admin.client.edit',compact('client','offices'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'first_name'=>'required|string',
            'last_name'=>'required|string',
            'display_name'=>'required|string',
            'email'=>'required|unique:users,email,'.$id,
            'user_name'=>'required|unique:users,user_name,'.$id
        ]);

        try {

            $user=User::whereId($id)->update([
                'first_name'        =>$request->first_name,
                'last_name'         =>$request->last_name,
                'display_name'      =>$request->display_name,
                'user_name'         =>strtolower($request->user_name),
                'team_name'         =>$request->team_name,
                'title'             =>$request->title,
                'email'             =>$request->email,
                'location'          =>$request->location,
                'latitude'          =>$request->latitude,
                'longitude'         =>$request->longitude,
                'cc_email'          =>$request->cc_email,
                'g_email'           =>$request->g_email,
                'password'          =>isset($request->password)?Hash::make($request->password):User::whereId($id)->first()->password,
                'phone'             =>$request->phone,
                'office_id'         =>$request->office_id,
                'website'           =>$request->website,
                'facebook'          =>$request->facebook,
                'linkdin'           =>$request->linkdin,
                'twitter'           =>$request->twitter,
                'instragram'        =>$request->instragram,
                'youtube'           =>$request->youtube,
                'note'              =>$request->note,
                'photo'             =>$request->hasfile('photo')?imageUploadHandler($request->file('photo'),User::PROFILE_IMAGE,'240x240',User::whereId($id)->first()->photo):User::whereId($id)->first()->photo,
                'background_image'  =>$request->hasfile('background_image')?imageUploadHandler($request->file('background_image'),User::PROFILE_IMAGE,'1920x600',User::whereId($id)->first()->background_image):User::whereId($id)->first()->background_image,
                'logo'              =>$request->hasfile('logo')?imageUploadHandler($request->file('logo'),User::PROFILE_IMAGE,'160x34',User::whereId($id)->first()->logo):User::whereId($id)->first()->logo,
                'user_type'         =>User::GET_USER_TYPE['client']
            ]);

            User::whereId($id)->first()->themeColors()->delete();

            foreach($request->color as $key=>$color)
            {
                ThemeColor::create([
                    'color'     =>$color,
                    'user_id'   =>$id
                ]);
            }
            // // send email
            // Mail::to($request->email)->later(now()->addSeconds(5), new CreateNewUser($request->display_name,$request->email,$request->password));

            sendFlash('Client Update Successfully');
            return redirect()->route('admin.client.index');

        } catch (Exception $e) {
            sendFlash($e->getMessage(),'error');
            return redirect()->route('admin.client.index');
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       $user=User::findOrFail($id);
       $user->delete();
       sendFlash('Client Delete Successfully');
       return redirect()->route('admin.client.index');
    }

    public function checkUrl(Request $request)
    {

        $user_name=User::whereUserName($request->user_name)->first();
        if ($user_name) {
           return response()->json(['error'=>'Please Change First and Last Name.']);
        }else{
            return response()->json(['user_name'=>$request->user_name]);
        }
    }

    public function trashedList()
    {
        $clients=User::onlyTrashed()->whereUserType(User::GET_USER_TYPE['client'])->get();
        return view('admin.client.trashed',compact('clients'));
    }

    public function restore(Request $request,$id)
    {
        $client=User::whereId($id)->withTrashed()->first();
        $client->restore();
        sendFlash('Client Restore Successfully');
       return redirect()->route('admin.client.index');
    }
}
