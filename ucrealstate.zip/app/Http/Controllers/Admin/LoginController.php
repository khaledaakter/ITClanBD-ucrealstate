<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Office;
use App\Models\StoryBoard;
use App\Models\ThemeColor;
use App\Models\User;
use App\Services\User\UserService;
use App\Services\Utils\FileUploadService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
	public function __construct(FileUploadService $fileUploadService,UserService $userService)
	{
	    $this->fileUploadService=$fileUploadService;
        $this->userService=$userService;
	}

    public function dashboard()
    {
        $storyBoareds=StoryBoard::orderBy('updated_at','DESC')->with(['user','bannerImages','boardGalleries'])->whereHas('user')->get();
        $page_title="Dashborad | Uplan photography & Measuring";
        return view('admin.dashboard',compact('storyBoareds','page_title'));
    }

    public function editProfile()
    {
    	$offices=Office::orderBy('name')->get();
    	return view('admin.profile',compact('offices'));
    }

    public function updateProfile(Request $request)
    {
    	$request->validate([
    	    'first_name'    =>'required|string',
    	    'last_name'     =>'required|string',
    	    'email'         =>'required|email|unique:users,email,'.auth()->user()->id
    	]);

    	try {
            $this->userService->updateOrCreate($request,auth()->user()->id);
    	    // // send email
    	    // Mail::to($request->email)->later(now()->addSeconds(5), new CreateNewUser($request->display_name,$request->email,$request->password));

    	    sendFlash('Profile Update Successfully');
    	    return redirect()->route('admin.dashboard');

    	} catch (Exception $e) {
    	    sendFlash($e->getMessage(),'error');
    	    return redirect()->route('admin.dashboard');
    	}
    }
}
