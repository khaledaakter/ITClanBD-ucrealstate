<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Office;
use App\Models\SystemCity;
use App\Models\SystemCountry;
use App\Models\SystemState;
use Illuminate\Http\Request;

class OfficeController extends Controller
{

    public function __construct()
    {
        $this->middleware(['permission:Add Office'])->only(['create']);
        $this->middleware(['permission:Edit Office'])->only(['edit','update']);
        $this->middleware(['permission:Show Office'])->only(['index']);
        $this->middleware(['permission:Delete Office'])->only(['destroy']);
        $this->middleware(['permission:Trashed Office'])->only(['trashedList']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $offices=Office::orderBy('updated_at','DESC')->get();
        return view('admin.office.index',compact('offices'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $countries=SystemCountry::orderBy('name')->get();
        $road_types=Office::ROAD_TYPE;
        return view('admin.office.create',compact('countries','road_types'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'      =>'required|string',
            'country'   =>'required|string',
            'state'     =>'required|string',
            'city'      =>'required|string',
        ]);

        Office::create([
            'name'          =>$request->name,
            'country'       =>$request->country,
            'state'         =>$request->state,
            'city'          =>$request->city,
            'unit'          =>$request->unit,
            'road_number'   =>$request->road_number,
            'road_name'     =>$request->road_name,
            'road_type'     =>$request->road_type,
            'location'      =>$request->location,
            'latitude'      =>$request->latitude,
            'longitude'     =>$request->longitude,
            'logo'          =>$request->hasfile('logo')?imageUploadHandler($request->file('logo'),Office::LOGO,'160x34'):null,
            'created_by'    =>auth()->user()->id
        ]);

        sendFlash('Office Create Successfully.');
        return redirect()->route('admin.office.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $office=Office::findOrFail($id);
        $countries=SystemCountry::orderBy('name')->get();
        $states=SystemState::whereCountryId($office->country)->get();
        $cities=SystemCity::whereStateId($office->state)->get();
        $road_types=Office::ROAD_TYPE;
        return view('admin.office.edit',compact('countries','office','states','cities','road_types'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name'      =>'required|string',
            'country'   =>'required|string',
            'state'     =>'required|string',
            'city'      =>'required|string',
        ]);
        $data = request()->except(['_token','_method']);
        Office::whereId($id)->update([
            'name'          =>$request->name,
            'country'       =>$request->country,
            'state'         =>$request->state,
            'city'          =>$request->city,
            'unit'          =>$request->unit,
            'road_number'   =>$request->road_number,
            'road_name'     =>$request->road_name,
            'road_type'     =>$request->road_type,
            'location'      =>$request->location,
            'latitude'      =>$request->latitude,
            'longitude'     =>$request->longitude,
            'logo'          =>$request->hasfile('logo')?imageUploadHandler($request->file('logo'),Office::LOGO,'160x34',Office::whereId($id)->first()->logo):Office::whereId($id)->first()->logo,
            'created_by'    =>auth()->user()->id
        ]);

        sendFlash('Office Update Successfully.');
        return redirect()->route('admin.office.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $office=Office::findOrFail($id);
        $office->delete();
        sendFlash('Office Delete Successfully.');
        return redirect()->route('admin.office.index');
    }

    public function setCountry(Request $request)
    {
        $states=SystemState::whereCountryId($request->country_id)->get();
        return response()->json(['states'=>$states]);
    }
    public function setState(Request $request)
    {
        $cities=SystemCity::whereStateId($request->state_id)->get();
        return response()->json(['cities'=>$cities]);
    }

    public function trashedList()
    {
        $offices=Office::onlyTrashed()->get();
        return view('admin.office.trashed',compact('offices'));
    }

    public function restore(Request $request,$id)
    {
       $office=Office::whereId($id)->withTrashed()->first();
       $office->restore();
       sendFlash('Office Restore Successfully');
       return redirect()->route('admin.office.index');
    }
}
