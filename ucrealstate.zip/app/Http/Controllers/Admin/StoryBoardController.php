<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BannerImage;
use App\Models\StoryBoard;
use App\Models\StoryBoardGallery;
use App\Models\StoryBoardPanorama;
use App\Models\User;
use App\Services\StoryBoard\StoryBoardService;
use App\Services\Utils\FileUploadService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;

class StoryBoardController extends Controller
{
    public function __construct(StoryBoardService $storyBoardService,FileUploadService $fileUploadService)
    {
        $this->storyBoardService=$storyBoardService;
        $this->fileUploadService=$fileUploadService;

        $this->middleware(['permission:Add Property'])->only(['create']);
        $this->middleware(['permission:Edit Property'])->only(['edit','update']);
        $this->middleware(['permission:Show Property'])->only(['index']);
        $this->middleware(['permission:Delete Property'])->only(['destroy']);
        $this->middleware(['permission:Trashed Property'])->only(['trashedList']);

    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $storyBoareds=StoryBoard::orderBy('updated_at','DESC')->with(['user','bannerImages','boardGalleries'])->whereHas('user')->get();

       return view('admin.storyboard.index',compact('storyBoareds'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $users=User::whereUserType(User::GET_USER_TYPE['client'])->get();
        $road_types=StoryBoard::ROAD_TYPE;
        $cities=StoryBoard::CITYS;
        $room_names=StoryBoard::ROOM_NAMES;
        return view('admin.storyboard.create',compact('users','road_types','cities','room_names'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $request->validate([
            'user_id'   =>'required',
            'road_type' =>'required',
            'city'      =>'required'
        ]);

        return $this->common([
            'type'=>'success',
            'message'=>'Storyborad Create Successfully.',
            'route'=>route('admin.storyboard.index')
        ], function ()  use ($request){
            $this->storyBoardService->createOrUpdate($request);
        });

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $storyBoared=StoryBoard::whereId($id)->with(['user','bannerImages','boardGalleries'])->first();
        $users=User::whereUserType(User::GET_USER_TYPE['client'])->get();
        $road_types=StoryBoard::ROAD_TYPE;
        $cities=StoryBoard::CITYS;
        $room_names=StoryBoard::ROOM_NAMES;
        $client=User::whereId($storyBoared->user_id)->with('themeColors')->first();
        foreach($road_types as $key=>$road_type){
            if(strcmp($road_type,$storyBoared->road_type) !== 0)
            {
                array_push($road_types,$storyBoared->road_type);
                break;
            }
        }

        foreach($cities as $key=>$city){
            if(strcmp($city,$storyBoared->city) !== 0)
            {
                array_push($cities,$storyBoared->city);
                break;
            }
        }

        return view('admin.storyboard.edit',compact('storyBoared','users','road_types','cities','room_names','client'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'user_id'   =>'required',
            'road_type' =>'required',
            'city'      =>'required'
        ]);

        return $this->common([
            'type'=>'success',
            'message'=>'Storyborad Update Successfully.',
            'route'=>route('admin.storyboard.index')
        ], function ()  use ($request,$id){
            $this->storyBoardService->createOrUpdate($request,$id);
        });
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $storyBoard=StoryBoard::findOrFail($id);
        $storyBoard->delete();
        sendFlash('Storyboard Delete Successfully.');
        return redirect()->route('admin.storyboard.index');
    }

    public function trashedList()
    {
        $storyBoareds=StoryBoard::onlyTrashed()->with(['user','bannerImages','boardGalleries'])->get();
        return view('admin.storyboard.trashed',compact('storyBoareds'));
    }

    public function restore(Request $request,$id)
    {
        $storyBoarde=StoryBoard::whereId($id)->onlyTrashed()->first();
        $storyBoarde->restore();
        sendFlash('Storyboard Restore Successfully.');
        return redirect()->route('admin.storyboard.index');
    }

    public function deleteFile(Request $request)
    {
        if ($request->file_name=='bannerimage') {
            $banner_image=BannerImage::findOrFail($request->file_id);
            $banner_image->delete();
            $this->fileUploadService->delete($banner_image->image);
            return response()->json(['message'=>'File Delete Successfully']);
        }
        if ($request->file_name=='gallery') {
           $gallery=StoryBoardGallery::findOrFail($request->file_id);
           $gallery->delete();
           $this->fileUploadService->delete($gallery->image);
           return response()->json(['message'=>'File Delete Successfully']);
        }
    }

    public function StoryBoardDeleteFile(Request $request)
    {

        $field_name=$request->field_name;
        if ($field_name!='panorama') {
            $storyBoard=StoryBoard::findOrFail($request->story_board_id);
            $this->fileUploadService->delete($storyBoard->$field_name);
            $storyBoard->$field_name=null;
            $storyBoard->save();
            return response()->json(['message'=>'File Delete Successfully']);
        }else{
            $panorama=StoryBoardPanorama::findOrFail($request->story_board_id);
            $this->fileUploadService->delete($panorama->panorama_photo);
            $panorama->delete();
            return response()->json(['message'=>'File Delete Successfully']);
        }
    }

    public function clientThemeColor(Request $request)
    {
        $user=User::findOrFail($request->client_id);
        return response()->json(['theme_color'=>$user->themeColors]);
    }

    public function sendPhoto(Request $request)
    {

        $storyboard=StoryBoard::findOrFail($request->storyboard_id);
        $data = array(
                'from_email'    =>auth()->user()->email,
                'first_name'    =>$storyboard->user->first_name,
                'subject'       =>'Uplan Photography || '.$storyboard->property_address ,
                'address'       =>$storyboard->property_address,
                'link'          =>config('app.url').$storyboard->user->user_name.'/'.$storyboard->slug,
                'message'       => 'I will upload this already on Photography section.',
                'email'         =>$storyboard->user->email
            );

            $file = $request->file('file');
            $file_mls = $request->file('file_mls');
            // Log::debug('abcd');
        Mail::send('admin.email.p_email', compact('data'), function ($message) use($data, $file,$file_mls){
            $message->replyTo($data['from_email']);
            $message->to($data['email'])->subject($data['subject']);

            if(isset($file)) {
                $message->attach($file->getRealPath(), array(
                    'as' => $file->getClientOriginalName(), // If you want you can chnage original name to custom name
                    'mime' => $file->getMimeType())
                );
            }
            if(isset($file_mls)) {
                $message->attach($file_mls->getRealPath(), array(
                    'as' => $file_mls->getClientOriginalName(), // If you want you can chnage original name to custom name
                    'mime' => $file_mls->getMimeType())
                );
            }
        });



        $storyboard->update([
            'p_email'=>1,
            'p_high_resolution'=>$request->has('file')?$this->fileUploadService->uploadFile($request,'file',StoryBoard::STORY_FILES):null,
            'p_lms'=>$request->has('file_mls')?$this->fileUploadService->uploadFile($request,'file_mls',StoryBoard::STORY_FILES):null
        ]);

        return response()->json(['message'=>'Email Send Successfully']);
    }

    public function sendVideo(Request $request)
    {
        $storyboard=StoryBoard::findOrFail($request->storyboard_id);

        $data = array(
                'from_email'    =>auth()->user()->email,
                'subject'       => 'Uplan Videography || '.$storyboard->property_address ,
                'first_name'    =>$storyboard->user->first_name,
                'address'       => $storyboard->property_address,
                // 'message'       => $request->message,
                'video_link'    => $request->video_link,
                'download_link' => $request->download_link,
                'embed_code'    => $request->embed_code,
                'link'          =>config('app.url').$storyboard->user->user_name.'/'.$storyboard->slug,
                'email'         =>$storyboard->user->email
            );
        Mail::send('admin.email.v_email', compact('data'), function ($message) use($data){
            $message->replyTo($data['from_email']);
            $message->to($data['email'])->subject($data['subject']);
        });
        $storyboard->update([
            'v_email'=>1
        ]);

        return response()->json(['message'=>'Email Send Successfully']);
    }

    public function sendFloor(Request $request)
    {
        $storyboard=StoryBoard::findOrFail($request->storyboard_id);
        $data = array(
                'from_email'    =>auth()->user()->email,
                'subject'       => 'Uplan Floor Plan || '.$storyboard->property_address ,
                'first_name'    =>$storyboard->user->first_name,
                'address'       => $storyboard->property_address,
                'link'          =>config('app.url').$storyboard->user->user_name.'/'.$storyboard->slug,
                'email'         =>$storyboard->user->email
            );

            $image_one = $request->file('image_one');

            $image_two = $request->file('image_two');
            $file = $request->file('pdf_file');

        Mail::send('admin.email.f_email', compact('data'), function ($message) use($data,$image_one,$image_two,$file){
            $message->replyTo($data['from_email']);
            $message->to($data['email'])->subject($data['subject']);

            if(isset($file)) {
                $message->attach($file->getRealPath(), array(
                    'as' => $file->getClientOriginalName(), // If you want you can chnage original name to custom name
                    'mime' => $file->getMimeType())
                );
            }

            if(isset($image_one)) {
                $message->attach($image_one->getRealPath(), array(
                    'as' => $image_one->getClientOriginalName(), // If you want you can chnage original name to custom name
                    'mime' => $image_one->getMimeType())
                );
            }
            if(isset($image_two)) {
                $message->attach($image_two->getRealPath(), array(
                    'as' => $image_two->getClientOriginalName(), // If you want you can chnage original name to custom name
                    'mime' => $image_two->getMimeType())
                );
            }
        });
        $storyboard->update([
            'f_email'=>1,
            'p_no_brand'=>$request->has('image_two')?$this->fileUploadService->uploadFile($request,'image_two',StoryBoard::STORY_FILES):null,
            'p_pdf'=>$request->has('pdf_file')?$this->fileUploadService->uploadFile($request,'pdf_file',StoryBoard::STORY_FILES):null
        ]);

        return response()->json(['message'=>'Email Send Successfully']);
        // sendFlash('Email Send Successfully.');
        // return back();
    }

    public function sendMetter(Request $request)
    {
        $storyboard=StoryBoard::findOrFail($request->storyboard_id);

        $data = array(
                'from_email'    =>auth()->user()->email,
                'subject'       => 'Uplan Matterport || '.$storyboard->property_address ,
                'first_name'    =>$storyboard->user->first_name,
                'address'       =>$storyboard->property_address,
                'link'          =>config('app.url').$storyboard->user->user_name.'/'.$storyboard->slug,
                'p_metterport'  =>$request->p_metterport,
                'email'         =>$storyboard->user->email
            );

        Mail::send('admin.email.m_email', compact('data'), function ($message) use($data){
            $message->replyTo($data['from_email']);
            $message->to($data['email'])->subject($data['subject']);
        });
        $storyboard->update([
            'm_email'=>1
        ]);

        return response()->json(['message'=>'Email Send Successfully']);
        // sendFlash('Email Send Successfully.');
        // return back();
    }

    public function sendPanaroma(Request $request)
    {
        $storyboard=StoryBoard::findOrFail($request->storyboard_id);
        $data = array(
                'from_email'    =>auth()->user()->email,
                'subject'       => 'Uplan Virtual Tour || '.$storyboard->property_address ,
                'first_name'    =>$storyboard->user->first_name,
                'address'       => $storyboard->property_address,
                'link'          => config('app.url').$storyboard->user->user_name.'/'.$storyboard->slug,
                'embed_code'    =>'I will upload this already on Panorama section.',
                'email'         =>$storyboard->user->email
            );

        Mail::send('admin.email.pa_email', compact('data'), function ($message) use($data){
            $message->replyTo($data['from_email']);
            $message->to($data['email'])->subject($data['subject']);
        });

        $storyboard->update([
            'pa_email'=>1
        ]);

        sendFlash('Email Send Successfully.');
        return back();
    }

    public function getEmbedCode(Request $request){
        $storyBoard=StoryBoard::findOrFail($request->story_board_id);
        $embted_code=$this->storyBoardService->getViemoVideoLink($request->url);
        $storyBoard->update([
            'p_video_iframe'=>$embted_code??null
        ]);
        return response()->json(['embed'=> $embted_code]);
    }

    public function updateInvoice(Request $request)
    {
        $storyBoard=StoryBoard::findOrFail($request->storyboard_id);
        $storyBoard->update([
            'invoice'=>$request->invoice=='1'?0:1
        ]);
        return response()->json(['storyboard'=>$storyBoard]);
    }
    public function updateFavorite(Request $request)
    {
        $storyBoard=StoryBoard::findOrFail($request->storyboard_id);
        $storyBoard->update([
            'favorite'=>$request->favorite=='1'?0:1
        ]);
        return response()->json(['storyboard'=>$storyBoard]);
    }

}
