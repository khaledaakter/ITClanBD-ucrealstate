<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Mail\CreateNewUser;
use App\Models\Office;
use App\Models\ThemeColor;
use App\Models\User;
use App\Services\Utils\FileUploadService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{
    public function __construct(FileUploadService $fileUploadService)
    {
        $this->fileUploadService=$fileUploadService;

        $this->middleware(['permission:Add User'])->only(['create']);
        $this->middleware(['permission:Edit User'])->only(['edit','update']);
        $this->middleware(['permission:Show User'])->only(['index']);
        $this->middleware(['permission:Delete User'])->only(['destroy']);
        $this->middleware(['permission:Trashed User'])->only(['trashedList']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users=User::with('roles')->get();
        return view('admin.user.index',compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $offices=Office::orderBy('name')->get();
        $roles=Role::all();
        return view('admin.user.create',compact('offices','roles'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'first_name'    =>'required|string',
            'last_name'     =>'required|string',
            'display_name'  =>'required|string',
            'password'      =>'required|min:8',
            'user_name'     =>'required|string|unique:users,user_name',
            'email'         =>'required|email|unique:users,email'
        ]);

        try {

            $user=User::create([
                'first_name'        =>$request->first_name,
                'last_name'         =>$request->last_name,
                'display_name'      =>$request->display_name,
                'user_name'         =>$request->user_name,
                'team_name'         =>$request->team_name,
                'title'             =>$request->title,
                'email'             =>$request->email,
                'location'          =>$request->location,
                'latitude'          =>$request->latitude,
                'longitude'         =>$request->longitude,
                'cc_email'          =>$request->cc_email,
                'g_email'           =>$request->g_email,
                'password'          =>Hash::make($request->password),
                'phone'             =>$request->phone,
                'office_id'         =>$request->office_id,
                'website'           =>$request->website,
                'facebook'          =>$request->facebook,
                'linkdin'           =>$request->linkdin,
                'twitter'           =>$request->twitter,
                'instragram'        =>$request->instragram,
                'youtube'           =>$request->youtube,
                'note'              =>$request->note,
                'photo'             =>$request->hasfile('photo')?imageUploadHandler($request->file('photo'),User::PROFILE_IMAGE,'240x240'):null,
                'background_image'  =>$request->hasfile('background_image')?imageUploadHandler($request->file('background_image'),User::PROFILE_IMAGE,'1920x600'):null,
                'logo'              =>$request->hasfile('logo')?imageUploadHandler($request->file('logo'),User::PROFILE_IMAGE,'160x34'):null,
                'user_type'         =>Role::whereId($request->role_id)->first()->name=='Client'?User::GET_USER_TYPE['client']:User::GET_USER_TYPE['admin']
            ]);

            $user->syncRoles($request->role_id);
            // User::whereId($id)->first()->syncRoles($request->role_id);
            foreach($request->color as $key=>$color)
            {
                ThemeColor::create([
                    'color'     =>$color,
                    'user_id'   =>$user->id
                ]);
            }
            // // send email 
            Mail::to($request->email)->later(now()->addSeconds(5), new CreateNewUser($request->display_name,$request->email,$request->password));

            sendFlash('User Create Successfully');
            return redirect()->route('admin.user.index');

        } catch (Exception $e) {
            sendFlash($e->getMessage(),'error');
            return redirect()->route('admin.user.index');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user  =User::with('roles')->findOrFail($id);
        $offices=Office::orderBy('name')->get();
        $roles=Role::all();
        return view('admin.user.edit',compact('user','offices','roles'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'first_name'    =>'required|string',
            'last_name'     =>'required|string',
            'display_name'  =>'required|string',
            'user_name'     =>'required|string|unique:users,user_name,'.$id,
            'email'     =>'required|email|unique:users,email,'.$id
        ]);

        try {

            User::whereId($id)->update([
                'first_name'        =>$request->first_name,
                'last_name'         =>$request->last_name,
                'display_name'      =>$request->display_name,
                'user_name'         =>$request->user_name,
                'team_name'         =>$request->team_name,
                'title'             =>$request->title,
                'email'             =>$request->email,
                'location'          =>$request->location,
                'latitude'          =>$request->latitude,
                'longitude'         =>$request->longitude,
                'cc_email'          =>$request->cc_email,
                'g_email'           =>$request->g_email,
                'password'          =>isset($request->password)?Hash::make($request->password):User::whereId($id)->first()->password,
                'phone'             =>$request->phone,
                'office_id'         =>$request->office_id,
                'website'           =>$request->website,
                'facebook'          =>$request->facebook,
                'linkdin'           =>$request->linkdin,
                'twitter'           =>$request->twitter,
                'instragram'        =>$request->instragram,
                'youtube'           =>$request->youtube,
                'note'              =>$request->note,
                'photo'             =>$request->hasfile('photo')?imageUploadHandler($request->file('photo'),User::PROFILE_IMAGE,'240x240',User::whereId($id)->first()->photo):User::whereId($id)->first()->photo,
                'background_image'  =>$request->hasfile('background_image')?imageUploadHandler($request->file('background_image'),User::PROFILE_IMAGE,'1920x600',User::whereId($id)->first()->background_image):User::whereId($id)->first()->background_image,
                'logo'              =>$request->hasfile('logo')?imageUploadHandler($request->file('logo'),User::PROFILE_IMAGE,'160x34',User::whereId($id)->first()->logo):User::whereId($id)->first()->logo,
                'user_type'         =>Role::whereId($request->role_id)->first()->name=='Client'?User::GET_USER_TYPE['client']:User::GET_USER_TYPE['admin']
            ]);

            User::whereId($id)->first()->syncRoles($request->role_id);
            // // send email 
            // Mail::to($request->email)->later(now()->addSeconds(5), new CreateNewUser($request->display_name,$request->email,$request->password));

            User::whereId($id)->first()->themeColors()->delete();

            foreach($request->color as $key=>$color)
            {
                ThemeColor::create([
                    'color'     =>$color,
                    'user_id'   =>$id
                ]);
            }

            sendFlash('User Update Successfully');
            return redirect()->route('admin.user.index');

        } catch (Exception $e) {
            sendFlash($e->getMessage(),'error');
            return redirect()->route('admin.user.index');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user=User::findOrFail($id);
        $user->delete();
        sendFlash('User Delete Successfully');
        return redirect()->route('admin.user.index');
    }

    public function trashedList()
    {
        $users=User::onlyTrashed()->get();
        return view('admin.user.trashed',compact('users'));
    }

    public function restore(Request $request,$id)
    {
        $user=User::whereId($id)->onlyTrashed()->first();
        $user->restore();
        sendFlash('User Restore Successfully');
        return redirect()->route('admin.user.index');
    }
}
