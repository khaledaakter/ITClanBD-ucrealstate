<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\Utils\FileUploadService;
use Robiussani152\Settings\Models\Settings;

class SettingController extends Controller
{

    public function __construct(FileUploadService $fileUploadService)
    {
        $this->fileUploadService=$fileUploadService;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $settings=Settings::all();
        return view('admin.setting.create',compact('settings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {

            if ($request->title) {
                $title=Settings::whereSettingKey('title')->first();
                $title->setting_value=$request->title;
                $title->save();
            }

            if ($request->hasFile('logo')) {
                $logo=Settings::whereSettingKey('logo')->first();
                $logo->setting_value=imageUploadHandler($request->file('logo'),'settings','160x34');
                $logo->save();
            }

            if ($request->hasFile('fabicon')) {
                $fab=Settings::whereSettingKey('fabicon')->first();
                $fab->setting_value=imageUploadHandler($request->file('fabicon'),'settings','16x16');
                $fab->save();
            }

            if ($request->hasFile('login_image')) {
                $login=Settings::whereSettingKey('login_image')->first();
                $login->setting_value=imageUploadHandler($request->file('login_image'),'settings','700x1050');
                $login->save();
            }

            if($request->hasFile('default_bg'))
            {
                $login=Settings::whereSettingKey('default_bg')->first();
                $login->setting_value=imageUploadHandler($request->file('default_bg'),'settings','1920x600');
                $login->save();
            }

            if($request->hasFile('default_profile'))
            {
                $login=Settings::whereSettingKey('default_profile')->first();
                $login->setting_value=imageUploadHandler($request->file('default_profile'),'settings','240x240');
                $login->save();
            }

            if(isset($request->flickr_user_id))
            {
                $flickr_user_id=Settings::whereSettingKey('flickr_user_id')->first();
                $flickr_user_id->setting_value=$request->flickr_user_id;
                $flickr_user_id->save();
            }
            if(isset($request->flickr_key))
            {
                $flickr_key=Settings::whereSettingKey('flickr_key')->first();
                $flickr_key->setting_value=$request->flickr_key;
                $flickr_key->save();
            }

            if(isset($request->flickr_secret))
            {
                $flickr_secret=Settings::whereSettingKey('flickr_secret')->first();
                $flickr_secret->setting_value=$request->flickr_secret;
                $flickr_secret->save();
            }


            sendFlash('Setting Update Successfully.');
            return redirect()->route('admin.setting.index');

        } catch (Exception $e) {
            sendFlash($e->getMessage(),'error');
            return redirect()->route('admin.setting.index');
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
