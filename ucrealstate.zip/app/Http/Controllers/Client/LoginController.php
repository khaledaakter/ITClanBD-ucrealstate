<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Office;
use App\Models\StoryBoard;
use App\Models\ThemeColor;
use App\Models\User;
use App\Services\Utils\FileUploadService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
	public function __construct(FileUploadService $fileUploadService)
	{
	    $this->fileUploadService=$fileUploadService;
	}

    public function dashboard()
    {
        $storyBoards=StoryBoard::whereUserId(auth()->user()->id)->with(['bannerImages','boardGalleries'])->get();
        return view('client.dashboard',compact('storyBoards'));
    }

    public function editProfile()
    {
    	$offices=Office::orderBy('name')->get();
    	return view('client.profile',compact('offices'));
    }

    public function updateProfile(Request $request)
    {
    	$request->validate([
    	    'first_name'    =>'required|string',
    	    'last_name'     =>'required|string',
    	    'email'         =>'required|email|unique:users,email,'.auth()->user()->id
    	]);

    	try {

    	    $user=User::whereId(auth()->user()->id)->update([
    	        'first_name'        =>$request->first_name,
    	        'last_name'         =>$request->last_name,
    	        'title'             =>$request->title,
    	        'email'             =>$request->email,
                'location'          =>$request->location,
                'latitude'          =>$request->latitude,
                'longitude'         =>$request->longitude,
                'cc_email'          =>$request->cc_email,
                'g_email'           =>$request->g_email,
    	        'password'          =>(!empty($request->password))?Hash::make($request->password):auth()->user()->password,
    	        'website'           =>$request->website,
    	        'facebook'          =>$request->facebook,
    	        'linkdin'           =>$request->linkdin,
    	        'twitter'           =>$request->twitter,
                'instragram'        =>$request->instragram,
                'youtube'           =>$request->youtube,
    	        'photo'             =>$request->hasfile('photo')?imageUploadHandler($request->file('photo'),User::PROFILE_IMAGE,'240x240',User::whereId(auth()->user()->id)->first()->photo):User::whereId(auth()->user()->id)->first()->photo,
                'background_image'  =>$request->hasfile('background_image')?imageUploadHandler($request->file('background_image'),User::PROFILE_IMAGE,'1920x600',User::whereId(auth()->user()->id)->first()->background_image):User::whereId(auth()->user()->id)->first()->background_image,
    	    	'logo'              =>$request->hasfile('logo')?imageUploadHandler($request->file('logo'),User::PROFILE_IMAGE,'160x34',auth()->user()->logo):auth()->user()->logo,
                'user_type'			=>auth()->user()->user_type
    	    ]);
    	    // // send email 
    	    // Mail::to($request->email)->later(now()->addSeconds(5), new CreateNewUser($request->display_name,$request->email,$request->password));

            User::whereId(auth()->user()->id)->first()->themeColors()->delete();

            foreach($request->color as $key=>$color)
            {
                ThemeColor::create([
                    'color'     =>$color,
                    'user_id'   =>auth()->user()->id
                ]);
            }

    	    sendFlash('Profile Update Successfully');
    	    return redirect()->route('client.dashboard');

    	} catch (Exception $e) {
    	    sendFlash($e->getMessage(),'error');
    	    return redirect()->route('client.dashboard');
    	}
    }
}
