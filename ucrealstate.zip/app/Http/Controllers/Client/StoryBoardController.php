<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\StoryBoard;
use App\Services\Utils\FileUploadService;
use Illuminate\Http\Request;

class StoryBoardController extends Controller
{
    public function __construct(FileUploadService $fileUploadService)
    {
        $this->fileUploadService=$fileUploadService;
        
        $this->middleware(['permission:Client Edit StoryBoard'])->only(['edit','updateStoryBoard']);
    }

    public function index()
    {
        $storyBoareds=StoryBoard::whereUserId(auth()->user()->id)->get();
        return view('client.storyboard.index',compact('storyBoareds'));
    }

    public function edit($slug)
    {
        $storyBoard=StoryBoard::whereSlug($slug)->whereUserId(auth()->user()->id)->first();
        if ($storyBoard) {
            return view('client.storyboard.edit',compact('storyBoard'));
        }else{
            abort(404);
        }
    }


    public function showGallery($slug)
    {
    	$storyBoard=StoryBoard::whereSlug($slug)->whereUserId(auth()->user()->id)->with(['boardGalleries'])->first();
    	if ($storyBoard) {
    		return view('client.storyboard.gallery',compact('storyBoard'));
    	}else{
    		abort(404);
    	}
    }

    public function showVideo($slug)
    {
    	$storyBoard=StoryBoard::whereSlug($slug)->whereUserId(auth()->user()->id)->first();
    	if ($storyBoard) {
    		return view('client.storyboard.video',compact('storyBoard'));
    	}else{
    		abort(404);
    	}
    }

    public function showPropertyPlan($slug)
    {
    	$storyBoard=StoryBoard::whereSlug($slug)->whereUserId(auth()->user()->id)->first();
    	if ($storyBoard) {
    		return view('client.storyboard.property_plan',compact('storyBoard'));
    	}else{
    		abort(404);
    	}
    }

    public function StoryBoardDeleteFile(Request $request)
    {
        $storyBoard=StoryBoard::findOrFail($request->story_board_id);
        $field_name=$request->field_name;
        if ($storyBoard) {
            $this->fileUploadService->delete($storyBoard->$field_name);
            $storyBoard->$field_name=null;
            $storyBoard->save();
            return response()->json(['message'=>'File Delete Successfully']);
        }
    }

    public function updateStoryBoard(Request $request,$slug)
    {
        $storyBoard=StoryBoard::whereSlug($slug)->first();
        if ($storyBoard) {
            StoryBoard::whereSlug($slug)->update([
                'show_about'    =>isset($request->show_about)?1:0,
                'property_price'=>$request->property_price,
                'about_property'=>$request->about_property,
                'property_image'=>$request->hasFile('property_image')?imageUploadHandler($request->file('property_image'),StoryBoard::STORY_FILES,'540x526'):$storyBoard->property_image,
                'year'          =>$request->year,
                'square_feets'  =>$request->square_feets,
                'bedroom'       =>$request->bedroom,
                'bathroom'      =>$request->bathroom
            ]);
            sendFlash('StorbBoard Update Successfully');
            return redirect()->route('client.storyboard.index');
        }else{
            abort(404);
        }
    }
}
