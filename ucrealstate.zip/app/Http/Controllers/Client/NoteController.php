<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Note;
use Illuminate\Http\Request;

class NoteController extends Controller
{

    public function __construct()
    {
        $this->middleware(['permission:Client Add Note'])->only(['create']);
        $this->middleware(['permission:Client Edit Note'])->only(['edit','update']);
        $this->middleware(['permission:Client Show Note'])->only(['index']);
        $this->middleware(['permission:Client Delete Note'])->only(['destroy']);
        $this->middleware(['permission:Client Trashed Note'])->only(['trashedList']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $notes=Note::whereCreatedBy(auth()->user()->id)->get();
        return view('client.note.index',compact('notes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('client.note.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title'=>'string|required'
        ]);

        Note::create([
            'title'     =>$request->title,
            'note'      =>$request->note,
            'created_by'=>auth()->user()->id
        ]);

        sendFlash('Note Create Successfully.');
        return redirect()->route('client.note.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $note=Note::whereId($id)->whereCreatedBy(auth()->user()->id)->first();
        if ($note) {
            return view('client.note.edit',compact('note'));
        }else{
            sendFlash('Note Not Found','error');
            return redirect()->route('client.note.index');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title'=>'string|required'
        ]);

        Note::whereId($id)->update([
            'title'     =>$request->title,
            'note'      =>$request->note
        ]);
        sendFlash('Note Update Successfully.');
        return redirect()->route('client.note.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $note=Note::findOrFail($id);
        $note->delete();
        sendFlash('Note Delete Successfully.');
        return redirect()->route('client.note.index');
    }

    public function trashedList()
    {
        $notes=Note::whereCreatedBy(auth()->user()->id)->onlyTrashed()->get();
        return view('client.note.trashed',compact('notes'));
    }

    public function restore(Request $request,$id)
    {
        $note=Note::whereId($id)->onlyTrashed()->first();
        $note->restore();
        sendFlash('Note Restore Successfully');
        return redirect()->route('client.note.index');
    }
}
