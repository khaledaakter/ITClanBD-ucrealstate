<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;


    public function common(array $response,callable $callable_func)
    {
    	try {
    	    $response_data = [];
    	    $response_data = $callable_func();
    	} catch (\Exception $e) {
    	    $response['type'] = 'error';
    	    $response['message'] = $e->getMessage();
    	    $response['route'] = url()->previous();
    	}

    	sendFlash($response['message'],$response['type']);
        return redirect($response['route'])->with($response_data)->withInput(request()->input());
    }
}
