<?php

namespace App\Http\Controllers;

use App\Http\Traits\FlickrApiTrait;
use App\Mail\ContactMail;
use App\Models\StoryBoard;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class FrontendController extends Controller
{
    use FlickrApiTrait;

    public function profile($user_name)
    {
        $user         = User::whereUserName($user_name)->with(['office', 'storyBoards'])->first();
        $theme_colors = $user->themeColors;
        $page_title   = $user->display_name . " | Uplan photography & Measuring";
        if ($user) {
            return view('frontend.profile', compact('user', 'theme_colors', 'page_title'));
        } else {
            abort(404);
        }
    }

    public function contact($user_name)
    {
        $user         = User::whereUserName($user_name)->with('office')->first();
        $theme_colors = $user->themeColors;
        $page_title   = "Contact " . $user->display_name . " | Uplan photography & Measuring";
        if ($user) {
            return view('frontend.contact', compact('user', 'theme_colors', 'page_title'));
        } else {
            abort(404);
        }
    }

    public function property($user_name, $story_board)
    {

        $user         = User::whereUserName($user_name)->first();
        $theme_colors = $user->themeColors;
        $storyBoard   = StoryBoard::whereUserId($user->id)->whereSlug($story_board)->with(['user', 'bannerImages', 'boardGalleries'])->first();

        $flickr_photos = [];
        if ($storyBoard->flickr_photo_set_id) {
            // $flickr_photos = $this->flickrApi($storyBoard->flickr_photo_set_id);
            $flickr_photos = $this->getOriginImage($storyBoard->flickr_photo_set_id);
        }
        $AllStoryBoards = StoryBoard::whereUserId($user->id)->where('id', '!=', $storyBoard->id)->take(4)->get();
        foreach ($AllStoryBoards as $key => $AllStoryBoard) {
            if ($AllStoryBoard->flickr_photo_set_id) {
                $AllStoryBoard['flickr_first_photo'] = $this->flickrApiFirstImage($AllStoryBoard->flickr_photo_set_id);
            }
        }

        $page_title = $storyBoard->PropertyAddress . ' | Uplan photography & Measuring';
        if ($storyBoard) {
            return view('frontend.property', compact('storyBoard', 'user', 'AllStoryBoards', 'theme_colors', 'page_title', 'flickr_photos'));
        } else {
            abort(404);
        }
    }

    public function getDistance(Request $request)
    {
        // return $request->all();

        $latitudeFrom  = $request->location_lat;
        $longitudeFrom = $request->location_long;

        $latitudeTo  = $request->property_lat;
        $longitudeTo = $request->property_long;

        //Calculate distance from latitude and longitude
        $theta = $longitudeFrom - $longitudeTo;
        $dist  = sin(deg2rad($latitudeFrom)) * sin(deg2rad($latitudeTo)) + cos(deg2rad($latitudeFrom)) * cos(deg2rad($latitudeTo)) * cos(deg2rad($theta));
        $dist  = acos($dist);
        $dist  = rad2deg($dist);
        $miles = $dist * 60 * 1.1515;

        // convate Km
        $distance = ($miles * 1.609344);

        // walking time count
        $walk    = number_format($distance / 5, 1);
        $driving = number_format($distance / 60, 1);
        $cycle   = number_format($distance / 15, 1);
        return response()->json(['walk' => $walk, 'driving' => $driving, 'cycle' => $cycle]);
    }

    public function viewReset()
    {
        return view('reset_password');
    }

    public function sendMessage(Request $request)
    {
        $request->validate([
            'name'       => 'required|string',
            'from_email' => 'required|email',
        ]);

        Mail::to($request->to_email)->later(now()->addSeconds(5), new ContactMail($request->all()));

        sendFlash('Mail Send Successfully!!!');
        return back();
    }

    public function updateStoryBoard(Request $request)
    {

        // return $request->all();
        $storyboard = StoryBoard::whereSlug($request->storyboard_slug)->first();

        if ($storyboard) {
            $storyboard->update([
                'property_price' => str_replace(',', '', str_replace('$', '', $request->property_price)),
                'about_property' => $request->about_property,
                'year'           => $request->build_year,
                'square_feets'   => str_replace(',', '', $request->square_feets),
                'bedroom'        => $request->bedroom,
                'bathroom'       => $request->bathroom,
                'show_about'     => isset($request->show_about) ? 1 : $storyboard->show_about,
            ]);
            sendFlash('Story board Update Successfully');
            return back();
        } else {
            sendFlash('Story board Not Found!!');
            return back();
        }
    }
}
