<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Mail\RestPasswordMail;
use App\Models\User;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Ramsey\Uuid\Uuid;

class LoginController extends Controller
{
    public function login()
    {
        if((auth()->check())){
            if (auth()->user()->user_type==1) {
                return redirect(route('admin.dashboard'));
            }else{
                return redirect(route('client.dashboard'));
            }
        }else{
            return view('login');
        }
    }

    public function submitLogin(Request $request)
    {
        $request->validate([
            'email'=>'required|email',
            'password'=>'required|min:8'
        ]);

        $admin=$request->only(['email','password']);
        if (auth()->attempt($admin,true)) {
            sendFlash("You are successfully login.");
            if (auth()->user()->user_type==1) {
                return redirect(route('admin.dashboard'));
            }else{
                return redirect(route('client.dashboard'));
            }
        } else {
            sendFlash("We can't found you",'error');
            return view('login');
        }
    }

    public function systemSubmitLogin(Request $request)
    {
        $request->validate([
            'email'=>'required|email',
            'password'=>'required|min:8'
        ]);

        $admin=$request->only(['email','password']);
        if (auth()->attempt($admin,true)) {
            sendFlash("You are successfully login.");
            if (auth()->user()->user_type==1) {
                return back();
            }else{
               return back();
            }
        } else {
            sendFlash("We can't found you",'error');
            return view('login');
        }
    }

    public function logout(){
        auth()->logout();
        sendFlash("Successfully Logout");
        return redirect(route('home'));
    }

    public function logoutfrontend()
    {
        auth()->logout();
        sendFlash("Successfully Logout");
        return back();
    }

    public function resetPassword(Request $request)
    {
        $request->validate([
            'email'=>'required|email|string'
        ]);


        $user=User::whereEmail($request->email)->first();
        if ($user) {
            $uuid=Uuid::uuid4();
            $user->update([
                'remember_token'=>$uuid
            ]);

            Mail::to($request->email)->later(now()->addSeconds(5), new RestPasswordMail($uuid));
            sendFlash("We send a mail please check you mail.");
            return back();
        }else{
            sendFlash("We Can't Found You!!!",'error');
            return back();
        }
    }

    public function setNewPassword($uu_id)
    {
        $user=User::whereRememberToken($uu_id)->first();
        if ($user) {
            $uu_id=$uu_id;
            return view('set_new_password',compact('uu_id'));
        }else{
            sendFlash("We Can't Found You!!!",'error');
            return redirect()->route('reset.password');
        }
    }

    public function createNewPassword(Request $request,$uuid)
    {
        $request->validate([
            'password'=>'required|min:8|confirmed',
        ]);

        $user=User::whereRememberToken($uuid)->first();
        if ($user) {
            $user->update([
                'password'=>Hash::make($request->password),
                'remember_token'=>Uuid::uuid4()
            ]);
            sendFlash("Password Change Successfully.");
            return redirect()->route('home');
        }else{
            sendFlash("We Can't Found You!!!",'error');
            return redirect()->route('reset.password');
        }
    }

}
