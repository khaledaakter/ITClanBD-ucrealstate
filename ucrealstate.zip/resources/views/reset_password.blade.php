
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  @include('admin.layouts._head')
</head>
<body>
  <form method="POST" action="{{ route('send.reset.password') }}">
    @csrf

    <div class="auth-wrapper">
      <div class="auth-content container">
        <div class="card">
          <div class="row align-items-center">
            <div class="col-md-6">
              <div class="card-body">
                @if (Settings::get('logo'))
                    <img src="{{ Storage::url(Settings::get('logo')) }}" alt="" class="img-fluid mb-4">
                @else
                    <img src="{{ asset('dashboard/assets/images/logo.svg') }}" alt="" class="img-fluid mb-4">
                @endif
                <h4 class="mb-3 f-w-400">Reset Password</h4>
                <div class="form-group mb-2">
                  <label class="form-label">Enter Email</label>
                  <input type="email" name="email" class="form-control" placeholder="name@sitename.com">
                  @error('email')
                    <span class="text-danger">{{ $message }}</span>
                  @enderror
                </div>
                <button class="btn btn-primary mb-4">Reset Password</button>
                <a href="{{ route('home') }}" class="btn btn-info mb-4 text-white">Login</a>
              </div>
            </div>
            <div class="col-md-6 d-none d-md-block">
              @if (Settings::get('login_image'))
                  <img src="{{ Storage::url(Settings::get('login_image')) }}" alt="" class="img-fluid">
              @else
                  <img src="{{ asset('dashboard/assets/images/login.jpg') }}" alt="" class="img-fluid">
              @endif
            </div>
          </div>
        </div>
      </div>
    </div>
  </form>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
  <script type="text/javascript">
    $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
    @if(Session::has('success'))
        toastr.success("{{ Session::get('success') }}");
      @endif
    @if(Session::has('error'))
      toastr.error("{{ Session::get('error') }}");
    @endif
  </script>  
  @include('admin.layouts._script')
</body>
</html>
