@if (Settings::get('title'))
	<title>{{ Settings::get('title') }}</title>
@else
	<title>Uplan.co</title>
@endif
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<!-- Favicon icon -->
@if (Settings::get('fabicon'))
<link rel="icon" href="{{Storage::url(Settings::get('fabicon'))}}" type="image/x-icon">
@else
<link rel="icon" href="{{asset('dashboard/assets/images/favicon.svg')}}" type="image/x-icon">
@endif
<!-- fontawesome icon -->
<link rel="stylesheet" href="{{asset('dashboard/assets/fonts/fontawesome/css/fontawesome-all.min.css')}}">
<!-- animation css -->
<link rel="stylesheet" href="{{asset('dashboard/assets/plugins/animation/css/animate.min.css')}}">


<!-- notification css -->
<link rel="stylesheet" href="{{asset('dashboard/assets/plugins/notification/css/notification.min.css')}}">

<!-- data tables css -->
<link rel="stylesheet" href="{{asset('dashboard/assets/plugins/data-tables/css/datatables.min.css')}}">

<!-- select2 css -->
<link rel="stylesheet" href="{{asset('dashboard/assets/css/plugins/select2.min.css')}}">

<!-- vendor css -->
<link rel="stylesheet" href="{{asset('dashboard/assets/css/app.css')}}">
<link rel="stylesheet" href="{{asset('dashboard/assets/css/style.css')}}">
{{-- toster Notification --}}
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
@yield('css')

@yield('style')
