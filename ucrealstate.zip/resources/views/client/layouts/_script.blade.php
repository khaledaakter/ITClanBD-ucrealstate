<!-- Required Js -->
<script src="{{ asset('dashboard/assets/js/vendor-all.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/plugins/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/js/ic-coded.min.js') }}"></script>

<!-- all plugin js here -->
<script src="{{ asset('dashboard/assets/js/app.js') }}"></script>
<script src="{{ asset('dashboard/assets/js/custom-datatable.js') }}"></script>

<!-- custom js -->
<script src="{{ asset('dashboard/assets/js/custom.js') }}"></script>
@yield('js')
{{-- Toster Notification --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
{{-- Sweet alert 2 --}}
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script type="text/javascript">
  $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
  @if(Session::has('success'))
      toastr.success("{{ Session::get('success') }}");
  @endif
  @if(Session::has('error'))
    toastr.error("{{ Session::get('error') }}");
  @endif


  function makeDeleteRequest(e,row_id){
    e.preventDefault();
    Swal.fire({
      title: 'Are you sure?',
      text: '',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        $(`#delete-form-${row_id}`).submit();
      }
    });

  }


  function systemLogout(e){
    e.preventDefault();
    Swal.fire({
      title: 'Are you sure?',
      text: '',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Logout it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        window.location ="{{ route('logout') }}";
      }
    });
  }


  function makeRestore(e,row_id){
    e.preventDefault();
    Swal.fire({
      title: 'Are you sure?',
      text: '',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Restore it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        $(`#restore-form-${row_id}`).submit();
      }
    });
  }
  
</script>

@yield('script')