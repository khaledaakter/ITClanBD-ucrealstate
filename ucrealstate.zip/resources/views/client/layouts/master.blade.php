<!DOCTYPE html>
<html lang="en">

<head>
    @include('client.layouts._head')
</head>

<body class="">
    <!-- [ Pre-loader ] start -->
    {{-- <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div> --}}
    <!-- [ Pre-loader ] End -->
<!-- [ navigation menu ] start -->
@include('client.layouts._nav')
<!-- [ navigation menu ] end -->

<!-- [ Header ] start -->
@include('client.layouts._header')
<!-- [ Header ] end -->

@yield('content')


@include('client.layouts._script')

</body>

</html>