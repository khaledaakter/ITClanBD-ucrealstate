<!DOCTYPE html>
<html lang="en">

<head>
    @if (Settings::get('title'))
    	<title>{{ Settings::get('title') }}</title>
    @else
    	<title>Uplan.co</title>
    @endif
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Favicon icon -->
    @if (Settings::get('fabicon'))
    <link rel="icon" href="{{Storage::url(Settings::get('fabicon'))}}" type="image/x-icon">
    @else
    <link rel="icon" href="{{asset('dashboard/assets/images/favicon.svg')}}" type="image/x-icon">
    @endif
    <!-- fontawesome icon -->
    <link rel="stylesheet" href="{{asset('dashboard/assets/fonts/fontawesome/css/fontawesome-all.min.css')}}">
    <!-- animation css -->
    <link rel="stylesheet" href="{{asset('dashboard/assets/plugins/animation/css/animate.min.css')}}">


    <!-- notification css -->
    <link rel="stylesheet" href="{{asset('dashboard/assets/plugins/notification/css/notification.min.css')}}">

    <!-- data tables css -->
    <link rel="stylesheet" href="{{asset('dashboard/assets/plugins/data-tables/css/datatables.min.css')}}">

    <!-- select2 css -->
    <link rel="stylesheet" href="{{asset('dashboard/assets/css/plugins/select2.min.css')}}">

    <!-- vendor css -->
    <link rel="stylesheet" href="{{asset('dashboard/assets/css/app.css')}}">
    <link rel="stylesheet" href="{{asset('dashboard/assets/css/style.css')}}">
    {{-- toster Notification --}}
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    @yield('css')

    @yield('style')
</head>

<body class="">
   
   <nav class="ic-navbar menupos-fixed menu-dark menu-item-icon-style6 " style="background:none;">
       <div class="navbar-wrapper ">
           <div class="navbar-brand header-logo">
               <a href="{{ route('agent.profile',[auth()->user()->user_name]) }}" class="b-brand">
                   {{-- @if (Settings::get('logo'))
                       <img src="{{ Storage::url(Settings::get('logo')) }}" alt="" class="logo images">
                   @else
                       <img src="{{ asset('dashboard/assets/images/logo.svg') }}" alt="" class="logo images">
                   @endif --}}
				   
                   @if (auth()->user()->logo)
                       <img src="{{ Storage::url(auth()->user()->logo) }}" alt="" class="logo images">
                   @else
				   <h4 style="color:{{ auth()->user()->themeColors[0]->color??'#000' }}">{{ auth()->user()->full_name }}</h4>
                   @endif

                   @if (Settings::get('fabicon'))
                       <img src="{{ Storage::url(Settings::get('fabicon')) }}" alt="" class="logo-thumb images">
                   @else
                       <img src="{{ asset('dashboard/assets/images/favicon.svg') }}" alt="" class="logo-thumb images">
                   @endif
               </a>
               {{-- <a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a> --}}
           </div>

       </div>
   </nav>

	<header class="navbar ic-header navbar-expand-lg navbar-light headerpos-fixed">
	    <div class="m-header">
	        <a class="mobile-menu" id="mobile-collapse1" href="#!"><span></span></a>
	        <a href="index.html" class="b-brand">
	            <!-- <div class="b-bg">
							<i class="fas fa-bolt"></i>
						</div> 
						<span class="b-title">Dasho</span> -->
	            <img src="assets/images/logo.svg" alt="" class="logo images">
	            <!-- <img src="assets/images/logo-icon.svg" alt="" class="logo-thumb images"> -->
	        </a>
	    </div>
	    <a class="mobile-menu" id="mobile-header" href="#!">
	        <i class="feather icon-more-horizontal"></i>
	    </a>
	    <div class="collapse navbar-collapse">
	        <a href="#!" class="mob-toggler"></a>
	        {{-- <ul class="navbar-nav mr-auto">
	            <li class="nav-item">
	                <div class="main-search open">
	                    <div class="input-group">
	                        <input type="text" id="m-search" class="form-control" placeholder="Search . . .">
	                        <a href="#!" class="input-group-append search-close">
	                            <i class="feather icon-x input-group-text"></i>
	                        </a>
	                        <span class="input-group-append search-btn btn btn-primary">
	                            <i class="feather icon-search input-group-text"></i>
	                        </span>
	                    </div>
	                </div>
	            </li>
	        </ul> --}}
	        <ul class="navbar-nav ml-auto">
	            <li>
	                <div class="dropdown drp-user">
	                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
	                        <i class="icon feather icon-settings"></i>
	                    </a>
	                    <div class="dropdown-menu dropdown-menu-right profile-notification">
	                        <div class="pro-head">
	                            @if (auth()->user()->photo)
	                                <img src="{{ Storage::url(auth()->user()->photo) }}" class="img-radius" alt="User-Profile-Image">
	                            @else
	                                <img src="{{ asset('dashboard/assets/images/user/default-user.jpg') }}" class="img-radius" alt="User-Profile-Image">
	                            @endif
	                            
	                            <span>
	                                <span class="text-muted">{{ auth()->user()->first_name }}</span>
	                                <span class="h6">{{ auth()->user()->email }}</span>
	                            </span>
	                        </div>
	                        <ul class="pro-body">
	                            <li><a href="{{ route('client.edit_profile') }}" class="dropdown-item"><i class="feather icon-user"></i> Profile</a></li>
	                            <li><a href="{{ route('logout') }}" class="dropdown-item"><i class="feather icon-power text-danger"></i>Logout</a></li>
	                        </ul>
	                    </div>
	                </div>
	            </li>
	        </ul>
	    </div>
	</header>

@yield('content')


<!-- Required Js -->
<script src="{{ asset('dashboard/assets/js/vendor-all.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/plugins/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('dashboard/assets/js/ic-coded.min.js') }}"></script>

<!-- all plugin js here -->
<script src="{{ asset('dashboard/assets/js/app.js') }}"></script>
<script src="{{ asset('dashboard/assets/js/custom-datatable.js') }}"></script>

<!-- custom js -->
<script src="{{ asset('dashboard/assets/js/custom.js') }}"></script>
@yield('js')
{{-- Toster Notification --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
{{-- Sweet alert 2 --}}
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

</body>

</html>