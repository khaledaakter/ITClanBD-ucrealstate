<nav class="ic-navbar menupos-fixed menu-dark menu-item-icon-style6 ">
    <div class="navbar-wrapper ">
        <div class="navbar-brand header-logo">
            <a href="{{ route('client.dashboard') }}" class="b-brand">
                {{-- @if (Settings::get('logo'))
                    <img src="{{ Storage::url(Settings::get('logo')) }}" alt="" class="logo images">
                @else
                    <img src="{{ asset('dashboard/assets/images/logo.svg') }}" alt="" class="logo images">
                @endif --}}
                @if (auth()->user()->logo)
                    <img src="{{ Storage::url(auth()->user()->logo) }}" alt="" class="logo images">
                @else
                    <h4>{{ auth()->user()->full_name }}</h4>
                @endif

                @if (Settings::get('fabicon'))
                    <img src="{{ Storage::url(Settings::get('fabicon')) }}" alt="" class="logo-thumb images">
                @else
                    <img src="{{ asset('dashboard/assets/images/favicon.svg') }}" alt="" class="logo-thumb images">
                @endif
            </a>
            <a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a>
        </div>
        <div class="navbar-content scroll-div">

            <ul class="nav ic-inner-navbar ">
                <li data-username="documentation" class="nav-item">
                    <a href="{{ route('client.dashboard') }}" class="nav-link">
                        <span class="ic-micon">
                            <i class="fas fa-home"></i>
                        </span>
                        <span class="pcoded-mtext">Dashboard</span>
                    </a>
                </li>

                @canany(['Client Edit StoryBoard','Client Show StoryBoard'])
                <li data-username="vertical" class="nav-item ic-hasmenu">
                    <a href="#" class="nav-link"><span class="ic-micon"><i class="feather icon-edit-1"></i></span><span class="ic-mtext">Storyboard</span></a>
                    <ul class="ic-submenu">
                        <li class=""><a href="{{ route('client.storyboard.index') }}" class="">Storyboard List</a></li>
                    </ul>
                </li>
                @endcanany
                
                @canany(['Client Add Note','Client Edit Note','Client Show Note','Client Delete Note','Client Trashed Note'])
                <li data-username="vertical" class="nav-item ic-hasmenu">
                    <a href="#" class="nav-link"><span class="ic-micon"><i class="far fa-clipboard"></i></span><span class="ic-mtext">Note</span></a>
                    <ul class="ic-submenu">

                        @can('Client Add Note')
                            <li class=""><a href="{{ route('client.note.create') }}" class="">Add Note</a></li>
                        @endcan
                        
                        @can('Client Show Note')
                            <li class=""><a href="{{ route('client.note.index') }}" class="">Note List</a></li>
                        @endcan

                        @can('Client Trashed Note')
                            <li class=""><a href="{{ route('client.note.trashed') }}" class="">Trashed Note List</a></li>
                        @endcan

                    </ul>
                </li>
                @endcanany

                <li data-username="documentation" class="nav-item">
                    <a href="{{ route('client.edit_profile') }}" class="nav-link">
                        <span class="ic-micon">
                            <i class="far fa-user"></i>
                        </span>
                        <span class="pcoded-mtext">Profile</span>
                    </a>
                </li>

                <li data-username="documentation" class="nav-item">
                    <a href="javascript:void(0)" onclick="systemLogout(event)" class="nav-link">
                        <span class="ic-micon">
                            <i class="fas fa-power-off text-danger"></i>
                        </span>
                        <span class="pcoded-mtext">Logout</span>
                    </a>
                </li>

            </ul>

        </div>
    </div>
</nav>