@extends('client.layouts.master')

@section('content')

<div class="ic-main-container">
	<div class="ic-wrapper">
		<div class="ic-content">
			<div class="ic-inner-content">
				<div class="main-body">
					<div class="page-wrapper">
						<div class="page-header">
							<div class="page-block">
								<div class="row align-items-center">
									<div class="col-md-12">
										<div class="page-header-title">
											<h5>Update Information</h5>
										</div>
										<ul class="breadcrumb">
											<li class="breadcrumb-item"><a href="#"><i class="far fa-clipboard"></i></a></li>
											<li class="breadcrumb-item"><a href="#">Update Information</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- [ breadcrumb ] end -->

						<!-- [ Main Content ] start -->
						<div class="ic-main-wrapper">
							<form action="{{ route('client.note.update',[$note->id]) }}" method="POST" enctype="multipart/form-data">
								@csrf
								@method('PUT')
								
								<div class="row">
									<div class="col-xl-6 col-md-6">
										<div class="card">
											<div class="card-body">
												<div class="form-group">
													<label for="">Title #</label>
													<input type="text" name="title" value="{{ $note->title }}" class="form-control" placeholder="Note Title">
													@error('title')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
												<div class="form-group">
													<label for="">Note </label>
													<textarea name="note" class="form-control" id="" cols="5" rows="7" placeholder="Note">{{ $note->note }}</textarea>
													@error('note')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
											</div>
										</div>
									</div>
								</div>
								<button class="btn btn-primary mr-2">Update</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



@endsection