@extends('client.layouts.master')


@section('content')

<!-- [ Main Content ] start -->
<div class="ic-main-container">
	<div class="ic-wrapper">
		<div class="ic-content">
			<div class="ic-inner-content">
				<div class="main-body">
					<div class="page-wrapper">
						<!-- [ breadcrumb ] start -->
						<div class="page-header">
							<div class="page-block">
								<div class="row align-items-center">
									<div class="col-md-12">
										<div class="page-header-title">
											<h5>Home</h5>
										</div>
										<ul class="breadcrumb">
											<li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
											<li class="breadcrumb-item"><a href="#!">Analytics Dashboard</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- [ breadcrumb ] end -->

						<!-- [ Main Content ] start -->
						{{-- <div class="row">
							<div class="col-xl-12">
								<div class="card">
									<div class="card-body table-border-style">
										<div class="row">
											@foreach($storyBoards as $key=>$storyBoard)
												<div class="col-md-4 mt-2">
													<img src="{{ Storage::url($storyBoard->boardGalleries[0]->image) }}" style="width: 100%;" alt="">
												</div>
												<div class="col-md-8">
													<p>{{ $storyBoard->property_address }}</p>
													<p><a href="{{ route('client.property.gallery',[$storyBoard->slug]) }}"><i class="fas fa-images"></i></a></p>
													<p><a href="{{ route('client.property.video',[$storyBoard->slug]) }}"><i class="far fa-play-circle"></i></a></p>
													<p><a href="{{ route('client.property.property_plan',[$storyBoard->slug]) }}"><i class="far fa-building"></i></a></p>
												</div>
											@endforeach
										</div>
									</div>
								</div>
							</div>
						</div> --}}
						<!-- [ Main Content ] end -->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<!-- [ Main Content ] end -->
@endsection