@extends('client.layouts.master')


@section('content')

<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-12">
                                        <div class="page-header-title">
                                            <h5>Story Board List</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#"><i class="fas fa-user-tie"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#">Story Board List</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->

                        <!-- [ Main Content ] start -->
                        <div class="row">
                            <!-- Column Rendering table start -->
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Story Board List</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive dt-responsive">
                                            <table id="colum-rendr" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Sl.</th>
                                                        <th>CLIENT</th>
                                                        <th>ADDRESS</th>
                                                        <th>DATE</th>
                                                        <th>PROGRESS</th>
                                                        <th>STATUS</th>
                                                        @can('Client Edit StoryBoard')
                                                        <th>Action</th>
                                                        @endcan
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @php
                                                        $i=1;
                                                    @endphp
                                                    @foreach ($storyBoareds as $storyBoared)
                                                        <tr>
                                                            <td>{{ $i++ }}</td>
                                                            <td>{{ $storyBoared->user->full_name }}</td>
                                                            <td><a href="{{ route('show.property',[auth()->user()->user_name,$storyBoared->slug]) }}" target="_blank">{{ $storyBoared->property_address }}</a></td>
                                                            <td>{{ $storyBoared->created_at_format }}</td>
                                                            <td>
                                                                <p class="{{ $storyBoared->status==1?'text-primary':'' }}">
                                                                    @if (count($storyBoared->boardGalleries)>0)
                                                                        P
                                                                    @endif
                                                                    @if ($storyBoared->p_video_link)
                                                                        V
                                                                    @endif
                                                                    @if ($storyBoared->p_floor_plan)
                                                                        F
                                                                    @endif
                                                                    @if ($storyBoared->p_metterport)
                                                                        M
                                                                    @endif
                                                                </p>
                                                            </td>
                                                            <td>
                                                                {!! $storyBoared->story_board_status !!}
                                                            </td>
                                                            @can('Client Edit StoryBoard')
                                                            <td>
                                                                <div class="dropdown">
                                                                  <button class="btn btn-default dropdown-toggle btn-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    ...
                                                                  </button>
                                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                      <a class="dropdown-item" href="{{ route('client.storyboard.edit',[$storyBoared->slug]) }}"><i class="fas fa-edit text-success"></i> Edit</a>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            @endcan
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection

@section('script')



@endsection