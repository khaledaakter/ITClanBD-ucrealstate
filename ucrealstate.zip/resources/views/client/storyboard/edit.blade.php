@extends('client.layouts.master')


@section('content')

<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-12">
                                        <div class="page-header-title">
                                            <h5>Story Board Update</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#"><i class="fas fa-user-tie"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#">Story Board Update</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->

                        <!-- [ Main Content ] start -->
                        <div class="row">
                            <!-- Column Rendering table start -->
                            <div class="col-xl-12">
                           <form action="{{ route('client.storyboard.update',[$storyBoard->slug]) }}" method="POST" enctype="multipart/form-data">
                               @csrf
                               
                               <div class="card">
                                   <div class="card-body">
                                       <div class="row">
                                           <div class="col-lg-6">
                                           
                                               <div class="ic-banner-part">
                                                   <h5>About Part</h5>

                                                   <div class="custom-control custom-checkbox float-right">
                                                       <input type="checkbox" {{ $storyBoard->show_about==1?'checked':'' }} name="show_about" class="custom-control-input" value="1" id="customCheck1">
                                                       <label class="custom-control-label" for="customCheck1">Show</label>
                                                   </div>

                                                   <div class="form-group">
                                                       <label for="propertyamount">Property Amount</label>
                                                       <input type="number" placeholder="Property Amount" value="{{ $storyBoard->property_price }}" name="property_price" class="form-control">
                                                   </div>
                                                   <div class="form-group">
                                                       <label for="aboutText">About Text</label>
                                                       <textarea name="about_property" id="aboutProperty" class="form-control"  placeholder="About text">{!! $storyBoard->about_property !!}</textarea>
                                                   </div>
                                                   <div class="form-group">
                                                       <label for="">Property Image</label>
                                                       <input type="file" name="property_image" class="form-control">    
                                                   </div>
                                                   <div class="ic-banner-img">
                                                       <div class="ic-images-div">
                                                           @if ($storyBoard->property_image)
                                                               <div class="ic-images-items">
                                                                   <div class="ic-items-img">
                                                                       <img src="{{ Storage::url( $storyBoard->property_image ) }}" class="img-fluid" alt="images">
                                                                       <div class="ic-overlay">
                                                                           <a href="#" onclick="deleteStoryBoardFile(event,'{{ $storyBoard->id }}','property_image')" class="img-closed"> <i class="far fa-times-circle"></i></a>
                                                                       </div>
                                                                   </div>
                                                               </div>
                                                           @endif
                                                       </div>
                                                   </div>
                                               </div> 
                                               
                                               <div class="ic-banner-part">
                                                   <h5>About Card</h5>
                                                   <div class="ic-about-card p-2 border">
                                                       <div class="form-group">
                                                           <label for="aboutYear">Yera Of Build year</label>
                                                           <input type="number" placeholder="About Icons" name="year" value="{{ $storyBoard->year }}" class="form-control">
                                                       </div>
                                                       <div class="form-group">
                                                           <label for="SquareYear">Square Feets</label>
                                                           <input type="number" placeholder="Square Feets" name="square_feets" value="{{ $storyBoard->square_feets }}" class="form-control">
                                                       </div>

                                                       <div class="form-group">
                                                           <label for="BedroomsYear">Bedrooms Number</label>
                                                           <input type="number" placeholder="Bedrooms Number" name="bedroom" value="{{ $storyBoard->bedroom }}" class="form-control">
                                                       </div>
                                                       <div class="form-group">
                                                           <label for="BedroomsYear">Bathrooms Number</label>
                                                           <input type="number" placeholder="Bathrooms Number" name="bathroom" value="{{ $storyBoard->bathroom }}" class="form-control">
                                                       </div>
                                                   </div>
                                               </div>

                                               <div class="ic-button-submit">
                                                   <button class="btn btn-primary mr-2">Update</button>
                                               </div>

                                           </div>
                                       </div>
                                   </div>
                               </div>
                           </form>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection

@section('css')
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
@endsection

@section('js')
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
@endsection

@section('script')

<script>

    $(document).ready(function() {
      $('#aboutProperty').summernote();
    });

    function deleteStoryBoardFile(e,file_id,name){
      e.preventDefault();
      Swal.fire({
        title: 'Are you sure?',
        text: '',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, keep it'
      }).then((result) => {
        if (result.value) {
          $.ajax({
            url:"{{ route('client.storyboard.delete-file') }}",
            method:"GET",
            data:{
                story_board_id:file_id,
                field_name:name
            },
            success:function(response){
                // console.log(response);
                if (response.message) {
                    toastr.success(response.message);
                    setTimeout(function(){ 
                        location.reload();
                    }, 2000);
                }else{
                    toastr.error("Something is Problem");
                }
            },
            error:function(error){
                console.log(error);
            }
          });
        }
      });
    }
</script>
@endsection