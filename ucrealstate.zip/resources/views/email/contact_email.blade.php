<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Contact Mail</title>
</head>
<body>
	<span> <strong>Name: {{ $name }}</strong> </span><br>
	<span> <strong>Phone: {{ $phone }}</strong> </span><br>
	<span> <strong>Email: {{ $email }}</strong> </span><br>
	@if($address!=null)
	<span> <strong>Address: {{ $address }}</strong> </span><br>
	@endif
	<span> <strong>Message:</strong> {{ $mess }} </span>
</body>
</html>