@extends('admin.layouts.master')


@section('content')

<div class="ic-main-container">
	<div class="ic-wrapper">
		<div class="ic-content">
			<div class="ic-inner-content">
				<div class="main-body">
					<div class="page-wrapper">
						<!-- [ breadcrumb ] start -->
						<div class="page-header">
							<div class="page-block">
								<div class="row align-items-center">
									<div class="col-md-12">
										<div class="page-header-title">
											<h5>Register Office</h5>
										</div>
										<ul class="breadcrumb">
											<li class="breadcrumb-item"><a href="index.html"><i class="feather icon-users"></i></a></li>
											<li class="breadcrumb-item"><a href="#!">Register Office</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- [ breadcrumb ] end -->

						<!-- [ Main Content ] start -->
						<div class="ic-main-wrapper">
							<form action="{{ route('admin.office.store') }}" method="POST" enctype="multipart/form-data">
								@csrf

								<div class="row">
									<div class="col-xl-6">
										<div class="card">
											<div class="card-body">

												<div class="row">
													<div class="col-md-12">
														<div class="form-group">
															<label for="">Office Name #</label>
															<input type="text" name="name" class="form-control" value="{{ old('name') }}" placeholder="Office Name">
															@error('name')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-3">
														<div class="form-group">
															<label>Unit</label>
															<input type="text" name="unit" class="form-control" value="{{ old('unit') }}" placeholder="Unit">
															@error('unit')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>
													<div class="col-md-3">
														<div class="form-group">
															<label>Road Number</label>
															<input type="text" name="road_number" class="form-control" value="{{ old('road_number') }}" placeholder="Road Number">
															@error('road_number')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>
													<div class="col-md-3">
														<div class="form-group">
															<label>Road Name</label>
															<input type="text" name="road_name" class="form-control" value="{{ old('road_name') }}" placeholder="Road Name">
															@error('road_name')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>
													<div class="col-md-3">
														<div class="form-group">
															<label>Road Type</label>
															<select name="road_type" id="" class="form-control select2">
																	<option value="">Select Road Type</option>
																@foreach($road_types as $key=>$road_type)
																	<option value="{{ $road_type }}">{{ $road_type }}</option>
																@endforeach
															</select>
															@error('road_type')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-4">
														<div class="form-group">
															<label for="">Country #</label>
															<select name="country" onchange="selectCountry($(this).find(':selected').val())" class="js-example-basic-single form-control">
																	<option value="">Select Country</option>
																@foreach($countries as $key=>$country)
																	<option value="{{ $country->id }}">{{ $country->name }}</option>
																@endforeach
															</select>
															@error('country')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>
													<div class="col-md-4">
														<div class="form-group">
															<label for="">State #</label>
															<select name="state" onchange="selectState($(this).find(':selected').val())" class="select-state form-control">
																<option value="">Select State</option>
															</select>
															@error('state')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>
													<div class="col-md-4">
														<div class="form-group">
															<label for="">City #</label>
															<select name="city" class="select-city form-control">
																<option value="">Select City</option>
															</select>
															@error('city')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-12">
														{{-- Location --}}
														<div class="form-group">
														    <div class="form-group">
														        <label for="videoLink">Location</label>
														        <input type="text" placeholder="Location" id="autocomplete-input" name="location" value="{{ old('location') }}" class="form-control" autocomplete="off">
														    </div>

														    <input type="hidden" id="locationLat" name="latitude" class="form-control" value="{{ old('latitude') }}" >
														    <input type="hidden" id="locationLng" name="longitude" class="form-control" value="{{ old('longitude') }}">
														</div>
													</div>

													<div class="col-md-12">
														<div class="form-group">
															<label for="">Logo</label>
															<input type="file" name="logo" class="form-control">
														</div>
													</div>
												</div>
											</div>	
										</div>	
									</div>	
								</div>	

								{{-- <div class="row">
									<div class="col-xl-6">
										<div class="card">
											<div class="card-body">
												<div class="form-group">
													<label for="">Office Name #</label>
													<input type="text" name="name" class="form-control" value="{{ old('name') }}" placeholder="Office Name">
													@error('name')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
												<div class="form-group">
													<label for="">Country #</label>
													<select name="country" onchange="selectCountry($(this).find(':selected').val())" class="js-example-basic-single form-control">
															<option value="">Select Country</option>
														@foreach($countries as $key=>$country)
															<option value="{{ $country->id }}">{{ $country->name }}</option>
														@endforeach
													</select>
													@error('country')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
												<div class="form-group">
													<label for="">State #</label>
													<select name="state" onchange="selectState($(this).find(':selected').val())" class="select-state form-control">
														<option value="">Select State</option>
													</select>
													@error('state')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>

												<div class="form-group">
													<label for="">City #</label>
													<select name="city" class="select-city form-control">
														<option value="">Select City</option>
													</select>
													@error('city')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>

												<div class="form-group">
													<label for="">Unit</label>
													<input type="text" name="unit" value="{{ old('unit') }}" class="form-control" placeholder="Unit">
												</div>
												<div class="form-group">
													<label for="">Street Number</label>
													<input type="text" name="street_number" value="{{ old('street_number') }}" class="form-control" placeholder="Street Number">
												</div>
												<div class="form-group">
													<label for="">Street Name</label>
													<input type="text" name="street_name" value="{{ old('street_name') }}" class="form-control" placeholder="Street Name">
												</div>
												<div class="form-group">
													<label for="">Postal Code</label>
													<input type="text" name="postal_code" value="{{ old('postal_code') }}" class="form-control" placeholder="Postal Code">
												</div>

												<div class="form-group">
													<label for="">Phone Number</label>
													<input type="number" name="phone" value="{{ old('phone') }}" class="form-control" placeholder="Number">
												</div>

												<div class="form-group">
													<label for="">Note</label>
													<textarea name="note" class="form-control" id="" cols="4" rows="3">{{ old('note') }}</textarea>
												</div>
											</div>
										</div>
									</div>
								</div> --}}
								<div class="row">
									<div class="col-md-6">
										<button class="btn btn-primary mr-2">Submit</button>
									</div>
								</div>
								
							</form>
						</div>
						<!-- [ Main Content ] end -->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@endsection

@section('js')
<script id="api-key" defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB1taAMFjjJDItj7VVzlvsTvVrixJHHNqc&callback=initMap&libraries=places"></script>
@endsection


@section('script')
<script>
	function selectCountry(country_id)
	{
		$(".select-state").html('').select2({data: [{id:'', text: 'Select State'}]});
		$(".select-city").html('').select2({data: [{id:'', text: 'Select City'}]});
		if (country_id) {
			$.ajax({
				url:"{{ route('admin.office.select-country') }}",
				method:'GET',
				data:{'country_id':country_id},
				success:function(response){
					let states=[];
					states.push({id:'', text: 'Select State'});
					for (var i = 0; i < response.states.length; i++) {
						states.push({id:response.states[i].id, text: response.states[i].name});
					}
					$(".select-state").html('').select2({data: states});
				},
				error:function(error){
					console.log(error);
				}
			});
		}else{
			console.log('not found');
		}
	}

	function selectState(state_id)
	{
		if (state_id) {
			$.ajax({
				url:"{{ route('admin.office.select-state') }}",
				method:"GET",
				data:{'state_id':state_id},
				success:function(response){
					console.log(response.cities);
					let cities=[];
					cities.push({id:'', text: 'Select Cities'});
					for (var i = 0; i < response.cities.length; i++) {
						cities.push({id:response.cities[i].id, text: response.cities[i].name});
					}
					console.log(cities);
					$(".select-city").html('').select2({data: cities});
				},
				error:function(error){
					console.log(error);
				}
			});
		}else{
			console.log('not found');
		}
	}

	// Google autocomplete
	window.onload = function() {
	   initAutocomplete();
	}

	var autocomplete;
	function initAutocomplete(){
	    autocomplete = new google.maps.places.Autocomplete(
	    document.getElementById('autocomplete-input'), {types: ['geocode']});
	    autocomplete.addListener('place_changed', getAddressDetails);
	}
	function getAddressDetails(){
	    var place = autocomplete.getPlace();   
	    window.lat = place.geometry.location.lat();
	    window.long = place.geometry.location.lng();
	    console.log( +'-'+window.long);
	    $('#locationLat').val(window.lat);
	    $('#locationLng').val(window.long);
	}

	function geolocate(){
	  if (navigator.geolocation){
	    navigator.geolocation.getCurrentPosition(function(position){
	      var geolocation = {
	        lat: position.coords.latitude,
	        lng: position.coords.longitude
	      };
	        var circle = new google.maps.Circle(
	        {center: geolocation, radius: position.coords.accuracy});
	        autocomplete.setBounds(circle.getBounds());
	    });
	  }
	}
</script>
@endsection