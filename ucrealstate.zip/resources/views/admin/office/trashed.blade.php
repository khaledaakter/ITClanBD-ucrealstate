@extends('admin.layouts.master')


@section('content')

<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <!-- [ breadcrumb ] start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-12">
                                        <div class="page-header-title">
                                            <h5>Trashed List</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.html"><i class="fas fa-briefcase"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#!">Trashed List</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->

                        <!-- [ Main Content ] start -->
                        <div class="row">
                            <!-- Column Rendering table start -->
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Trashed List</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive dt-responsive">
                                            <table id="colum-rendr" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Sl</th>
                                                        <th>Office Name</th>
                                                        <th>Address</th>
                                                        <th>Street Name</th>
                                                        <th>Phone</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                	@php
                                                		$i=1;
                                                	@endphp
                                                	@foreach($offices as $key=>$office)
                                                    <tr>
                                                        <td>{{ $i++ }}</td>
                                                        <td>{{ $office->name }}</td>
                                                        <td>{{ $office->address }}</td>
                                                        <td>{{ $office->street_name }}</td>
                                                        <td>{{ $office->phone }}</td>
                                                        <td>
                                                            <div class="ic-action-button">
                                                        	<!-- <div class="dropdown show">
                                                        	  <a class="btn btn-default dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        	    ...
                                                        	  </a>
                                                        	  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink"> -->
                                                        	      <a class="dropdown-item" href="javascript:void(0)" onclick="makeRestore(event,'{{ $office->id }}')"><i class="fas fa-reply-all"></i> Restore</a>
                                                                    
                                                                    <form action="{{ route('admin.office.restore',[$office->id]) }}" method="POST" id="restore-form-{{ $office->id }}">
                                                                        @csrf

                                                                    </form>
                                                              <!-- </div>
                                                        	</div> -->
                                                        	</div>
                                                        </td>
                                                    </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('script')
    
@endsection