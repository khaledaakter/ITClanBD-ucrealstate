@extends('admin.layouts.master')


@section('content')

<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <!-- [ breadcrumb ] start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-6">
                                        <div class="page-header-title">
                                            <h5>Office List</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.html"><i class="fas fa-briefcase"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#!">Office List</a></li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <a href="{{ route('admin.office.create') }}" class="btn btn-success btn-sm float-right">Add Office</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->

                        <!-- [ Main Content ] start -->
                        <div class="row">
                            <!-- Column Rendering table start -->
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Client List</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive dt-responsive">
                                            <table id="colum-rendr" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Sl</th>
                                                        <th>Office Name</th>
                                                        <th>Address</th>
                                                        <th>Location</th>
                                                        @canany(['Delete Office'])
                                                        <th>Action</th>
                                                        @endcanany
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                	@php
                                                		$i=1;
                                                	@endphp
                                                	@foreach($offices as $key=>$office)
                                                    <tr>
                                                        <td>{{ $i++ }}</td>
                                                        <td>
                                                        @can('Edit Office')
                                                            <a href="{{ route('admin.office.edit',[$office->id]) }}">{{ $office->name }}</a></td>
                                                        @else
                                                            {{ $office->name }}
                                                        @endcan

                                                        <td>{{ $office->address }}</td>
                                                        <td>{{ $office->location }}</td>
                                                        @canany(['Delete Office'])
                                                            <td>
                                                                <div class="ic-action-button">
                                                                    @can('Delete Office')
                                                                    <a class="dropdown-item btn-danger btn-sm" onclick="makeDeleteRequest(event,'{{ $office->id }}')" href="javascript:void(0)"><i class="far fa-trash-alt"></i> Delete</a>
                                                                        <form action="{{ route('admin.office.destroy',[$office->id]) }}" method="post" id="delete-form-{{ $office->id }}">
                                                                            @csrf
                                                                            @method('DELETE')
                                                                        </form>
                                                                    @endcan
                                                                </div>
                                                            </td>
                                                        @endcanany
                                                    </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('script')

@endsection
