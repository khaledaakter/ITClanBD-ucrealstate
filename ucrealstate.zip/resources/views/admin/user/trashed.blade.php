@extends('admin.layouts.master')


@section('content')

<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-6">
                                        <div class="page-header-title">
                                            <h5>Trashed List</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#"><i class="fas fa-users"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#!">Trashed List</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->

                        <!-- [ Main Content ] start -->
                        <div class="row">
                            <!-- Column Rendering table start -->
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Trashed List</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive dt-responsive">
                                            <table id="colum-rendr" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Sl</th>
                                                        <th>Full Name</th>
                                                        <th>Email</th>
                                                        <th>Phone</th>
                                                        <th>Role</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                	@php
                                                		$i=1;
                                                	@endphp
                                                	@foreach($users as $key=>$user)
                                                        @if (auth()->user()->id!=$user->id)
                                                            <tr>
                                                                <td>{{ $i++ }}</td>
                                                                <td>{{ $user->full_name }}</td>
                                                                <td>{{ $user->email??'N/A' }}</td>
                                                                <td>{{ $user->phone??'N/A' }}</td>
                                                                <td><span class="badge badge-primary">{{ $user->roles[0]?$user->roles[0]->name:'N/A' }}</span></td>
                                                                <td>
                                                                <div class="ic-action-button">
                                                                    <!-- <div class="dropdown show">
                                                                      <a class="btn btn-default dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                        ...
                                                                      </a>
                                                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuLink"> -->
                                                                          <a class="dropdown-item" href="javascript:void(0)" onclick="makeRestore(event,'{{ $user->id }}')"><i class="fas fa-reply-all"></i> Restore</a>
                                                                            
                                                                            <form action="{{ route('admin.user.restore',[$user->id]) }}" method="POST" id="restore-form-{{ $user->id }}">
                                                                                @csrf

                                                                            </form>
                                                                      <!-- </div>
                                                                    </div> -->
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('script')
    
@endsection