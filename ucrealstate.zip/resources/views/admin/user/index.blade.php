@extends('admin.layouts.master')


@section('content')

<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-6">
                                        <div class="page-header-title">
                                            <h5>User List</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#"><i class="fas fa-users"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#">User List</a></li>
                                        </ul>
                                    </div>

                                    @can('Add User')
                                        <div class="col-md-6">
                                            <a href="{{ route('admin.user.create') }}" class="btn btn-success float-right">Create</a>
                                        </div>
                                    @endcan

                                </div>
                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->

                        <!-- [ Main Content ] start -->
                        <div class="row">
                            <!-- Column Rendering table start -->
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Client List</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive dt-responsive">
                                            <table id="colum-rendr" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Sl</th>
                                                        <th>Full Name</th>
                                                        <th>Email</th>
                                                        <th>Phone</th>
                                                        <th>Role</th>
                                                        @canany(['Edit User','Delete User'])
                                                        <th>Action</th>
                                                        @endcanany
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                	@php
                                                		$i=1;
                                                	@endphp
                                                	@foreach($users as $key=>$user)
                                                        @if (auth()->user()->id!=$user->id)
                                                            <tr>
                                                                <td>{{ $i++ }}</td>
                                                                <td><a href="{{ route('admin.user.edit',[$user->id]) }}">{{ $user->full_name }}</a></td>
                                                                <td>{{ $user->email??'N/A' }}</td>
                                                                <td>{{ $user->phone??'N/A' }}</td>
                                                                <td><span class="badge badge-primary">{{ $user->roles[0]?$user->roles[0]->name:'N/A' }}</span></td>
                                                                @canany(['Edit User','Delete User'])
                                                                    <td>
                                                                    <div class="ic-action-button">
                                                                        @can('Delete User')   
                                                                            <a class="dropdown-item btn-danger btn-sm" onclick="makeDeleteRequest(event,'{{ $user->id }}')" href="javascript:void(0)"><i class="far fa-trash-alt"></i> Delete</a>
                                                                                <form action="{{ route('admin.user.destroy',[$user->id]) }}" method="post" id="delete-form-{{ $user->id }}">
                                                                                    @csrf
                                                                                    @method('DELETE')
                                                                                </form>
                                                                        @endcan
                                                                    </div>
                                                                        <!-- <div class="dropdown show">
                                                                          <a class="btn btn-default dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                            ...
                                                                          </a>
                                                                          <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                                            @can('Edit User')
                                                                                <a class="dropdown-item" href="{{ route('admin.user.edit',[$user->id]) }}"><i class="fas fa-edit text-success"></i> Edit</a>
                                                                            @endcan

                                                                            
                                                                                   
                                                                          </div>
                                                                        </div> -->
                                                                    </td>
                                                                @endcanany
                                                                    
                                                            </tr>
                                                        @endif
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('script')
    
@endsection