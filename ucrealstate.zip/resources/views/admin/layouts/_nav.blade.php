<nav class="ic-navbar menupos-fixed menu-dark menu-item-icon-style6 ">
    <div class="navbar-wrapper ">
        <div class="navbar-brand header-logo">
            <a href="{{ route('admin.dashboard') }}" class="b-brand">
                @if (Settings::get('logo'))
                    <img src="{{ Storage::url(Settings::get('logo')) }}" alt="" class="logo images">
                @else
                    <img src="{{ asset('dashboard/assets/images/logo.svg') }}" alt="" class="logo images">
                @endif

                @if (Settings::get('fabicon'))
                    <img src="{{ Storage::url(Settings::get('fabicon')) }}" alt="" class="logo-thumb images">
                @else
                    <img src="{{ asset('dashboard/assets/images/favicon.svg') }}" alt="" class="logo-thumb images">
                @endif

            </a>
            <a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a>
        </div>
        <div class="navbar-content scroll-div">

            <ul class="nav ic-inner-navbar ">
                <li data-username="documentation" class="nav-item">
                    <a href="{{ route('admin.dashboard') }}" class="nav-link">
                        <span class="ic-micon">
                            <i class="fas fa-home"></i>
                        </span>
                        <span class="pcoded-mtext">Dashboard</span>
                    </a>
                </li>


                @canany(['Add Property','Edit Property','Show Property','Delete Property'])
                <li data-username="documentation" class="nav-item">
                    <a href="{{ route('admin.storyboard.index') }}" class="nav-link">
                        <span class="ic-micon">
                            <i class="fas fa-edit"></i>
                        </span>
                        <span class="pcoded-mtext">Property List</span>
                    </a>
                </li>
                @endcanany

                @canany(['Add Client','Edit Client','Show Client','Delete Client'])
                <li data-username="documentation" class="nav-item">
                    <a href="{{ route('admin.client.index') }}" class="nav-link">
                        <span class="ic-micon">
                            <i class="feather icon-user"></i>
                        </span>
                        <span class="pcoded-mtext">Client List</span>
                    </a>
                </li>
                @endcanany


                @canany(['Add Office','Edit Office','Show Office','Delete Office'])
                <li data-username="documentation" class="nav-item">
                    <a href="{{ route('admin.office.index') }}" class="nav-link">
                        <span class="ic-micon">
                            <i class="fas fa-briefcase"></i>
                        </span>
                        <span class="pcoded-mtext">Office List</span>
                    </a>
                </li>
                @endcanany

                {{-- @canany(['Note List'])
                <li data-username="vertical" class="nav-item ic-hasmenu">
                    <a href="#" class="nav-link"><span class="ic-micon"><i class="far fa-clipboard"></i></span><span class="ic-mtext">Note</span></a>
                    <ul class="ic-submenu">
                        <li class=""><a href="{{ route('admin.note.index') }}" class="">Note List</a></li>
                    </ul>
                </li>
                @endcanany --}}

                @canany(['Add Role','Edit Role','Show Role','Delete Role','Add User','Edit User','Show User','Delete User','Trashed User'])
                    <li data-username="vertical" class="nav-item ic-hasmenu">
                        <a href="#" class="nav-link"><span class="ic-micon"><i class="fas fa-users-cog"></i></span><span class="ic-mtext">Administration</span></a>
                        <ul class="ic-submenu">
                            @canany(['Add Role','Edit Role','Show Role','Delete Role'])
                                <li class=""><a href="{{ route('admin.role.index') }}" class="">Role</a></li>
                            @endcanany

                            @canany(['Add User','Edit User','Show User','Delete User'])
                                <li class=""><a href="{{ route('admin.user.index') }}" class="">User</a></li>
                            @endcanany

                            @canany(['Trashed User'])
                                <li class=""><a href="{{ route('admin.user.trashed') }}" class="">User Trashed List</a></li>
                            @endcanany
                        </ul>
                    </li>
                @endcanany

                @can('Edit Settings')
                <li data-username="documentation" class="nav-item">
                    <a href="{{ route('admin.setting.index') }}" class="nav-link">
                        <span class="ic-micon">
                            <i class="fas fa-cog"></i>
                        </span>
                        <span class="pcoded-mtext">Setting</span>
                    </a>
                </li>
                <li data-username="documentation" class="nav-item">
                    <a href="{{ route('admin.widget.create') }}" class="nav-link">
                        <span class="ic-micon">
                            <i class="fas fa-envelope-square"></i>
                        </span>
                        <span class="pcoded-mtext">Email Setting</span>
                    </a>
                </li>
                @endcan

                <li data-username="documentation" class="nav-item">
                    <a href="javascript:void(0)" onclick="systemLogout(event)" class="nav-link">
                        <span class="ic-micon">
                            <i class="fas fa-power-off text-danger"></i>
                        </span>
                        <span class="pcoded-mtext">Logout</span>
                    </a>
                </li>

                @can('Trashed Property')
                    <li data-username="documentation" class="nav-item">
                        <a href="{{ route('admin.storyboard.trashed') }}" class="nav-link">
                            <span class="ic-micon text-danger">
                                <i class="fas fa-trash-alt"></i>
                            </span>
                            <span class="pcoded-mtext">Property Trashed List</span>
                        </a>
                    </li>
                @endcan

                @can('Trashed Client')
                    <li data-username="documentation" class="nav-item">
                        <a href="{{ route('admin.client.trashed') }}" class="nav-link">
                            <span class="ic-micon text-danger">
                                <i class="fas fa-trash-alt"></i>
                            </span>
                            <span class="pcoded-mtext">Client Trashed List</span>
                        </a>
                    </li>
                @endcan

                @can('Trashed Office')
                    <li data-username="documentation" class="nav-item">
                        <a href="{{ route('admin.office.trashed') }}" class="nav-link">
                            <span class="ic-micon text-danger">
                                <i class="fas fa-trash-alt"></i>
                            </span>
                            <span class="pcoded-mtext">Office Trashed List</span>
                        </a>
                    </li>
                @endcan

            </ul>

        </div>
    </div>
</nav>
