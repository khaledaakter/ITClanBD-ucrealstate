@extends('admin.layouts.master')


@section('content')

<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-12">
                                        <div class="page-header-title">
                                            <h5>Trashed List</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.html"><i class="fas fa-user-tie"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#!">Trashed List</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Trashed List</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive dt-responsive">
                                            <table id="colum-rendr" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Sl.</th>
                                                        <th>Client Name</th>
                                                        <th>Email</th>
                                                        <th>Phone</th>
                                                        <th>Photo</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                	@php
                                                		$i=1;
                                                	@endphp
                                                	@foreach ($clients as $key=>$client)
                                                		<tr>
                                                			<td>{{ $i++ }}</td>
                                                			<td>{{ $client->display_name }}</td>
                                                			<td>{{ $client->email }}</td>
                                                			<td>{{ $client->phone??'N/A' }}</td>
                                                			<td><img width="30%" src="{{ Storage::url($client->photo) }}" alt="Image Not Found"></td>
                                                			<td>
                                                                <div class="ic-action-button">
                                                				    <a class="dropdown-item btn btn-danger btn-sm" href="javascript:void(0)" onclick="makeRestore(event,'{{ $client->id }}')"><i class="fas fa-reply-all"></i> Restore</a>

                                                				  	<form action="{{ route('admin.client.restore',[$client->id]) }}" method="POST" id="restore-form-{{ $client->id }}">
                                                				  		@csrf

                                                				  	</form>
                                                				</div>

                                                			</td>
                                                		</tr>
                                                	@endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
