@extends('admin.layouts.master')


@section('content')

<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <!-- [ breadcrumb ] start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-6">
                                        <div class="page-header-title">
                                            <h5>Client List</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.html"><i class="fas fa-user-tie"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#!">Client List</a></li>
                                        </ul>
                                    </div>
                                    @can('Add Client')
                                        <div class="col-md-6">
                                            <a href="{{ route('admin.client.create') }}" class="btn btn-success btn-sm float-right">Add Client</a>
                                        </div>
                                    @endcan
                                </div>
                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->

                        <!-- [ Main Content ] start -->
                        <div class="row">
                            <!-- Column Rendering table start -->
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Client List</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive dt-responsive">
                                            <table id="colum-rendr" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Sl.</th>
                                                        <th>Client Name</th>
                                                        <th>Email</th>
                                                        <th>Phone</th>
                                                        <th>Photo</th>
                                                        @canany(['Delete Client'])
                                                        <th>Action</th>
                                                        @endcanany
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                	@php
                                                		$i=1;
                                                	@endphp
                                                	@foreach ($clients as $key=>$client)
                                                		<tr>
                                                			<td>{{ $i++ }}</td>
                                                			<td>
                                                                @can('Edit Client')
                                                                <a href="{{ route('admin.client.edit',[$client->id]) }}">{{ $client->display_name }}</a>
                                                                @else
                                                                {{ $client->display_name }}
                                                                @endcan
                                                            </td>
                                                			<td>{{ $client->email }}</td>
                                                			<td>{{ $client->phone??'N/A' }}</td>
                                                			<td><img width="40%" src="{{ Storage::url($client->photo) }}" alt="Image Not Found"></td>
                                                			@canany(['Delete Client'])
                                                                <td>
                                                                    <div class="ic-action-button">
                                                                        @can('Delete Client')
                                                                            <a class="dropdown-item btn-danger btn-sm" href="javascript:void(0)" onclick="makeDeleteRequest(event,'{{ $client->id }}')"><i class="fas fa-trash-alt"></i> Delete</a>

                                                                            <form action="{{ route('admin.client.destroy',[$client->id]) }}" method="POST" id="delete-form-{{ $client->id }}">
                                                                                @csrf
                                                                                @method('DELETE')

                                                                            </form>
                                                                        @endcan
                                                                    </div>
                                                    			</td>
                                                            @endcanany
                                                		</tr>
                                                	@endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Column Rendering table end -->
                        </div>
                        <!-- [ Main Content ] end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
