@extends('admin.layouts.master')


@section('content')
<!-- [ Main Content ] start -->
<div class="ic-main-container">
	<div class="ic-wrapper">
		<div class="ic-content">
			<div class="ic-inner-content">
				<div class="main-body">
					<div class="page-wrapper">
						<!-- [ breadcrumb ] start -->
						<div class="page-header">
							<div class="page-block">
								<div class="row align-items-center">
									<div class="col-md-12">
										<div class="page-header-title">
											<h5>Home</h5>
										</div>
										<ul class="breadcrumb">
											<li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
											<li class="breadcrumb-item"><a href="#">Dashboard</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- [ breadcrumb ] end -->

						<!-- [ Main Content ] start -->
						<div class="row">
							<div class="col-xl-12">
								<div class="card">
									<div class="card-body table-border-style">
										<div class="table-responsive dt-responsive">
											<table id="colum-rendr" class="table table-striped table-bordered nowrap">
												<thead>
													<tr>
														<th class="bg-none">NO.</th>
														<th class="bg-none">Client</th>
														<th class="bg-none">Address</th>
														<th class="bg-none">Date</th>
														<th class="bg-none">Progress</th>
														<th class="bg-none">Status</th>
													</tr>
												</thead>
												<tbody>
													@php
														$i=1;
													@endphp
													@foreach ($storyBoareds as $storyBoared)
														<tr>
															<td>{{ $i++ }}</td>
															<td><a href="{{ route('admin.client.edit',[$storyBoared->user->id]) }}">{{ $storyBoared->user->full_name }}</a></td>
															<td><a href="{{ route('admin.storyboard.edit',[$storyBoared->id]) }}">{{ $storyBoared->property_address }}</a></td>
															<td>{{ $storyBoared->updated_at_format }}</td>
															<td>
															    {{-- <p class="{{ $storyBoared->status==1?'text-primary':'' }}">
															        @if (count($storyBoared->boardGalleries)>0)
															           <a href="javascript:void(0)" onclick="showStoryBoard(event,{{ $storyBoared->id }},'p')"> P </a>
															        @endif
															        @if ($storyBoared->p_video_link)
															           <a href="javascript:void(0)" onclick="showStoryBoard(event,{{ $storyBoared->id }},'v')"> V </a>
															        @endif
															        @if ($storyBoared->p_floor_plan)
															            <a href="javascript:void(0)" onclick="showStoryBoard(event,{{ $storyBoared->id }},'f')"> F </a>
															        @endif
															        @if ($storyBoared->p_metterport)
															            <a href="javascript:void(0)" onclick="showStoryBoard(event,{{ $storyBoared->id }},'m')"> M </a>
															        @endif
															        @if (count($storyBoared->panoramas)>0)
															            <a href="javascript:void(0)" onclick="showStoryBoard(event,{{ $storyBoared->id }},'pa')"> Pa </a>
															        @endif
															    </p> --}}
																<p class="{{ $storyBoared->status==1?'text-primary':'' }}">
                                                                    @foreach($storyBoared->allServices as $key=>$storyboardservice)
                                                                        @if ($storyboardservice->service_p)
                                                                            <a href="javascript:void(0)"> P </a>
                                                                        @endif

                                                                        @if ($storyboardservice->service_v)
                                                                            <a href="javascript:void(0)"> V </a>
                                                                        @endif

                                                                        @if ($storyboardservice->service_f)
                                                                            <a href="javascript:void(0)"> F </a>
                                                                        @endif

                                                                        @if ($storyboardservice->service_m)
                                                                            <a href="javascript:void(0)"> M </a>
                                                                        @endif
                                                                        @if ($storyboardservice->service_pa)
                                                                            <a href="javascript:void(0)"> Pa </a>
                                                                        @endif

                                                                    @endforeach
                                                                </p>
															</td>
															<td>
																{!! $storyBoared->story_board_status !!}
															</td>
														</tr>
													@endforeach
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- [ Main Content ] end -->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


@foreach ($storyBoareds as $key=>$storyBoared)
    <div class="modal fade" id="StoryBoard-{{ $storyBoared->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Story Board Quick View</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            @if (count($storyBoared->boardGalleries)>0)
                <span class="storyBoardItem type-p">
                     <label for="">P</label><br>
                    @foreach ($storyBoared->boardGalleries as $boardGallerie)
                        <img src="{{ Storage::url($boardGallerie->image) }}" width="20%" class="img-fluid" alt="images">
                    @endforeach
                </span>
            @endif

            @if ($storyBoared->p_video_link)
                <span class="storyBoardItem type-v">
                    <div class="form-group">
                        <label for="videoLink">video link</label><br>
                        <input type="text" class="form-control" value="{{ $storyBoared->p_video_link }}">
                    </div>
                </span>
            @endif

            @if ($storyBoared->p_floor_plan)
                <span class="storyBoardItem type-f">
                    <label for="">F</label><br>
                    @if (strpos($storyBoared->p_floor_plan, 'pdf') !== false)
                        <embed src="{{ Storage::url('story_file') }}/{{ $storyBoared->p_floor_plan }}" style="width:400px; height:600px;" frameborder="0">
                    @else
                       <img src="{{ Storage::url('story_file') }}/{{ $storyBoared->p_floor_plan }}" width="20%" class="img-fluid" alt="images">
                    @endif
                </span>
            @endif

            @if ($storyBoared->p_metterport)
                <span class="storyBoardItem type-m">
                    <div class="form-group">
                        <label for="">M</label><br>
                        <textarea class="form-control" id="" cols="3" rows="5">{{ $storyBoared->p_metterport }}</textarea>
                    </div>
                </span>
            @endif

            @if (count($storyBoared->panoramas)>0)
                <span class="storyBoardItem type-pa">
                    @foreach ($storyBoared->panoramas as $panorama)
                        <img src="{{ Storage::url($panorama->panorama_photo) }}" width="20%" class="img-fluid" alt="images">
                    @endforeach
                </span>
            @endif

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
@endforeach
<!-- [ Main Content ] end -->
@endsection

@section('script')
	<script>
	    function showStoryBoard(event,storyBoard_id,type)
	    {
	        event.preventDefault();
	        $(`#StoryBoard-${storyBoard_id}`).modal('show');
	        $('.storyBoardItem').hide();
	        $(`.type-${type}`).show();

	    }
	</script>
@endsection
