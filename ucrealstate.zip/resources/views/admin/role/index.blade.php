@extends('admin.layouts.master')


@section('content')

<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <!-- [ breadcrumb ] start -->
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-6">
                                        <div class="page-header-title">
                                            <h5>Role List</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.html"><i class="fas fa-user-tie"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#!">Role List</a></li>
                                        </ul>
                                    </div>

                                    @can('Add Role')
                                        <div class="col-md-6">
                                            <a href="{{ route('admin.role.create') }}" class="btn btn-success float-right">Create</a>
                                        </div>
                                    @endcan

                                </div>
                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->

                        <!-- [ Main Content ] start -->
                        <div class="row">
                            <!-- Column Rendering table start -->
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Role List</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive dt-responsive">
                                            <table id="colum-rendr" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Sl.</th>
                                                        <th>Role</th>
                                                        @canany(['Edit Role','Delete Role'])
                                                        <th>Action</th>
                                                        @endcanany
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                	@php
                                                		$i=1;
                                                	@endphp
                                                	@foreach ($roles as $key=>$role)
                                                        <tr>
                                                			<td>{{ $i++ }}</td>
                                                			<td>{{ $role->name }}</td>
                                                            @canany(['Edit Role','Delete Role'])
                                                                <td>
                                                                <div class="ic-action-button">
                                                                  <!-- <div class="dropdown">
                                                                    <button class="btn btn-default dropdown-toggle btn-sm" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                      ...
                                                                    </button>
                                                                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> -->
                                                                        @can('Edit Role')
                                                                            <a class="dropdown-item btn-success btn-sm" href="{{ route('admin.role.edit',[$role->id]) }}"><i class="fas fa-edit"></i> Edit</a>
                                                                        @endcan

                                                                        @can('Delete Role')    
                                                                            <a class="dropdown-item btn-danger btn-sm" href="javascript:void(0)" onclick="makeDeleteRequest(event,'{{ $role->id }}')"><i class="fas fa-trash-alt"></i> Delete</a>
                                                                        
                                                                            <form action="{{ route('admin.role.destroy',[$role->id]) }}" method="POST" id="delete-form-{{ $role->id }}">
                                                                                @csrf
                                                                                @method('DELETE')
                                                                            </form>
                                                                        @endcan
                                                                            
                                                                      <!-- </div>
                                                                  </div> -->
                                                                  </div>
                                                    			</td>
                                                            @endcanany    
                                                		</tr>
                                                	@endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection