@extends('admin.layouts.master')

@section('content')



<div class="ic-main-container">
	<div class="ic-wrapper">
		<div class="ic-content">
			<div class="ic-inner-content">
				<div class="main-body">
					<div class="page-wrapper">
						<div class="page-header">
							<div class="page-block">
								<div class="row align-items-center">
									<div class="col-md-12">
										<div class="page-header-title">
											<h5>Create Role</h5>
										</div>
										<ul class="breadcrumb">
											<li class="breadcrumb-item"><a href="index.html"><i class="feather icon-users"></i></a></li>
											<li class="breadcrumb-item"><a href="#!">Create Role</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- [ breadcrumb ] end -->

						<!-- [ Main Content ] start -->
						<div class="ic-main-wrapper">
							<form class="forms-sample" id="ic_permission_add" action="{{route('admin.role.store')}}" method="POST" enctype="multipart/form-data">
								@csrf
									<div class="row">
										<div class="col-xl-6 col-md-6">
											<div class="card">
												<div class="card-body">
							         <div class="form-group">
							             <label for="ic_role_name">Role Name</label>
							             <input type="text" class="form-control ic_custom-form-input" id="ic_role_name" autocomplete="off" name="role_name" placeholder="Enter Role Name" required value="{{old('role_name')}}">
							         </div>

							         <div class="row my-2">
							             <div class="col-8 pt-1">
							                 <div class="custom-control" style="padding-left: 0px;">
							                     <label for="customCheck-all">All Permissions</label>
							                 </div>
							             </div>
							             <div class="col-4 pt-1">
							                 <div class="custom-control custom-checkbox">
							                     <input type="checkbox" name="parent_id" class="custom-control-input" id="customCheck-all" value="all">
							                     <label class="custom-control-label" for="customCheck-all"></label>
							                 </div>
							             </div>
							         </div>

							         @foreach ($permissions as $i => $permission)
							             <div class="row ic_parent_permission my-2">
							                 <div class="col-8 pt-1">
							                     <div class="custom-control" style="padding-left: 0px">
							                         <label for="customCheck-{{$permission->id}}"><strong>{{$permission->name}} All</strong></label>
							                     </div>
							                 </div>
							                 <div class="col-4 pt-1">
							                     <div class="custom-control custom-checkbox">
							                         <input type="checkbox" name="parent_id" class="custom-control-input" id="customCheck-{{$permission->id}}" onchange="loadChildren({{$permission->id}})">
							                         <label class="custom-control-label" for="customCheck-{{$permission->id}}"></label>
							                     </div>
							                 </div>
							             </div>
							             <div class="row ic_div-show" id="ic_parent-{{$permission->id}}" style="display: none;transition: all 10s ease">
							                 @foreach ($permission->children as $children)
							                     <div class="col-8 pt-1">
							                         <div class="custom-control" style="padding-left: 0px">
							                             <label for="customCheck-{{$children->id}}">{{$children->name}}</label>
							                         </div>
							                     </div>
							                     <div class="col-4 pt-1">
							                         <div class="custom-control custom-checkbox">
							                             <input type="checkbox" name="permissions[]" class="custom-control-input parent-identy-{{$permission->id}}" id="customCheck-{{$children->id}}" value="{{$children->id}}">
							                             <label class="custom-control-label" for="customCheck-{{$children->id}}"></label>
							                         </div>
							                     </div>
							                 @endforeach
							             </div>
							         @endforeach
							         			<div class="col-md-6 float-right">
							         				<button type="submit" class="btn btn-success">Save Role</button>
										         	<a href="{{ url()->previous() }}" class="btn btn-info">Back</a>
							         			</div>
										         
							     				</div>
							     			</div>
							     		</div>
							     	</div>
							     </form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@endsection

@section('script')
<script>
        $("#customCheck-all").click(function(){
            $('input:checkbox').not(this).prop('checked', this.checked);
            $('div .ic_div-show').toggle();
        });

        function loadChildren(parent_id) {

            $(`#ic_parent-${parent_id}`).toggle();

            if ($(`#customCheck-${parent_id}`).is(':checked')){
                $(`.parent-identy-${parent_id}`).each(function(){
                    $(this).prop('checked', true);
                });
            }else{
                $(`.parent-identy-${parent_id}`).each(function(){
                    $(this).prop('checked', false);
                });
            }
        }
    </script>
@endsection

@section('style')
	<style>
        .ic_parent_permission {
            background-color: rgb(250, 243, 213);
            color: rgb(220, 74, 83);
            border-radius: 5px;
        }
    </style>
@endsection