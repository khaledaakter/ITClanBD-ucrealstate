@extends('admin.layouts.master')



@section('content')


<div class="ic-main-container">
	<div class="ic-wrapper">
		<div class="ic-content">
			<div class="ic-inner-content">
				<div class="main-body">
					<div class="page-wrapper">
						<div class="page-header">
							<div class="page-block">
								<div class="row align-items-center">
									<div class="col-md-12">
										<div class="page-header-title">
											<h5>Update Settings</h5>
										</div>
										<ul class="breadcrumb">
											<li class="breadcrumb-item"><a href="index.html"><i class="feather icon-users"></i></a></li>
											<li class="breadcrumb-item"><a href="#!">Update Settings</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- [ breadcrumb ] end -->

						<!-- [ Main Content ] start -->
						<div class="ic-main-wrapper">
							<form action="{{ route('admin.setting.store') }}" method="POST" enctype="multipart/form-data">
								@csrf

								<div class="row">
									<div class="col-xl-6 col-md-6">
										<div class="card">
											<div class="card-body">
												<div class="form-group">
													<label for="">Title #</label>
													<input type="text" name="title" value="{{ $settings[0]->setting_value }}" class="form-control" placeholder="Title">
													@error('title')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
												<div class="form-group">
													<label for="demo-input-file" class="col-form-label">Logo</label>
													<input class="form-control" name="logo" type="file" id="demo-input-file">
												</div>
												<div class="form-group">
													<label for="demo-input-file" class="col-form-label">Fabicon</label>
													<input class="form-control" name="fabicon" type="file" id="demo-input-file">
												</div>

												<div class="form-group">
													<label for="demo-input-file" class="col-form-label">Login Image</label>
													<input class="form-control" name="login_image" type="file" id="demo-input-file">
												</div>

												<div class="form-group">
													<label for="demo-input-file" class="col-form-label">Default background</label>
													<input class="form-control" name="default_bg" type="file" id="demo-input-file">
												</div>

												<div class="form-group">
													<label for="demo-input-file" class="col-form-label">Default Profile</label>
													<input class="form-control" name="default_profile" type="file" id="demo-input-file">
												</div>

											</div>
										</div>
									</div>
									<div class="col-xl-6 col-md-6">
										<div class="card">
											<div class="card-body">
												@if ($settings[1])
													<div class="form-group">
														<label for="">Logo</label><br>
														<img width="15%" src="{{ Storage::url($settings[1]->setting_value) }}" alt="">
													</div>
												@endif

												@if ($settings[2])
													<div class="form-group">
														<label for="">Fabicon</label><br>
														<img width="15%" src="{{ Storage::url($settings[2]->setting_value) }}" alt="">
													</div>
												@endif

												@if ($settings[3])
													<div class="form-group">
														<label for="">Login Image</label><br>
														<img width="15%" src="{{ Storage::url($settings[3]->setting_value) }}" alt="">
													</div>
												@endif

												@if ($settings[4])
													<div class="form-group">
														<label for="">Default Background</label><br>
														<img width="15%" src="{{ Storage::url($settings[4]->setting_value) }}" alt="">
													</div>
												@endif

												@if ($settings[5])
													<div class="form-group">
														<label for="">Default Profile</label><br>
														<img width="15%" src="{{ Storage::url($settings[5]->setting_value) }}" alt="">
													</div>
												@endif

											</div>
										</div>

                                        <div class="card">
											<div class="card-body">

                                                <div class="form-grpup">
                                                    <label for="">Flickr User Id</label>
                                                    <input type="text" name="flickr_user_id" value="{{ Settings::get('flickr_user_id')??'' }}" class="form-control" placeholder="Flickr User Id">
                                                </div>

                                                <div class="form-grpup">
                                                    <label for="">Flickr Secret</label>
                                                    <input type="text" name="flickr_secret" value="{{ Settings::get('flickr_secret')??'' }}" class="form-control" placeholder="Flickr Secret">
                                                </div>

                                                <div class="form-grpup">
                                                    <label for="">Flickr key</label>
                                                    <input type="text" name="flickr_key" value="{{ Settings::get('flickr_key')??'' }}" class="form-control" placeholder="Flickr key">
                                                </div>

											</div>
										</div>

									</div>
								</div>
								<button class="btn btn-primary mr-2 float-right">Update</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@endsection

@section('script')

@endsection
