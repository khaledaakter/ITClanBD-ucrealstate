@extends('admin.layouts.master')



@section('content')


<div class="ic-main-container">
	<div class="ic-wrapper">
		<div class="ic-content">
			<div class="ic-inner-content">
				<div class="main-body">
					<div class="page-wrapper">
						<div class="page-header">
							<div class="page-block">
								<div class="row align-items-center">
									<div class="col-md-12">
										<div class="page-header-title">
											<h5>Update Profile</h5>
										</div>
										<ul class="breadcrumb">
											<li class="breadcrumb-item"><a href="index.html"><i class="feather icon-users"></i></a></li>
											<li class="breadcrumb-item"><a href="#!">Update Profile</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- [ breadcrumb ] end -->

						<!-- [ Main Content ] start -->
						<div class="ic-main-wrapper">
							<form action="{{ route('admin.profile.update',[auth()->user()->id]) }}" method="POST" enctype="multipart/form-data">
								@csrf


								<div class="row">
									<div class="col-xl-6 col-md-6">
										<div class="card">
											<div class="card-body">
												<h6>Account</h6>

												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label for="">Email</label>
															<input type="email" name="email" value="{{ auth()->user()->email }}" class="form-control" placeholder="Email">
															
															@error('email')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="">Password</label>
															<input type="password" name="password" class="form-control" placeholder="Password">
															
															@error('email')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>
												</div>
											</div>	
										</div>	

										<div class="card">
											<div class="card-body">
												<h6>General</h6>

												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label for="">Name</label>
															<input type="text" name="first_name" value="{{ auth()->user()->first_name }}" class="form-control" placeholder="First Name">
															
															@error('first_name')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="" class="mt-3"></label>
															<input type="text" name="last_name" value="{{ auth()->user()->last_name }}" class="form-control" placeholder="Last Name">
															
															@error('last_name')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													{{-- <div class="col-md-4">
														<div class="form-group">
															<label for="">Display Name</label>
															<input type="text" name="display_name" value="{{ auth()->user()->display_name }}" class="form-control" placeholder="Display Name">
															
															@error('display_name')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div> --}}

													{{-- <div class="col-md-12">
														<div class="form-group">
															<label for="">URL Name #</label>
															<div class="ic-input-round">
																<input type="text" name="user_name" value="{{ auth()->user()->user_name }}" readonly class="form-control" placeholder="URL Name">
																
															</div>
															@error('user_name')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div> --}}

													<div class="col-md-6">
														<div class="form-group">
															<label for="">Email</label>
															<input type="email" name="g_email" value="{{ auth()->user()->g_email }}" class="form-control" placeholder="Email">
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="">CC Email</label>
															<input type="email" name="cc_email" value="{{ auth()->user()->cc_email }}" class="form-control" placeholder="CC Email">
															@error('cc_email')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="">Client Phone</label>
															<input type="number" name="phone" value="{{ auth()->user()->phone }}" class="form-control" placeholder="Client Phone">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
															<label for="">website Link</label>
															<input type="text" name="website" value="{{ auth()->user()->website }}" class="form-control" placeholder="website Link">
														</div>
													</div>
													{{-- <div class="col-md-6">
														<div class="form-group">
															<label for="">Office Name</label>
															<select name="office_id" id="" class="select2 form-control">
																<option value="">Select Office</option>
																@foreach($offices as $key=>$office)
																	<option {{ auth()->user()->office_id==$office->id?'selected':'' }} value="{{ $office->id }}">{{ $office->name }}</option>
																@endforeach
															</select>
														</div>
													</div> --}}

													<div class="col-md-6">
														<div class="form-group">
															<label for="">Title</label>
															<input type="text" name="title" value="{{ auth()->user()->title }}" class="form-control" placeholder="Title">
														</div>
													</div>

													<div class="col-md-6">
														{{-- Location --}}
														<div class="form-group">
														    <div class="form-group">
														        <label for="videoLink">Location</label>
														        <input type="text" placeholder="Location" id="autocomplete-input" name="location" value="{{ auth()->user()->location }}" class="form-control" autocomplete="off">
														    </div>

														    <input type="hidden" id="locationLat" name="latitude" class="form-control" value="{{ auth()->user()->latitude }}">
														    <input type="hidden" id="locationLng" name="longitude" class="form-control" value="{{ auth()->user()->longitude }}">
														</div>
													</div>
													{{-- <div class="col-md-6">
														<div class="form-group">
															<label for="">Team Name</label>
															<input type="text" name="team_name" value="{{ auth()->user()->team_name }}" class="form-control" placeholder="Team Name">
														</div>
													</div> --}}
													
												</div>


											</div>	
										</div>

										{{-- <div class="card">
											<div class="card-body">
												<h6>Note</h6>
												<textarea name="note" class="form-control" cols="5" rows="3">{{ auth()->user()->note }}</textarea>
											</div>
										</div> --}}

										<div class="card">
											<div class="card-body">
												<h6>SNS</h6>

												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label for="">Facebook</label>
															<input type="text" name="facebook" value="{{ auth()->user()->facebook }}" class="form-control" placeholder="Facebook">
															
															@error('facebook')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="">Linkedin</label>
															<input type="text" name="linkdin" value="{{ auth()->user()->linkdin }}" class="form-control" placeholder="Linkedin">
															
															@error('linkdin')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="">Twitter</label>
															<input type="text" name="twitter" value="{{ auth()->user()->twitter }}" class="form-control" placeholder="Twitter">
															
															@error('twitter')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="">Instragram</label>
															<input type="text" name="instragram" value="{{ auth()->user()->instragram }}" class="form-control" placeholder="Instragram">
															
															@error('instragram')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="">Youtube</label>
															<input type="text" name="youtube" value="{{ auth()->user()->youtube }}" class="form-control" placeholder="Youtube">
															
															@error('youtube')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

												</div>

											</div>
										</div>

										<div class="card">
											<div class="card-body">
												<h6>Customize</h6>

												<div class="row">
													<div class="col-md-12">
														<div class="row ic-panorama-photo">

															<div class="col-md-6">
																<div class="form-group">
																	<label for="demo-input-file" class="col-form-label">Client Images</label>
																	<input class="form-control" name="photo" type="file" id="demo-input-file">
																</div>
															</div>
															<div class="col-md-6">
																<img width="30%" src="{{ Storage::url(auth()->user()->photo) }}" alt="Client Image Not Found">
															</div>


															<div class="col-md-6">
																<div class="form-group">
																	<label for="demo-input-file" class="col-form-label">Background Image</label>
																	<input class="form-control" name="background_image" type="file" id="demo-input-file">
																</div>
															</div>

															<div class="col-md-6">
																<img width="30%" src="{{ Storage::url(auth()->user()->background_image) }}" alt="Client Image Not Found">
															</div>



															<div class="col-md-6">
																<div class="form-group">
																	<label for="demo-input-file" class="col-form-label">Logo</label>
																	<input class="form-control" name="logo" type="file" id="demo-input-file">
																</div>
															</div>

															<div class="col-md-6">
																<img width="30%" src="{{ Storage::url(auth()->user()->logo) }}" alt="Client Image Not Found">
															</div>


															@php
																$i=1;
															@endphp

															@forelse(auth()->user()->themeColors as $key=>$themeColor)
																<div class="col-md-2">
																	<div class="form-group">
																		<label for="">Theme Color {{ $i }}</label><br>
																		<input type="color" name="color[]" class="" value="{{ $themeColor->color }}" placeholder="Theme Color 1">
																	</div>
																</div>
																	
																	@php
																		$i+=1;
																	@endphp
															@empty
																<div class="col-md-2">
																	<div class="form-group">
																		<label for="">Main Color</label><br>
																		<input type="color" name="color[]" class="" placeholder="Theme Color 1">
																	</div>
																</div>
																<div class="col-md-2">
																	<div class="form-group">
																		<label for="">Sub Color</label><br>
																		<input type="color" name="color[]" class="" placeholder="Theme Color 2">
																	</div>
																</div>
																<div class="col-md-2">
																	<div class="form-group">
																		<label for="">Sub Color</label><br>
																		<input type="color" name="color[]" class="" placeholder="Theme Color 3">
																	</div>
																</div>
																<div class="col-md-2">
																	<div class="form-group">
																		<label for="">Sub Color</label><br>
																		<input type="color" name="color[]" class="" placeholder="Theme Color 4">
																	</div>
																</div>
																<div class="col-md-2">
																	<div class="form-group">
																		<label for="">Sub Color</label><br>
																		<input type="color" name="color[]" class="" placeholder="Theme Color 5">
																	</div>
																</div>
															@endforelse
														</div>
													</div>
												</div>

											</div>
										</div>

									</div>
									
								</div>	
								
								{{-- <div class="row">
									<div class="col-xl-6 col-md-6">
										<div class="card">
											<div class="card-body">
												<div class="form-group">
													<label for="">First Name #</label>
													<input type="text" name="first_name" value="{{ auth()->user()->first_name }}" class="form-control" placeholder="First Name">
													@error('first_name')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
												<div class="form-group">
													<label for="">Last Name #</label>
													<input type="text" name="last_name" value="{{ auth()->user()->last_name }}" class="form-control" placeholder="Last Name">
													@error('last_name')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
												<div class="form-group">
													<label for="">Display Name #</label>
													<input type="text" name="display_name" value="{{ auth()->user()->display_name }}" class="form-control" placeholder="Display Name">
													@error('display_name')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
												<div class="form-group">
													<label for="">URL Name #</label>
													<div class="ic-input-round">
														<input type="text" name="user_name" value="{{ auth()->user()->user_name }}" readonly class="form-control" placeholder="URL Name">
													</div>
													@error('user_name')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
												<div class="form-group">
													<label for="">Email #</label>
													<input type="email" name="email" value="{{ auth()->user()->email }}" class="form-control" placeholder="Client Email">
													@error('email')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
												<div class="form-group">
													<label for="">CC Email</label>
													<input type="email" name="cc_email" value="{{ auth()->user()->cc_email }}" class="form-control" placeholder="CC Email">
													@error('cc_email')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
												<div class="form-group">
													<label for="">Password </label>
													<input type="password" name="password" class="form-control" placeholder="Password">
													@error('password')
														<span class="text-danger">{{ $message }}</span>
													@enderror
												</div>
												<div class="form-group">
													<label for="">Client Phone</label>
													<input type="number" name="phone" value="{{ auth()->user()->phone }}" class="form-control" placeholder="Client Phone">
												</div>
												<div class="form-group">
													<label for="">Team Name</label>
													<input type="text" name="team_name" value="{{ auth()->user()->team_name }}" class="form-control" placeholder="Team Name">
												</div>
												<div class="form-group">
													<label for="">Title</label>
													<input type="text" name="title" value="{{ auth()->user()->title }}" class="form-control" placeholder="Title">
												</div>
												
												<div class="form-group">
													<label for="">Office Name</label>
													<select name="office_id" id="" class="select2 form-control">
														<option value="">Select Office</option>
														@foreach($offices as $key=>$office)
															<option {{ auth()->user()->office_id==$office->id?'selected':'' }} value="{{ $office->id }}">{{ $office->name }}</option>
														@endforeach
													</select>
												</div>

												
												<div class="form-group">
												    <div class="form-group">
												        <label for="videoLink">Location</label>
												        <input type="text" placeholder="Location" id="autocomplete-input" name="location" value="{{ auth()->user()->location }}" class="form-control" autocomplete="off">
												    </div>

												    <input type="hidden" id="locationLat" name="latitude" class="form-control" value="{{ auth()->user()->latitude }}" name="lat">
												    <input type="hidden" id="locationLng" name="longitude" class="form-control" value="{{ auth()->user()->longitude }}" name="lng">
												</div>


												<div class="form-group">
													<label for="demo-input-file" class="col-form-label">Client Images</label>
													<input class="form-control" name="photo" type="file" id="demo-input-file">
												</div>
												<div class="form-group">
													<label for="demo-input-file" class="col-form-label">Background Image</label>
													<input class="form-control" name="background_image" type="file" id="demo-input-file">
												</div>

												<div class="form-group">
													<label for="demo-input-file" class="col-form-label">Logo</label>
													<input class="form-control" name="logo" type="file" id="demo-input-file">
												</div>
											</div>
										</div>
									</div>
									<div class="col-xl-6 col-md-6">
										<div class="card">
											<div class="card-body">
												<div class="form-group">
													<label for="">website Link</label>
													<input type="text" name="website" value="{{ auth()->user()->website }}" class="form-control" placeholder="website Link">
												</div>
												<div class="form-group">
													<label for="">Facebook</label>
													<input type="text" name="facebook" value="{{ auth()->user()->facebook }}" class="form-control" placeholder="Facebook">
												</div>
												<div class="form-group">
													<label for="">Linkedin</label>
													<input type="text" name="linkdin" value="{{ auth()->user()->linkdin }}" class="form-control" placeholder="Linkedin">
												</div>
												<div class="form-group">
													<label for="">Twitter</label>
													<input type="text" name="twitter" value="{{ auth()->user()->twitter }}" class="form-control" placeholder="Twitter">
												</div>
												<div class="form-group">
													<label for="">Instragram</label>
													<input type="text" name="instragram" value="{{ auth()->user()->instragram }}" class="form-control" placeholder="Instragram">
												</div>
												<div class="form-group">
													<label for="">Youtube</label>
													<input type="text" name="youtube" value="{{ auth()->user()->youtube }}" class="form-control" placeholder="Youtube">
												</div>
											</div>
										</div>

										<div class="card">
											<div class="card-body">
												@php
													$i=1;
												@endphp

												@forelse(auth()->user()->themeColors as $key=>$themeColor)
													<div class="form-group">
														<label for="">Theme Color {{ $i }}</label><br>
														<input type="color" name="color[]" class="" value="{{ $themeColor->color }}" placeholder="Theme Color 1">
													</div>
													@php
														$i+=1;
													@endphp
												@empty
													<div class="form-group">
														<label for="">Theme Color 1</label><br>
														<input type="color" name="color[]" class="" placeholder="Theme Color 1">
													</div>
													<div class="form-group">
														<label for="">Theme Color 2</label><br>
														<input type="color" name="color[]" class="" placeholder="Theme Color 2">
													</div>
													<div class="form-group">
														<label for="">Theme Color 3</label><br>
														<input type="color" name="color[]" class="" placeholder="Theme Color 3">
													</div>
													<div class="form-group">
														<label for="">Theme Color 4</label><br>
														<input type="color" name="color[]" class="" placeholder="Theme Color 4">
													</div>
													<div class="form-group">
														<label for="">Theme Color 5</label><br>
														<input type="color" name="color[]" class="" placeholder="Theme Color 5">
													</div>
												@endforelse
											</div>
										</div>

									</div>
								</div> --}}
								<button class="btn btn-primary mr-2">Update</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@endsection

@section('js')
<script id="api-key" defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB1taAMFjjJDItj7VVzlvsTvVrixJHHNqc&callback=initMap&libraries=places"></script>
@endsection

@section('script')
<script>
	$(function(){
		$('.select2').select2();
	});

	function checkUrlName(event)
	{
		event.preventDefault();

		$('input[name=user_name]').val(' ');

		let first_name=$("input[name=first_name]").val();
		let last_name=$("input[name=last_name]").val();


		if (first_name && last_name) {
			$.ajax({
				url:"{{ route('admin.client.check-url') }}",
				method:'GET',
		        data:{'user_name':first_name.trim().replace(/\s+/g, '-')+'-'+last_name.trim().replace(/\s+/g, '-')},
		        success:function(response){
		        	console.log(response)
		        	if (response.error) {
		        		toastr.error(response.error);
		        	}else{
		        		$('input[name=user_name]').val(response.user_name);
		        	}
		        },
		        error:function(error){
		        	console.log(error);
		        }
			});
		}else{
			toastr.error("Please Add First And Last Name");
		}
		
	}

	// Google autocomplete
	window.onload = function() {
	   initAutocomplete();
	}

	var autocomplete;
	function initAutocomplete(){
	    autocomplete = new google.maps.places.Autocomplete(
	    document.getElementById('autocomplete-input'), {types: ['geocode']});
	    autocomplete.addListener('place_changed', getAddressDetails);
	}
	function getAddressDetails(){
	    var place = autocomplete.getPlace();   
	    window.lat = place.geometry.location.lat();
	    window.long = place.geometry.location.lng();
	    console.log( +'-'+window.long);
	    $('#locationLat').val(window.lat);
	    $('#locationLng').val(window.long);
	}

	function geolocate(){
	  if (navigator.geolocation){
	    navigator.geolocation.getCurrentPosition(function(position){
	      var geolocation = {
	        lat: position.coords.latitude,
	        lng: position.coords.longitude
	      };
	        var circle = new google.maps.Circle(
	        {center: geolocation, radius: position.coords.accuracy});
	        autocomplete.setBounds(circle.getBounds());
	    });
	  }
	}
</script>
@endsection