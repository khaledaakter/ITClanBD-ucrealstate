@extends('admin.layouts.master')



@section('content')


<div class="ic-main-container">
	<div class="ic-wrapper">
		<div class="ic-content">
			<div class="ic-inner-content">
				<div class="main-body">
					<div class="page-wrapper">
						<div class="page-header">
							<div class="page-block">
								<div class="row align-items-center">
									<div class="col-md-12">
										<div class="page-header-title">
											<h5>Update Email Settings</h5>
										</div>
										<ul class="breadcrumb">
											<li class="breadcrumb-item"><a href=""><i class="feather icon-users"></i></a></li>
											<li class="breadcrumb-item"><a href="#!">Email Settings</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- [ breadcrumb ] end -->

						<!-- [ Main Content ] start -->
						<div class="ic-main-wrapper">
							<form action="{{ route('admin.widget.store') }}" method="POST" >
								@csrf

								<div class="row">
									<div class="col-xl-6 col-md-6">
										<div class="card">
											<div class="card-body">
												<h6>Email Settings</h6>

												<div class="row">
													<div class="col-md-6">
														<div class="form-group">
															<label for="">Host</label>
															<input type="text" name="contents[host]" value="@if($email_setting){{ $email_setting->contents['host'] }}@endif" class="form-control" placeholder="Host">
															
															@error('host')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="">Port</label>
															<input type="text" name="contents[port]" value="@if($email_setting){{ $email_setting->contents['port'] }}@endif" class="form-control" placeholder="Port">
															
															@error('port')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>


													<div class="col-md-6">
														<div class="form-group">
															<label for="">From Address</label>
															<input type="email" name="contents[from_address]" value="@if($email_setting){{ $email_setting->contents['from_address'] }}@endif" class="form-control" placeholder="From Address">
															
															@error('from_address')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="">From Name</label>
															<input type="text" name="contents[from_name]" value="@if($email_setting){{ $email_setting->contents['from_name'] }}@endif" class="form-control" placeholder="From Name">
															
															@error('from_name')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>


													<div class="col-md-6">
														<div class="form-group">
															<label for="">Encryptione</label>
															<input type="text" name="contents[encryption]" value="@if($email_setting){{ $email_setting->contents['encryption'] }}@endif" class="form-control" placeholder="Encryptione">
															
															@error('encryption')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="">User Name</label>
															<input type="text" name="contents[username]" value="@if($email_setting){{ $email_setting->contents['username'] }}@endif" class="form-control" placeholder="User Name">
															
															@error('username')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>

													<div class="col-md-6">
														<div class="form-group">
															<label for="">Password</label>
															<input type="text" name="contents[password]" value="@if($email_setting){{ $email_setting->contents['password'] }}@endif" class="form-control" placeholder="Password">
															
															@error('password')
																<span class="text-danger">{{ $message }}</span>
															@enderror
														</div>
													</div>


												</div>
											</div>	
										</div>	
									</div>	
								</div>	


								<button class="btn btn-primary mr-2">Update</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@endsection

