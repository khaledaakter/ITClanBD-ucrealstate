@extends('admin.layouts.master')


@section('content')

<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-12">
                                        <div class="page-header-title">
                                            <h5>Property Trashed List</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#"><i class="fas fa-user-tie"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#">Property Trashed List</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->

                        <!-- [ Main Content ] start -->
                        <div class="row">
                            <!-- Column Rendering table start -->
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Story Board List</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive dt-responsive">
                                            <table id="colum-rendr" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Sl.</th>
                                                        <th>CLIENT</th>
                                                        <th>ADDRESS</th>
                                                        <th>DATE</th>
                                                        <th>PROGRESS</th>
                                                        <th>STATUS</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @php
                                                        $i=1;
                                                    @endphp
                                                    @foreach ($storyBoareds as $storyBoared)
                                                        <tr>
                                                            <td>{{ $i++ }}</td>
                                                            <td>Name</td>
                                                            <td>{{ $storyBoared->property_address }}</td>
                                                            <td>{{ $storyBoared->updated_at_format }}</td>
                                                            <td>
                                                                <p class="ic-progress-list {{ $storyBoared->status==1?'text-primary':'' }}">
                                                                    @foreach($storyBoared->allServices as $key=>$storyboardservice)
                                                                        <a href="javascript:void(0)">@if ($storyboardservice->service_p)<i class="fas fa-check text-success"></i>@endif P </a>
                                                                        <a href="javascript:void(0)">@if ($storyboardservice->service_v)<i class="fas fa-check text-success"></i>@endif V </a>
                                                                        <a href="javascript:void(0)">@if ($storyboardservice->service_f)<i class="fas fa-check text-success"></i>@endif F </a>
                                                                        <a href="javascript:void(0)">@if ($storyboardservice->service_m)<i class="fas fa-check text-success"></i>@endif M </a>
                                                                        <a href="javascript:void(0)">@if ($storyboardservice->service_pa)<i class="fas fa-check text-success"></i>@endif Pa </a>
                                                                    @endforeach
                                                                </p>
                                                            </td>
                                                            <td>
                                                                {!! $storyBoared->story_board_status !!}
                                                            </td>
                                                            <td>
                                                            <div class="ic-action-button">

                                                                    <a class="dropdown-item btn btn-info btn-sm" href="javascript:void(0)" onclick="makeRestore(event,'{{ $storyBoared->id }}')"><i class="fas fa-reply-all"></i> Restore</a>

                                                                    <form action="{{ route('admin.storyboard.restore',[$storyBoared->id]) }}" method="POST" id="restore-form-{{ $storyBoared->id }}">
                                                                    @csrf
                                                                    </form>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
