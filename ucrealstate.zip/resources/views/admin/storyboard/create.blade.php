@extends('admin.layouts.master')


@section('content')


<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-12">
                                        <div class="page-header-title">
                                            <h5>Property Create</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#"><i class="feather icon-edit-1"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#">Property Create</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>


                            <form action="{{ route('admin.storyboard.store') }}" method="POST" enctype="multipart/form-data">
                                @csrf

                                <div class="row">

                                    <div class="col-xl-6">

                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <div class="form-group">
                                                                <label for="">Client</label>
                                                                <select name="user_id" id="selectUser" onchange="selectClient($(this).find(':selected').val())" class="form-control select2">
                                                                    <option value="">Select Client</option>
                                                                    @foreach ($users as $key=>$user)
                                                                        <option value="{{ $user->id }}" data-email="{{ $user->email }}">{{ $user->display_name }}</option>
                                                                    @endforeach
                                                                </select>
                                                                @error('user_id')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </div>

                                                            {{-- <div class="form-group">
                                                                <label for="">Theme Color #</label>
                                                                <ul>
                                                                    <div id="themeColor"></div>
                                                                </ul>
                                                            </div> --}}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="row ic-card-address">

                                                        <div class="col-lg-2 row">
                                                            <div class="form-group">
                                                                <label for="propertyaddress">Unit</label>
                                                                <input type="text" placeholder="Unit" name="unit" value="{{ old('unit') }}" class="form-control">
                                                                @error('unit')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-3">
                                                            <div class="form-group">
                                                                <label for="propertyaddress">Road Number</label>
                                                                <input type="text" placeholder="Road Number" name="road_number" value="{{ old('road_number') }}" class="form-control">
                                                                @error('road_number')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-3 row">
                                                            <div class="form-group">
                                                                <label for="propertyaddress">Road Name</label>
                                                                <input type="text" placeholder="Road Name" name="road_name" value="{{ old('road_name') }}" class="form-control">
                                                                @error('road_name')
                                                                    <span class="text-danger">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-2">
                                                            <div class="form-group">
                                                                <label for="propertyaddress">Road Type</label>
                                                                <select name="road_type" id="" class="form-control select2-tag">
                                                                    <option value="">Select Road Type</option>
                                                                    @foreach($road_types as $key=>$road_type)
                                                                        <option value="{{ $road_type }}">{{ $road_type }}</option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                        </div>


                                                        <div class="col-lg-2">
                                                            <div class="form-group">
                                                                <label for="propertyaddress">City</label>
                                                                <select name="city" id="" class="form-control select2-tag">
                                                                    <option value="">Select City</option>
                                                                    @foreach($cities as $key=>$citiy)
                                                                        <option value="{{ $citiy }}">{{ $citiy }}</option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <div class="form-group">
                                                                {{-- <h5>Location</h5> --}}
                                                                <div id="locationField">
                                                                    <div class="form-group">
                                                                        <label for="videoLink">Location</label>
                                                                        <input type="text" placeholder="Location" id="autocomplete-input" name="location" value="{{ old('location') }}" class="form-control">
                                                                    </div>

                                                                    <input type="text" id="locationLat" name="latitude" class="form-control d-none" value="{{ old('latitude') }}" name="lat">
                                                                    <input type="text" id="locationLng" name="longitude" class="form-control d-none" value="{{ old('longitude') }}" name="lng">
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="row ic-admin-fullwidth-row">

                                                        <div class="ic-banner-part">
                                                            <h5>Services</h5>
                                                            <div class="container">
                                                                <div class="row">
                                                                    <ul class="ic-ul">

                                                                        <li class="ic-li">
                                                                          <input type="checkbox" class="ic-checkbox" id="ic-p" name="service[p]" value="1"/>
                                                                          <label for="ic-p" class="ic-label">P</label>
                                                                        </li>
                                                                        <li class="ic-li">

                                                                          <input type="checkbox" class="ic-checkbox" id="ic-v" name="service[v]" value="1"/>
                                                                          <label for="ic-v" class="ic-label">V</label>
                                                                        </li>
                                                                        <li class="ic-li">
                                                                          <input type="checkbox" class="ic-checkbox" id="ic-f" name="service[f]" value="1"/>
                                                                          <label for="ic-f" class="ic-label">F</label>
                                                                        </li>
                                                                        <li class="ic-li">
                                                                            <input type="checkbox" class="ic-checkbox" id="ic-m" name="service[m]" value="1"/>
                                                                            <label for="ic-m" class="ic-label">M</label>
                                                                        </li>
                                                                        <li class="ic-li">
                                                                            <input type="checkbox" class="ic-checkbox" id="ic-pa" name="service[pa]" value="1"/>
                                                                            <label for="ic-pa" class="ic-label">Pa</label>
                                                                        </li>
                                                                      </ul>
                                                                </div>
                                                            </div>



                                                            <ul class="nav nav-pills p-0" id="pills-tab" role="tablist">
                                                                <li class="nav-item">
                                                                    <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#p" role="tab" aria-controls="pills-home" aria-selected="true">P</a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#v" role="tab" aria-controls="pills-profile" aria-selected="false">V</a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#f" role="tab" aria-controls="pills-contact" aria-selected="false">F</a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#m" role="tab" aria-controls="pills-contact" aria-selected="false">M</a>
                                                                </li>

                                                                <li class="nav-item">
                                                                    <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pa" role="tab" aria-controls="pills-contact" aria-selected="false">Pa</a>
                                                                </li>
                                                            </ul>
                                                            <div class="ic-tab-content-wrap tab-content" id="pills-tabContent">
                                                                <div class="tab-pane fade show active" id="p" role="tabpanel" aria-labelledby="pills-home-tab">
                                                                    <div class="ic-about-card p-2 border">

                                                                        <div class="form-group">
                                                                            <label for="">Dropbox Download link</label>
                                                                            <input type="url" value="" name="dropbox_url" placeholder="Dropbox Download link" class="form-control">
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="">Flickr PhotosetID</label>
                                                                            <input type="text" name="flickr_photo_set_id" class="form-control" placeholder="Flickr Photo Set Id">
                                                                        </div>
                                                                    </div>
                                                                    {{-- Email Button --}}
                                                                    {{-- <button type="button" onclick="sendPEmail()" class="btn btn-success btn-sm text-white ic-send-button">Send</button> --}}
                                                                </div>
                                                                <div class="tab-pane fade" id="v" role="tabpanel" aria-labelledby="pills-profile-tab">
                                                                    <div class="ic-about-card p-2 border">
                                                                        <div class="form-group">
                                                                            <label for="videoLink">Video link</label>
                                                                            <input type="text" placeholder="video link" name="p_video_link" value="{{ old('p_video_link') }}" class="form-control">
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="videoLink">Download link</label>
                                                                            <input type="text" placeholder="Download link" name="p_download_link" value="{{ old('p_download_link') }}" class="form-control">
                                                                        </div>


                                                                    </div>
                                                                    {{-- Email Button --}}
                                                                    {{-- <button type="button" onclick="sendVideoEmail()" class="btn btn-success btn-sm text-white ic-send-button">Send</button> --}}
                                                                </div>
                                                                <div class="tab-pane fade ic-tab-content-wrap" id="f" role="tabpanel"  aria-labelledby="pills-contact-tab">
                                                                    <div class="ic-about-card p-2 border">
                                                                        <div class="form-group">
                                                                            <label for="">Brand jpeg</label>
                                                                            <input type="file" placeholder="Upload Photo" name="p_floor_plan" class="form-control" accept="image/jpeg">
                                                                        </div>
                                                                    </div>
                                                                    {{-- Email Button --}}
                                                                    {{-- <button type="button" onclick="sendFloorEmail()" class="btn btn-success btn-sm text-white ic-send-button">Send</button> --}}
                                                                </div>
                                                                <div class="tab-pane fade ic-tab-content-wrap" id="m" role="tabpanel" aria-labelledby="pills-contact-tab">
                                                                    <div class="form-group">
                                                                        <label for="videoLink">Metterport Embeded Code</label>
                                                                        <textarea class="form-control" name="p_metterport" placeholder="Metterport Embeded Code">{{ old('p_metterport') }}</textarea>
                                                                    </div>
                                                                    {{-- Email Button --}}
                                                                    {{-- <button type="button" onclick="sendMetterEmail()" class="btn btn-success btn-sm text-white ic-send-button">Send</button> --}}
                                                                </div>

                                                                <div class="tab-pane fade ic-tab-content-wrap" id="pa" role="tabpanel" aria-labelledby="pills-home-tab">
                                                                    <div class="ic-about-card p-2 border">
                                                                        <div class="row">
                                                                            <div class="col-md-4">
                                                                                <label for="">Room Name</label>
                                                                            </div>
                                                                            <div class="col-md-4">
                                                                                <label for="">Photo</label>
                                                                            </div>
                                                                            <div class="col-md-4">

                                                                            </div>
                                                                        </div>
                                                                        <div id="panoramaPhoto">

                                                                        </div>
                                                                        {{-- <div class="form-group">
                                                                            <label for="">Panorama Photo</label>
                                                                            <input type="file" name="panorama" placeholder="Panorama" class="form-control">
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="">Room Name</label><br>
                                                                            <select name="p_room_name[]" id="" class="form-control select2-multi" style="width:100%;" multiple="">
                                                                                @foreach($room_names as $key=>$room_name)
                                                                                    <option value="{{ $room_name }}">{{ $room_name }}</option>
                                                                                @endforeach
                                                                            </select>
                                                                        </div> --}}

                                                                        <button onclick="addMorePanorama()" type="button" class="btn btn-success btn-sm">Add More</button>
                                                                    </div>

                                                                    {{-- Email Button --}}
                                                                    {{-- <button type="button" onclick="sendPanoramaEmail()" class="btn btn-success btn-sm text-white ic-send-button">Send</button> --}}

                                                                </div>
                                                            </div>
                                                        </div>


                                                    </div>
                                                </div>
                                            </div>
                                    </div>

                                    <div class="col-xl-6">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="ic-banner-part">
                                                            <h5>About Property</h5>

                                                            <div class="custom-control custom-checkbox float-right">
                                                                <input type="checkbox" name="show_about" class="custom-control-input" value="1" id="customCheck1">
                                                                <label class="custom-control-label" for="customCheck1">Show</label>
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="propertyamount">Property Price</label>
                                                                <input type="number" placeholder="Property Price" name="property_price" value="{{ old('property_price') }}" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="aboutText">Description</label>
                                                                <textarea name="about_property" class="form-control" id="aboutProperty"  placeholder="About text">{{ old('about_property') }}</textarea>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="">Property Image</label>
                                                                <input type="file" name="property_image" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                                <div class="ic-banner-part">
                                                    <h5>Summary</h5>
                                                       <div class="ic-about-card">
                                                         <div class="row">
                                                            <div class="col-lg-3">
                                                                <div class="form-group">
                                                                    <label for="aboutYear">Year Built</label>
                                                                    <input type="number" placeholder="Year Built" name="year" value="{{ old('year') }}" class="form-control">
                                                                </div>
                                                            </div>

                                                           <div class="col-lg-3">
                                                              <div class="form-group">
                                                                  <label for="SquareYear">Square Feet</label>
                                                                  <input type="number" placeholder="Square Feet" name="square_feets" value="{{ old('square_feets') }}" class="form-control">
                                                              </div>
                                                           </div>

                                                           <div class="col-lg-3">
                                                               <div class="form-group">
                                                                   <label for="BedroomsYear">Bedroom(s)</label>
                                                                   <input type="number" placeholder="Bedroom(s)" name="bedroom" value="{{ old('bedroom') }}" class="form-control">
                                                               </div>
                                                           </div>

                                                           <div class="col-lg-3">
                                                              <div class="form-group">
                                                                  <label for="BedroomsYear">Bathroom(s)</label>
                                                                  <input type="number" placeholder="Bathroom(s)" name="bathroom" value="{{ old('bathroom') }}" class="form-control">
                                                              </div>
                                                           </div>

                                                       </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="ic-button-submit float-right">
                                    <button class="btn btn-primary mr-2">Submit</button>
                                </div>
                            </form>



                                    {{-- <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="ic-banner-part">

                                                        <div class="form-group">
                                                            <label for="">Client</label>
                                                            <select name="user_id" id="selectUser" onchange="selectClient($(this).find(':selected').val())" class="form-control select2">
                                                                <option value="">Select Client</option>
                                                                @foreach ($users as $key=>$user)
                                                                    <option value="{{ $user->id }}" data-email="{{ $user->email }}">{{ $user->display_name }}</option>
                                                                @endforeach
                                                            </select>
                                                            @error('user_id')
                                                                <span class="text-danger">{{ $message }}</span>
                                                            @enderror
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">Theme Color #</label>
                                                            <ul>
                                                                <div id="themeColor"></div>
                                                            </ul>
                                                        </div>



                                                        <div class="form-group">
                                                            <label for="propertyaddress">Unit</label>
                                                            <input type="text" placeholder="Unit" name="unit" value="{{ old('unit') }}" class="form-control">
                                                            @error('unit')
                                                                <span class="text-danger">{{ $message }}</span>
                                                            @enderror
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="propertyaddress">Road Number</label>
                                                            <input type="text" placeholder="Road Number" name="road_number" value="{{ old('road_number') }}" class="form-control">
                                                            @error('road_number')
                                                                <span class="text-danger">{{ $message }}</span>
                                                            @enderror
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="propertyaddress">Road Name</label>
                                                            <input type="text" placeholder="Road Name" name="road_name" value="{{ old('road_name') }}" class="form-control">
                                                            @error('road_name')
                                                                <span class="text-danger">{{ $message }}</span>
                                                            @enderror
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="propertyaddress">Road Type</label>
                                                            <select name="road_type" id="" class="form-control select2-tag">
                                                                <option value="">Select Road Type</option>
                                                                @foreach($road_types as $key=>$road_type)
                                                                    <option value="{{ $road_type }}">{{ $road_type }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="propertyaddress">City</label>
                                                            <select name="city" id="" class="form-control select2-tag">
                                                                <option value="">Select City</option>
                                                                @foreach($cities as $key=>$citiy)
                                                                    <option value="{{ $citiy }}">{{ $citiy }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>

                                                    </div>

                                                    <div class="ic-banner-part">
                                                        <h5>About Part</h5>

                                                        <div class="custom-control custom-checkbox float-right">
                                                            <input type="checkbox" name="show_about" class="custom-control-input" value="1" id="customCheck1">
                                                            <label class="custom-control-label" for="customCheck1">Show</label>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="propertyamount">Property Amount</label>
                                                            <input type="number" placeholder="Property Amount" name="property_price" value="{{ old('property_price') }}" class="form-control">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="aboutText">About Text</label>
                                                            <textarea name="about_property" class="form-control" id="aboutProperty"  placeholder="About text">{{ old('about_property') }}</textarea>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="">Property Image</label>
                                                            <input type="file" name="property_image" class="form-control">
                                                        </div>
                                                    </div>

                                                    <div class="ic-banner-part">
                                                        <h5>About Card</h5>
                                                        <div class="ic-about-card p-2 border">
                                                            <div class="form-group">
                                                                <label for="aboutYear">Yera Of Build year</label>
                                                                <input type="number" placeholder="Yera Of Build year" name="year" value="{{ old('year') }}" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="SquareYear">Square Feets</label>
                                                                <input type="number" placeholder="Square Feets" name="square_feets" value="{{ old('square_feets') }}" class="form-control">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="BedroomsYear">Bedrooms Number</label>
                                                                <input type="number" placeholder="Bedrooms Number" name="bedroom" value="{{ old('bedroom') }}" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="BedroomsYear">Bathrooms Number</label>
                                                                <input type="number" placeholder="Bathrooms Number" name="bathroom" value="{{ old('bathroom') }}" class="form-control">
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <div class="ic-banner-part">
                                                        <h5>PVFM</h5>
                                                        <ul class="nav nav-pills p-0" id="pills-tab" role="tablist">
                                                            <li class="nav-item">
                                                                <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#p" role="tab" aria-controls="pills-home" aria-selected="true">P</a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#v" role="tab" aria-controls="pills-profile" aria-selected="false">V</a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#f" role="tab" aria-controls="pills-contact" aria-selected="false">F</a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#m" role="tab" aria-controls="pills-contact" aria-selected="false">M</a>
                                                            </li>

                                                            <li class="nav-item">
                                                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pa" role="tab" aria-controls="pills-contact" aria-selected="false">Pa</a>
                                                            </li>
                                                        </ul>
                                                        <div class="tab-content ic-tab-content-wrap" id="pills-tabContent">
                                                            <div class="tab-pane fade show active" id="p" role="tabpanel" aria-labelledby="pills-home-tab">
                                                                <div class="ic-about-card p-2 border">
                                                                    <div class="form-group">
                                                                        <label for="">Upload Photo</label>
                                                                        <input type="file" name="p_photo[]" placeholder="Upload Photo" class="form-control" multiple="">
                                                                    </div>
                                                                </div>

                                                                <button type="button" onclick="sendPEmail()" class="btn btn-success btn-sm text-white ic-send-button">Send</button>
                                                            </div>
                                                            <div class="tab-pane fade" id="v" role="tabpanel" aria-labelledby="pills-profile-tab">
                                                                <div class="ic-about-card p-2 border">
                                                                    <div class="form-group">
                                                                        <label for="videoLink">video link</label>
                                                                        <input type="text" placeholder="video link" name="p_video_link" value="{{ old('p_video_link') }}" class="form-control">
                                                                    </div>
                                                                </div>

                                                                <button type="button" onclick="sendVideoEmail()" class="btn btn-success btn-sm text-white">Send</button>
                                                            </div>
                                                            <div class="tab-pane fade" id="f" role="tabpanel"  aria-labelledby="pills-contact-tab">
                                                                <div class="ic-about-card p-2 border">
                                                                    <div class="form-group">
                                                                        <label for="">Upload Floor Plan</label>
                                                                        <input type="file" placeholder="Upload Photo" name="p_floor_plan" class="form-control" multiple="">
                                                                    </div>
                                                                </div>

                                                                <button type="button" onclick="sendFloorEmail()" class="btn btn-success btn-sm text-white">Send</button>
                                                            </div>
                                                            <div class="tab-pane fade" id="m" role="tabpanel" aria-labelledby="pills-contact-tab">
                                                                <div class="form-group">
                                                                    <label for="videoLink">Metterport Embeded Code</label>
                                                                    <textarea class="form-control" name="p_metterport" placeholder="Metterport Embeded Code">{{ old('p_metterport') }}</textarea>
                                                                </div>

                                                                <button type="button" onclick="sendMetterEmail()" class="btn btn-success btn-sm text-white">Send</button>
                                                            </div>

                                                            <div class="tab-pane fade" id="pa" role="tabpanel" aria-labelledby="pills-home-tab">
                                                                <div class="ic-about-card p-2 border">
                                                                    <div class="form-group">
                                                                        <label for="">Panorama Photo</label>
                                                                        <input type="file" name="panorama" placeholder="Panorama" class="form-control">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="">Room Name</label><br>
                                                                        <select name="p_room_name[]" id="" class="form-control select2-multi" style="width:100%;" multiple="">
                                                                            @foreach($room_names as $key=>$room_name)
                                                                                <option value="{{ $room_name }}">{{ $room_name }}</option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                </div>


                                                                <button type="button" onclick="sendPanoramaEmail()" class="btn btn-success btn-sm text-white ic-send-button">Send</button>

                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="ic-button-submit">
                                                        <button class="btn btn-primary mr-2">Submit</button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div> --}}



                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@include('admin.storyboard.email_model.p_model')
@include('admin.storyboard.email_model.v_model')
@include('admin.storyboard.email_model.f_model')
@include('admin.storyboard.email_model.m_model')
@include('admin.storyboard.email_model.pa_model')


@endsection

@section('css')

@endsection

@section('js')
<script type="text/javascript" src="{{ asset('dashboard/assets/js/plugins/tinymce/tinymce.min.js') }}" referrerpolicy="origin"></script>
{{-- <script
    type="text/javascript"
    src='https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js'
    referrerpolicy="origin">
  </script> --}}
  <script src="https://cdn.tiny.cloud/1/bv4pyu6ub1by8idjsr8gydy6ckw8m1xnmqy5yhmjjzwl044g/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  <script id="api-key" defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB1taAMFjjJDItj7VVzlvsTvVrixJHHNqc&callback=initMap&libraries=places"></script>
  {{-- <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?libraries=places&API=AIzaSyBKyhXsbW_uw5eq-G5jzZS4SMW7TICTh_M"></script> --}}
@endsection

@section('script')
<script>
    var clientEmail='';

    $(document).ready(function() {
        tinymce.init({
            selector: '#aboutProperty',
            toolbar: false,
            height: "400",
            content_style: 'body { font-family: "Roboto", sans-serif; }',
            statusbar: false
        });
    });

    // Google autocomplete
    window.onload = function() {
       initAutocomplete();
    }

    var autocomplete;
    function initAutocomplete(){
        autocomplete = new google.maps.places.Autocomplete(
        document.getElementById('autocomplete-input'), {types: ['geocode']});
        autocomplete.addListener('place_changed', getAddressDetails);
    }
    function getAddressDetails(){
        var place = autocomplete.getPlace();
        window.lat = place.geometry.location.lat();
        window.long = place.geometry.location.lng();
        console.log( +'-'+window.long);
        $('#locationLat').val(window.lat);
        $('#locationLng').val(window.long);
    }

    function geolocate(){
      if (navigator.geolocation){
        navigator.geolocation.getCurrentPosition(function(position){
          var geolocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
            var circle = new google.maps.Circle(
            {center: geolocation, radius: position.coords.accuracy});
            autocomplete.setBounds(circle.getBounds());
        });
      }
    }

    // Select client
    function selectClient(client_id)
    {
        clientEmail=$('#selectUser option:selected').attr('data-email');

        // $('#themeColor').html('');
        // if (client_id) {
        //     $.ajax({
        //         url:"{{ route('admin.theme.color') }}",
        //         method:'GET',
        //         data:{'client_id':client_id},
        //         success:function(response){
        //             console.log(response.theme_color)
        //             // let theme=[];
        //             // theme.push({id:'', text: 'Select Theme'});
        //             for (var i = 0; i < response.theme_color.length; i++) {
        //                 $('#themeColor').append(`<li class="mt-2"><input type="radio" name="theme_color" value="${response.theme_color[i].color}">&nbsp;&nbsp;&nbsp;<input type="color" value="${response.theme_color[i].color}" disabled ></li>`);
        //                 // theme.push({id:response.theme_color[i].id, text: response.theme_color[i].color});
        //             }
        //             // $(".select-theme").html('').select2({data: theme});
        //         },
        //         error:function(error){
        //             console.log(error);
        //         }
        //     });
        // }else{
        //     console.log('not found');
        // }
    }

    function sendPEmail()
    {
        if (clientEmail.length>0) {
            $('#pModal').modal('show');
            $('#formEmail').val(clientEmail);
        }else{
            toastr.error("Please Select A Client");
        }

    }

    function sendVideoEmail()
    {
        if (clientEmail.length>0) {
            $('#videoModal').modal('show');
            $('#vformEmail').val(clientEmail);
        }else{
            toastr.error("Please Select A Client");
        }
    }

    function sendFloorEmail()
    {
        if (clientEmail.length>0) {
            $('#foorModal').modal('show');
            $('#fformEmail').val(clientEmail);
        }else{
            toastr.error("Please Select A Client");
        }
    }

    function sendMetterEmail()
    {
        if (clientEmail.length>0) {
            $('#metterModal').modal('show');
            $('#mformEmail').val(clientEmail);
        }else{
            toastr.error("Please Select A Client");
        }
    }

    function sendPanoramaEmail()
    {
       if (clientEmail.length>0) {
           $('#panaromaModal').modal('show');
           $('#paformEmail').val(clientEmail);
       }else{
           toastr.error("Please Select A Client");
       }
    }

    // Add Panorama Photo Funcaiton
    let i=1;
    function addMorePanorama()
    {
        $('#panoramaPhoto').append(`
                    <div class="ic-panorama-photo git pull --allrow pRow${i}">
                        <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <select name="p_room_name[]" id="" class="form-control select2-tag" style="width:100%;">
                                    <option selected >Select Room Type</option>
                                    @foreach($room_names as $key=>$room_name)
                                        <option value="{{ $room_name }}">{{ $room_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <input type="file" class="form-control" name="panorama[]">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <button type="button" onclick="reomvePanoramaPhoto(${i})" class="btn btn-danger btn-sm mt-2">Remove</button>
                            </div>
                        </div>
                    </div></div>`);
        i++;

        select2tags();

    }

    function reomvePanoramaPhoto(i)
    {
        // console.log(i);
        $(`.pRow${i}`).remove();
    }

    function select2tags()
    {
        $('.select2-tag').select2({
            tags: true,
            dropdownCssClass : 'bigdrop'
        });
    }

</script>

@endsection
