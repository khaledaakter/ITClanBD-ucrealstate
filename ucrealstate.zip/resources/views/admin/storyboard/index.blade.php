@extends('admin.layouts.master')


@section('content')

<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-6">
                                        <div class="page-header-title">
                                            <h5>Property List</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#"><i class="fas fa-user-tie"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#">Property List</a></li>
                                        </ul>
                                    </div>

                                    @can('Add Property')
                                        <div class="col-md-6">
                                            <a href="{{ route('admin.storyboard.create') }}" class="btn btn-success btn-sm float-right">Add Property</a>
                                        </div>
                                    @endcan

                                </div>
                            </div>
                        </div>
                        <!-- [ breadcrumb ] end -->

                        <!-- [ Main Content ] start -->
                        <div class="row">
                            <!-- Column Rendering table start -->
                            <div class="col-sm-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Property List</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive dt-responsive">
                                            <table id="colum-rendr" class="table table-striped table-bordered nowrap">
                                                <thead>
                                                    <tr>
                                                    <th>Sl.</th>
                                                        <th>CLIENT</th>
                                                        <th>PROGRESS</th>
                                                        <th>DATE</th>
                                                        <th>ADDRESS</th>
                                                        <th>INVOICE</th>
                                                        <th>STATUS</th>
                                                        @canany(['Delete Property'])
                                                        <th>Action</th>
                                                        @endcanany
                                                        <th>FAVORITR</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @php
                                                        $i=1;
                                                    @endphp
                                                    @foreach ($storyBoareds as $storyBoared)
                                                        <tr>
                                                            <td>{{ $i++ }}</td>
                                                            @can('Edit Property')
                                                                <td><a href="{{ route('admin.storyboard.edit',[$storyBoared->id]) }}">{{ $storyBoared->user->full_name }}</a></td>
                                                            @else
                                                             <td>{{ $storyBoared->user->full_name }}</td>
                                                            @endcan

                                                            <td>
                                                                <p class="ic-progress-list {{ $storyBoared->status==1?'text-primary':'' }}">

                                                                    @foreach($storyBoared->allServices as $key=>$storyboardservice)
                                                                        <a href="javascript:void(0)">@if ($storyboardservice->service_p)<i class="fas fa-check text-success"></i>@endif P </a>
                                                                        <a href="javascript:void(0)">@if ($storyboardservice->service_v)<i class="fas fa-check text-success"></i>@endif V </a>
                                                                        <a href="javascript:void(0)">@if ($storyboardservice->service_f)<i class="fas fa-check text-success"></i>@endif F </a>
                                                                        <a href="javascript:void(0)">@if ($storyboardservice->service_m)<i class="fas fa-check text-success"></i>@endif M </a>
                                                                        <a href="javascript:void(0)">@if ($storyboardservice->service_pa)<i class="fas fa-check text-success"></i>@endif Pa </a>
                                                                    @endforeach
                                                                </p>
                                                            </td>
                                                            <td>{{ $storyBoared->updated_at_format }}</td>
                                                            <td><a href="{{ route('show.property',[$storyBoared->user->user_name,$storyBoared->slug]) }}" target="_blank">{{ $storyBoared->property_address }}</a></td>

                                                            <td>
                                                                <form action="" class="ic-invoice-checkbox text-center">
                                                                    <input type="checkbox" {{ $storyBoared->invoice?'checked':'' }} onclick="selectInvoice({{ $storyBoared->id }},this.value)" name="invoice" value="{{ $storyBoared->invoice }}">
                                                                </form>
                                                            </td>

                                                            <td>
                                                                {!! $storyBoared->story_board_status !!}
                                                            </td>
                                                            @canany(['Delete Property'])
                                                                <td>
                                                                    <div class="ic-action-button">
                                                                    @can('Delete Property')
                                                                            <a class="dropdown-item btn-danger btn-sm" href="javascript:void(0)" onclick="makeDeleteRequest(event,'{{ $storyBoared->id }}')"><i class="fas fa-trash-alt"></i> Delete</a>

                                                                            <form action="{{ route('admin.storyboard.destroy',[$storyBoared->id]) }}" method="POST" id="delete-form-{{ $storyBoared->id }}">
                                                                                @csrf
                                                                                @method('DELETE')
                                                                            </form>
                                                                    @endcan
                                                                    </div>
                                                                </td>
                                                            @endcanany

                                                            <td>
                                                                <form action="" class="ic-invoice-checkbox text-center">
                                                                    <div class="rate">
                                                                        <input type="checkbox" {{ $storyBoared->favorite?'checked':'' }} onclick="selectFavorite({{ $storyBoared->id }},this.value)" id="star{{ $storyBoared->id }}" name="rate" value="{{ $storyBoared->favorite }}" />
                                                                        <label for="star{{ $storyBoared->id }}" title="text"></label>
                                                                    </div>

                                                                </form>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


    @foreach ($storyBoareds as $key=>$storyBoared)
        <div class="modal fade" id="StoryBoard-{{ $storyBoared->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Story Board Quick View</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                @if (count($storyBoared->boardGalleries)>0)
                    <span class="storyBoardItem type-p">
                         <label for="">P</label><br>
                        @foreach ($storyBoared->boardGalleries as $boardGallerie)
                            <img src="{{ Storage::url($boardGallerie->image) }}" width="20%" class="img-fluid" alt="images">
                        @endforeach
                    </span>
                @endif

                @if ($storyBoared->p_video_link)
                    <span class="storyBoardItem type-v">
                        <div class="form-group">
                            <label for="videoLink">video link</label><br>
                            <input type="text" class="form-control" value="{{ $storyBoared->p_video_link }}">
                        </div>
                    </span>
                @endif

                @if ($storyBoared->p_floor_plan)
                    <span class="storyBoardItem type-f">
                        <label for="">F</label><br>
                        @if (strpos($storyBoared->p_floor_plan, 'pdf') !== false)
                            <embed src="{{ Storage::url('story_file') }}/{{ $storyBoared->p_floor_plan }}" style="width:400px; height:600px;" frameborder="0">
                        @else
                           <img src="{{ Storage::url('story_file') }}/{{ $storyBoared->p_floor_plan }}" width="20%" class="img-fluid" alt="images">
                        @endif
                    </span>
                @endif

                @if ($storyBoared->p_metterport)
                    <span class="storyBoardItem type-m">
                        <div class="form-group">
                            <label for="">M</label><br>
                            <textarea class="form-control" id="" cols="3" rows="5">{{ $storyBoared->p_metterport }}</textarea>
                        </div>
                    </span>
                @endif

                @if (count($storyBoared->panoramas)>0)
                    <span class="storyBoardItem type-pa">
                        @foreach ($storyBoared->panoramas as $panorama)
                            <img src="{{ Storage::url($panorama->panorama_photo) }}" width="20%" class="img-fluid" alt="images">
                        @endforeach
                    </span>
                @endif

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
    @endforeach

@endsection

@section('script')

<script>
    function showStoryBoard(event,storyBoard_id,type)
    {
        event.preventDefault();
        $(`#StoryBoard-${storyBoard_id}`).modal('show');
        $('.storyBoardItem').hide();
        $(`.type-${type}`).show();

    }

    // Invoice chicked
    function selectInvoice(id,invoice)
    {
        // console.log(invoice);
        $.ajax({
            url:"{{ route('admin.storyboard.update_invoice') }}",
            method:"GET",
            data:{'storyboard_id':id,invoice},
            success:function(response){
                if(response.storyboard)
                {
                    toastr.success("Invoice Update Successfully");
                }
            },
            error:function(error){
                toastr.error("Somethings is proble");
            }
        })
    }
    // Favorite
    function selectFavorite(id,favorite)
    {
        $.ajax({
            url:"{{ route('admin.storyboard.update_favorite') }}",
            method:"GET",
            data:{'storyboard_id':id,favorite},
            success:function(response){
                if(response.storyboard)
                {
                    toastr.success("Favorite Update Successfully");
                }
            },
            error:function(error){
                toastr.error("Somethings is proble");
            }
        })
    }
</script>

@endsection
