<div class="modal fade" id="pModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Send Email</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="{{ route('admin.storyboard.send.photo') }}" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                @csrf

                <input type="hidden" value="" name="from_email" id="formEmail">

                <div class="form-group">
                  <input type="text" name="subject" class="form-control" placeholder="Subject">
                </div>

                <div class="form-group">
                  <textarea name="message" id="" cols="5" rows="3" class="form-control" placeholder="Message"></textarea>
                </div>

                <div class="form-group">
                  <input type="text" name="footer" class="form-control" placeholder="Footer">
                </div>

                <div class="form-group">
                  <input type="file" name="file" accept=".zip">
                </div>

            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary"><i class="far fa-paper-plane"></i>&nbsp;&nbsp;Save Email</button>
            </div>
        </form>
    </div>
  </div>
</div>