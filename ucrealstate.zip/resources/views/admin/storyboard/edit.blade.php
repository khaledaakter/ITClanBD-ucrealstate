@extends('admin.layouts.master')




@section('content')


<div class="ic-main-container">
    <div class="ic-wrapper">
        <div class="ic-content">
            <div class="ic-inner-content">
                <div class="main-body">
                    <div class="page-wrapper">
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-12">
                                        <div class="page-header-title">
                                            <h5>Property Update</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#"><i class="feather icon-edit-1"></i></a></li>
                                            <li class="breadcrumb-item"><a href="#">Storyboard Update</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-12">
                                <form action="{{ route('admin.storyboard.update',[$storyBoared->id]) }}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    @method('PUT')


                                    <div class="row">

                                        <div class="col-xl-6">

                                                <div class="card">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="form-group">
                                                                    <label for="">Client</label>
                                                                    <select name="user_id" id="selectUser" onchange="selectClient($(this).find(':selected').val())" class="form-control select2">
                                                                        <option value="">Select Client</option>
                                                                        @foreach ($users as $key=>$user)
                                                                            <option {{ $storyBoared->user_id==$user->id?'selected':'' }} value="{{ $user->id }}" data-email="{{ $user->email }}">{{ $user->display_name }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                    @error('user_id')
                                                                        <span class="text-danger">{{ $message }}</span>
                                                                    @enderror
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="card">
                                                    <div class="card-body">
                                                        <div class="row ic-card-address">

                                                            <div class="col-lg-2 row">
                                                                <div class="form-group">
                                                                    <label for="propertyaddress">Unit</label>
                                                                    <input type="text" placeholder="Unit" name="unit" value="{{ $storyBoared->unit }}" class="form-control">
                                                                    @error('unit')
                                                                        <span class="text-danger">{{ $message }}</span>
                                                                    @enderror
                                                                </div>
                                                            </div>

                                                            <div class="col-lg-3">
                                                                <div class="form-group">
                                                                    <label for="propertyaddress">Road Number</label>
                                                                    <input type="text" placeholder="Road Number" name="road_number" value="{{ $storyBoared->road_number }}" class="form-control">
                                                                    @error('road_number')
                                                                        <span class="text-danger">{{ $message }}</span>
                                                                    @enderror
                                                                </div>
                                                            </div>

                                                            <div class="col-lg-3 row">
                                                                <div class="form-group">
                                                                    <label for="propertyaddress">Road Name</label>
                                                                    <input type="text" placeholder="Road Name" name="road_name" value="{{ $storyBoared->road_name }}" class="form-control">
                                                                    @error('road_name')
                                                                        <span class="text-danger">{{ $message }}</span>
                                                                    @enderror
                                                                </div>
                                                            </div>

                                                            <div class="col-lg-2">
                                                                <div class="form-group">
                                                                    <label for="propertyaddress">Road Type</label>
                                                                    <select name="road_type" id="" class="form-control select2-tag">
                                                                        <option value="">Select Road Type</option>
                                                                        @foreach($road_types as $key=>$road_type)
                                                                            <option {{ $storyBoared->road_type==$road_type?'selected':'' }} value="{{ $road_type }}">{{ $road_type }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                            </div>


                                                            <div class="col-lg-2">
                                                                <div class="form-group">
                                                                    <label for="propertyaddress">City</label>
                                                                    <select name="city" id="" class="form-control select2-tag">
                                                                        <option value="">Select City</option>
                                                                        @foreach($cities as $key=>$citiy)
                                                                            <option {{ $storyBoared->city==$citiy?'selected':'' }} value="{{ $citiy }}">{{ $citiy }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="form-group">
                                                                    <label for="videoLink">Location</label>
                                                                    <input type="text" placeholder="Location" id="autocomplete-input" name="location" value="{{ $storyBoared->location }}" class="form-control">
                                                                </div>
                                                                <input type="text" id="locationLat" name="latitude" class="form-control d-none" value="{{ $storyBoared->latitude }}" name="lat">
                                                                <input type="text" id="locationLng" name="longitude" class="form-control d-none" value="{{ $storyBoared->longitude }}" name="lng">
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>

                                                <div class="card">
                                                    <div class="card-body">
                                                        <div class="row">

                                                            <div class="ic-banner-part">
                                                                <h5>Services</h5>
                                                                <div class="container">
                                                                    <div class="row">
                                                                        <ul class="ic-ul">
                                                                            <li class="ic-li">
                                                                              <input type="checkbox" class="ic-checkbox" {{ $storyBoared->flickr_photo_set_id?'checked':'' }} id="ic-p" name="service[p]" value="1"/>
                                                                              <label for="ic-p" class="ic-label">P</label>
                                                                            </li>
                                                                            <li class="ic-li">

                                                                              <input type="checkbox" class="ic-checkbox" {{ $storyBoared->service->service_v==1?'checked':'' }} id="ic-v" name="service[v]" value="1"/>
                                                                              <label for="ic-v" class="ic-label">V</label>
                                                                            </li>
                                                                            <li class="ic-li">
                                                                              <input type="checkbox" class="ic-checkbox" {{ $storyBoared->service->service_f==1?'checked':'' }} id="ic-f" name="service[f]" value="1"/>
                                                                              <label for="ic-f" class="ic-label">F</label>
                                                                            </li>
                                                                            <li class="ic-li">
                                                                                <input type="checkbox" class="ic-checkbox" id="ic-m" {{ $storyBoared->service->service_m==1?'checked':'' }} name="service[m]" value="1"/>
                                                                                <label for="ic-m" class="ic-label">M</label>
                                                                            </li>
                                                                            <li class="ic-li">
                                                                                <input type="checkbox" class="ic-checkbox" id="ic-pa" {{ $storyBoared->service->service_pa==1?'checked':'' }} name="service[pa]" value="1"/>
                                                                                <label for="ic-pa" class="ic-label">Pa</label>
                                                                            </li>
                                                                          </ul>
                                                                    </div>
                                                                </div>

                                                                <ul class="nav nav-pills p-0" id="pills-tab" role="tablist">
                                                                    <li class="nav-item">
                                                                        <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#p" role="tab" aria-controls="pills-home" aria-selected="true">P</a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#v" role="tab" aria-controls="pills-profile" aria-selected="false">V</a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#f" role="tab" aria-controls="pills-contact" aria-selected="false">F</a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#m" role="tab" aria-controls="pills-contact" aria-selected="false">M</a>
                                                                    </li>

                                                                    <li class="nav-item">
                                                                        <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pa" role="tab" aria-controls="pills-contact" aria-selected="false">Pa</a>
                                                                    </li>
                                                                </ul>
                                                                <div class="tab-content" id="pills-tabContent">
                                                                    <div class="tab-pane fade show active ic-tab-content-wrap" id="p" role="tabpanel" aria-labelledby="pills-home-tab">
                                                                        <div class="ic-about-card p-2 border">


                                                                            <div class="form-group">
                                                                                <label for="">Dropbox Download link</label>
                                                                                <input type="url" value="{{ $storyBoared->dropbox_url }}" name="dropbox_url" placeholder="Dropbox Download link" class="form-control">
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label for="">Flickr PhotosetID</label>
                                                                                <input type="text" value="{{ $storyBoared->flickr_photo_set_id }}" name="flickr_photo_set_id" placeholder="Flickr PhotosetID" class="form-control">
                                                                            </div>

                                                                        </div>
                                                                        {{-- <button type="button" onclick="sendPEmail()" id="p-send-email" class="btn btn-success btn-sm text-white ic-send-button">{{ $storyBoared->p_email==0?'Send':'Sent' }}</button> --}}
                                                                    </div>
                                                                    <div class="tab-pane fade ic-tab-content-wrap" id="v" role="tabpanel" aria-labelledby="pills-profile-tab">
                                                                        <div class="ic-about-card p-2 border">
                                                                            <div class="form-group">
                                                                                <label for="videoLink">Video link</label>
                                                                                <input type="text" placeholder="video link" name="p_video_link" value="{{ $storyBoared->p_video_link }}" class="form-control" onchange="getEmbedCode($(this).val())">

                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label for="videoLink">Download link</label>
                                                                                <input type="text" placeholder="Download link" name="p_download_link" value="{{ $storyBoared->p_download_link }}" class="form-control">
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label for="videoLink">Embed Code</label>
                                                                                <textarea name="" id="" placeholder="Embed Code" class="form-control v-embed-code" cols="5" rows="3">{{ $storyBoared->p_video_iframe }}</textarea>
                                                                            </div>


                                                                        </div>
                                                                        <button type="button" onclick="sendVideoEmail()" id="v-send-email" class="btn btn-success btn-sm text-white ic-send-button">{{ $storyBoared->v_email==0?'Send':'Sent' }}</button>
                                                                    </div>
                                                                    <div class="tab-pane fade ic-tab-content-wrap" id="f" role="tabpanel"  aria-labelledby="pills-contact-tab">
                                                                        <div class="ic-about-card p-2 border">

                                                                            <div class="form-group">
                                                                              <label for="">Brand jpeg</label>
                                                                              <input type="file" name="p_floor_plan" class="image_one form-control" accept="image/jpeg">
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label for="">No Brand jpeg</label>
                                                                              <input type="file" name="" class="image_two form-control" accept="image/jpeg">
                                                                                <img style="width: 90px;margin-top: 10px;" src="{{ asset(Storage::url('story_file/'.$storyBoared->p_no_brand)) }}" alt="">
                                                                            </div>

                                                                            <div class="form-group">
                                                                                <label for="">PDF</label>
                                                                                <input type="file" name="" class="pdf_file form-control" accept="application/pdf">
                                                                                @if($storyBoared->p_pdf)
                                                                                    <a href="#" class=""><i class="far fa-folder"></i></a>
                                                                                @endif
                                                                            </div>

                                                                            <div class="ic-banner-img">
                                                                                <div class="ic-images-div">
                                                                                    @if ($storyBoared->p_floor_plan)
                                                                                        <div class="ic-images-items">
                                                                                            <div class="ic-items-img">

                                                                                                @if (strpos($storyBoared->p_floor_plan, 'pdf') !== false)

                                                                                                    <embed src="{{ Storage::url('story_file') }}/{{ $storyBoared->p_floor_plan }}" style="width:400px; height:600px;" frameborder="0">
                                                                                                    <div class="ic-overlay">
                                                                                                        <a href="#" onclick="deleteStoryBoardFile(event,'{{ $storyBoared->id }}','p_floor_plan')" class="img-closed"> <i class="far fa-times-circle"></i></a>
                                                                                                    </div>

                                                                                                @else
                                                                                                   <img src="{{ Storage::url('story_file') }}/{{ $storyBoared->p_floor_plan }}" class="img-fluid" alt="images">
                                                                                                   <div class="ic-overlay">
                                                                                                       <a href="#" onclick="deleteStoryBoardFile(event,'{{ $storyBoared->id }}','p_floor_plan')" class="img-closed"> <i class="far fa-times-circle"></i></a>
                                                                                                   </div>
                                                                                                @endif

                                                                                            </div>
                                                                                        </div>
                                                                                    @endif
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                        <button type="button" onclick="sendFloorEmail()" id="f-send-email" class="btn btn-success btn-sm text-white ic-send-button">{{ $storyBoared->f_email==0?'Send':'Sent' }}</button>
                                                                    </div>
                                                                    <div class="tab-pane fade ic-tab-content-wrap" id="m" role="tabpanel" aria-labelledby="pills-contact-tab">
                                                                        <div class="form-group">
                                                                            <label for="videoLink">Metterport Embeded Code</label>
                                                                            <textarea class="form-control p-metterport" name="p_metterport" placeholder="Metterport Embeded Code">{{ $storyBoared->p_metterport }}</textarea>
                                                                        </div>

                                                                        <button type="button" onclick="sendMetterEmail()" id="m-send-email" class="btn btn-success btn-sm text-white ic-send-button">{{ $storyBoared->m_email==0?'Send':'Sent' }}</button>

                                                                    </div>

                                                                    <div class="tab-pane fade ic-tab-content-wrap" id="pa" role="tabpanel" aria-labelledby="pills-home-tab">
                                                                        <div class="ic-about-card p-2 border">
                                                                            <div class="row">
                                                                                <div class="col-md-4">
                                                                                    <label for="">Room Name</label>
                                                                                </div>
                                                                                <div class="col-md-4">
                                                                                    <label for="">Photo</label>
                                                                                </div>
                                                                                <div class="col-md-4">

                                                                                </div>
                                                                            </div>
                                                                            <div id="panoramaPhoto">

                                                                            </div>
                                                                            <button onclick="addMorePanorama()" type="button" class="btn btn-success btn-sm">Add More</button>


                                                                            <div class="ic-banner-img">
                                                                                <div class="ic-images-div">
                                                                                    @foreach ($storyBoared->panoramas as $panorama)
                                                                                        <div class="ic-images-items">
                                                                                            <div class="ic-items-img">
                                                                                                <img src="{{ Storage::url($panorama->panorama_photo) }}" class="img-fluid" alt="images">
                                                                                                <div class="ic-overlay">
                                                                                                    <a href="#" onclick="deleteStoryBoardFile(event,'{{ $panorama->id }}','panorama')" class="img-closed"> <i class="far fa-times-circle"></i></a>
                                                                                                </div>
                                                                                            </div>
                                                                                            <p class="panorma-image-text">{{ $panorama->p_room_name }}</p>
                                                                                        </div>
                                                                                    @endforeach
                                                                                </div>
                                                                            </div>
                                                                            {{-- @php
                                                                                $p_room_names=explode(",",$storyBoared->p_room_name);
                                                                            @endphp
                                                                            <div class="form-group">
                                                                                <label for="">Room Name</label><br>
                                                                                <select name="p_room_name[]" id="" class="form-control select2-multi" style="width:100%;" multiple="">
                                                                                    @foreach($room_names as $key=>$room_name)
                                                                                        <option {{ in_array($room_name,$p_room_names)?'selected':'' }} value="{{ $room_name }}">{{ $room_name }}</option>
                                                                                    @endforeach
                                                                                </select>
                                                                            </div> --}}
                                                                        </div>

                                                                        <button type="button" onclick="sendPanoramaEmail()" id="pa_email_send" class="btn btn-success btn-sm text-white ic-send-button">{{ $storyBoared->pa_email==0?'Send':'Sent' }}</button>

                                                                    </div>
                                                                </div>
                                                            </div>


                                                        </div>
                                                    </div>
                                                </div>
                                        </div>

                                        <div class="col-xl-6">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <div class="ic-banner-part">
                                                                <h5>About Property</h5>

                                                                <div class="custom-control custom-checkbox float-right">
                                                                    <input type="checkbox" name="show_about" {{ $storyBoared->show_about==1?'checked':'' }} class="custom-control-input" value="1" id="customCheck1">
                                                                    <label class="custom-control-label" for="customCheck1">Show</label>
                                                                </div>

                                                                <div class="form-group">
                                                                    <label for="propertyamount">Property Price</label>
                                                                    <input type="number" placeholder="Property Price" name="property_price" value="{{ $storyBoared->property_price }}" class="form-control">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="aboutText">Description</label>
                                                                    <textarea name="about_property" class="form-control" id="aboutProperty"  placeholder="About text">{!! $storyBoared->about_property !!}</textarea>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="">Property Image</label>
                                                                    <input type="file" name="property_image" class="form-control">
                                                                </div>

                                                                <div class="ic-banner-img">
                                                                    <div class="ic-images-div">
                                                                        @if ($storyBoared->property_image)
                                                                            <div class="ic-images-items">
                                                                                <div class="ic-items-img">
                                                                                    <img src="{{ Storage::url( $storyBoared->property_image ) }}" class="img-fluid" alt="images">
                                                                                    <div class="ic-overlay">
                                                                                        <a href="#" onclick="deleteStoryBoardFile(event,'{{ $storyBoared->id }}','property_image')" class="img-closed"> <i class="far fa-times-circle"></i></a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        @endif
                                                                    </div>
                                                                </div>

                                                            </div>
                                                        </div>

                                                    </div>

                                                    <div class="ic-banner-part">
                                                        <h5>Summary</h5>
                                                           <div class="ic-about-card">
                                                             <div class="row">
                                                                <div class="col-lg-3">
                                                                    <div class="form-group">
                                                                        <label for="aboutYear">Year Built</label>
                                                                        <input type="number" placeholder="Year Built" name="year" value="{{ $storyBoared->year }}" class="form-control">
                                                                    </div>
                                                                </div>

                                                               <div class="col-lg-3">
                                                                  <div class="form-group">
                                                                      <label for="SquareYear">Square Feet</label>
                                                                      <input type="number" placeholder="Square Feet" name="square_feets" value="{{ $storyBoared->square_feets }}" class="form-control">
                                                                  </div>
                                                               </div>

                                                               <div class="col-lg-3">
                                                                   <div class="form-group">
                                                                       <label for="BedroomsYear">Bedroom(s)</label>
                                                                       <input type="number" placeholder="Bedroom(s)" name="bedroom" value="{{ $storyBoared->bedroom }}" class="form-control">
                                                                   </div>
                                                               </div>

                                                               <div class="col-lg-3">
                                                                  <div class="form-group">
                                                                      <label for="BedroomsYear">Bathroom(s)</label>
                                                                      <input type="number" placeholder="Bathroom(s)" name="bathroom" value="{{ $storyBoared->bathroom }}" class="form-control">
                                                                  </div>
                                                               </div>

                                                           </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="ic-button-submit float-right">
                                        <button class="btn btn-primary mr-2">Update</button>
                                    </div>

                                    {{-- <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-lg-6">

                                                    <div class="ic-banner-part">
                                                        <h5>Banner Part</h5>


                                                        <div class="form-group">
                                                            <label for="">Client</label>
                                                            <select name="user_id" id="" onchange="selectClient($(this).find(':selected').val())" class="form-control select2">
                                                                <option value="">Select Client</option>
                                                                @foreach ($users as $key=>$user)
                                                                    <option {{ $storyBoared->user_id==$user->id?'selected':'' }} value="{{ $user->id }}">{{ $user->display_name }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">Theme Color #</label>
                                                            <ul>
                                                                <div id="themeColor">
                                                                    @foreach($client->themeColors as $key=>$theme_color)
                                                                        <li class="mt-2"><input type="radio" {{ $storyBoared->theme_color==$theme_color->color?'checked':'' }} name="theme_color" value="{{ $theme_color->color }}">&nbsp;&nbsp;&nbsp;<input type="color" value="{{ $theme_color->color }}"></li>
                                                                    @endforeach
                                                                </div>
                                                            </ul>
                                                        </div>


                                                        <div class="form-group">
                                                            <label for="propertyaddress">Unit</label>
                                                            <input type="text" placeholder="Unit" name="unit" value="{{ $storyBoared->unit }}" class="form-control">
                                                            @error('unit')
                                                                <span class="text-danger">{{ $message }}</span>
                                                            @enderror
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="propertyaddress">Road Number</label>
                                                            <input type="text" placeholder="Road Number" name="road_number" value="{{ $storyBoared->road_number }}" class="form-control">
                                                            @error('road_number')
                                                                <span class="text-danger">{{ $message }}</span>
                                                            @enderror
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="propertyaddress">Road Name</label>
                                                            <input type="text" placeholder="Road Name" name="road_name" value="{{ $storyBoared->road_name }}" class="form-control">
                                                            @error('road_name')
                                                                <span class="text-danger">{{ $message }}</span>
                                                            @enderror
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="propertyaddress">Road Type</label>
                                                            <select name="road_type" id="" class="form-control select2-tag">
                                                                <option value="">Select Road Type</option>
                                                                @foreach($road_types as $key=>$road_type)
                                                                    <option {{ $storyBoared->road_type==$road_type?'selected':'' }} value="{{ $road_type }}">{{ $road_type }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="propertyaddress">City</label>
                                                            <select name="city" id="" class="form-control select2-tag">
                                                                <option value="">Select City</option>
                                                                @foreach($cities as $key=>$citiy)
                                                                    <option {{ $storyBoared->city==$citiy?'selected':'' }} value="{{ $citiy }}">{{ $citiy }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>


                                                    </div>

                                                    <div class="ic-banner-part">
                                                        <h5>About Part</h5>

                                                        <div class="custom-control custom-checkbox float-right">
                                                            <input type="checkbox" {{ $storyBoared->show_about==1?'checked':'' }} name="show_about" class="custom-control-input" value="1" id="customCheck1">
                                                            <label class="custom-control-label" for="customCheck1">Show</label>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="propertyamount">Property Amount</label>
                                                            <input type="number" placeholder="Property Amount" value="{{ $storyBoared->property_price }}" name="property_price" class="form-control">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="aboutText">About Text</label>
                                                            <textarea name="about_property" id="aboutProperty" class="form-control"  placeholder="About text">{!! $storyBoared->about_property !!}</textarea>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="">Property Image</label>
                                                            <input type="file" name="property_image" class="form-control">
                                                        </div>
                                                        <div class="ic-banner-img">
                                                            <div class="ic-images-div">
                                                                @if ($storyBoared->property_image)
                                                                    <div class="ic-images-items">
                                                                        <div class="ic-items-img">
                                                                            <img src="{{ Storage::url( $storyBoared->property_image ) }}" class="img-fluid" alt="images">
                                                                            <div class="ic-overlay">
                                                                                <a href="#" onclick="deleteStoryBoardFile(event,'{{ $storyBoared->id }}','property_image')" class="img-closed"> <i class="far fa-times-circle"></i></a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="ic-banner-part">
                                                        <h5>About Card</h5>
                                                        <div class="ic-about-card p-2 border">
                                                            <div class="form-group">
                                                                <label for="aboutYear">Yera Of Build year</label>
                                                                <input type="number" placeholder="About Icons" name="year" value="{{ $storyBoared->year }}" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="SquareYear">Square Feets</label>
                                                                <input type="number" placeholder="Square Feets" name="square_feets" value="{{ $storyBoared->square_feets }}" class="form-control">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="BedroomsYear">Bedrooms Number</label>
                                                                <input type="number" placeholder="Bedrooms Number" name="bedroom" value="{{ $storyBoared->bedroom }}" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="BedroomsYear">Bathrooms Number</label>
                                                                <input type="number" placeholder="Bathrooms Number" name="bathroom" value="{{ $storyBoared->bathroom }}" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="ic-banner-part">
                                                        <h5>PVFM</h5>
                                                        <ul class="nav nav-pills p-0" id="pills-tab" role="tablist">
                                                            <li class="nav-item">
                                                                <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#p" role="tab" aria-controls="pills-home" aria-selected="true">P</a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#v" role="tab" aria-controls="pills-profile" aria-selected="false">V</a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#f" role="tab" aria-controls="pills-contact" aria-selected="false">F</a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#m" role="tab" aria-controls="pills-contact" aria-selected="false">M</a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pa" role="tab" aria-controls="pills-contact" aria-selected="false">Pa</a>
                                                            </li>
                                                        </ul>
                                                        <div class="tab-content" id="pills-tabContent">
                                                            <div class="tab-pane fade show active" id="p" role="tabpanel" aria-labelledby="pills-home-tab">
                                                                <div class="ic-about-card p-2 border">
                                                                    <div class="form-group">
                                                                        <label for="">Upload Photo</label>
                                                                        <input type="file" name="p_photo[]" placeholder="Upload Photo" class="form-control" multiple="">
                                                                    </div>

                                                                    <div class="ic-banner-img">
                                                                        <div class="ic-images-div">
                                                                            @if (count($storyBoared->boardGalleries)>0)
                                                                                @foreach ($storyBoared->boardGalleries as $boardGallerie)
                                                                                    <div class="ic-images-items">
                                                                                        <div class="ic-items-img">
                                                                                            <img src="{{ Storage::url($boardGallerie->image) }}" class="img-fluid" alt="images">
                                                                                            <div class="ic-overlay">
                                                                                                <a href="#" onclick="removeFile(event,'{{ $boardGallerie->id }}','gallery')" class="img-closed"> <i class="far fa-times-circle"></i></a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                @endforeach
                                                                            @endif
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <div class="tab-pane fade" id="v" role="tabpanel" aria-labelledby="pills-profile-tab">
                                                                <div class="ic-about-card p-2 border">
                                                                    <div class="form-group">
                                                                        <label for="videoLink">video link</label>
                                                                        <input type="text" placeholder="video link" name="p_video_link" value="{{ $storyBoared->p_video_link }}" class="form-control">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane fade" id="f" role="tabpanel"  aria-labelledby="pills-contact-tab">
                                                                <div class="ic-about-card p-2 border">
                                                                    <div class="form-group">
                                                                        <label for="">Upload Floor Plan</label>
                                                                        <input type="file" placeholder="Upload Photo" name="p_floor_plan" class="form-control" multiple="">
                                                                    </div>
                                                                    <div class="ic-banner-img">
                                                                        <div class="ic-images-div">
                                                                            @if ($storyBoared->p_floor_plan)
                                                                                <div class="ic-images-items">
                                                                                    <div class="ic-items-img">

                                                                                        @if (strpos($storyBoared->p_floor_plan, 'pdf') !== false)

                                                                                            <embed src="{{ Storage::url('story_file') }}/{{ $storyBoared->p_floor_plan }}" style="width:400px; height:600px;" frameborder="0">
                                                                                            <div class="ic-overlay">
                                                                                                <a href="#" onclick="deleteStoryBoardFile(event,'{{ $storyBoared->id }}','p_floor_plan')" class="img-closed"> <i class="far fa-times-circle"></i></a>
                                                                                            </div>

                                                                                        @else
                                                                                           <img src="{{ Storage::url('story_file') }}/{{ $storyBoared->p_floor_plan }}" class="img-fluid" alt="images">
                                                                                           <div class="ic-overlay">
                                                                                               <a href="#" onclick="deleteStoryBoardFile(event,'{{ $storyBoared->id }}','p_floor_plan')" class="img-closed"> <i class="far fa-times-circle"></i></a>
                                                                                           </div>
                                                                                        @endif

                                                                                    </div>
                                                                                </div>
                                                                            @endif
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="tab-pane fade" id="m" role="tabpanel" aria-labelledby="pills-contact-tab">
                                                                <div class="form-group">
                                                                    <label for="videoLink">Metterport Embeded Code</label>
                                                                    <textarea class="form-control" name="p_metterport" placeholder="Metterport Embeded Code">{{ $storyBoared->p_metterport }}</textarea>
                                                                </div>
                                                            </div>

                                                            <div class="tab-pane fade" id="pa" role="tabpanel" aria-labelledby="pills-home-tab">
                                                                <div class="ic-about-card p-2 border">
                                                                    <div class="form-group">
                                                                        <label for="">Panorama Photo</label>
                                                                        <input type="file" name="panorama" placeholder="Panorama" class="form-control">
                                                                    </div>

                                                                    <div class="ic-banner-img">
                                                                        <div class="ic-images-div">
                                                                            @if ($storyBoared->panorama)
                                                                                <div class="ic-images-items">
                                                                                    <div class="ic-items-img">
                                                                                        <img src="{{ Storage::url($storyBoared->panorama) }}" class="img-fluid" alt="images">
                                                                                        <div class="ic-overlay">
                                                                                            <a href="#" onclick="deleteStoryBoardFile(event,'{{ $storyBoared->id }}','panorama')" class="img-closed"> <i class="far fa-times-circle"></i></a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            @endif
                                                                        </div>
                                                                    </div>
                                                                    @php
                                                                        $p_room_names=explode(",",$storyBoared->p_room_name);
                                                                    @endphp
                                                                    <div class="form-group">
                                                                        <label for="">Room Name</label><br>
                                                                        <select name="p_room_name[]" id="" class="form-control select2-multi" style="width:100%;" multiple="">
                                                                            @foreach($room_names as $key=>$room_name)
                                                                                <option {{ in_array($room_name,$p_room_names)?'selected':'' }} value="{{ $room_name }}">{{ $room_name }}</option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>



                                                    <div class="ic-banner-part">
                                                        <h5>Location</h5>
                                                        <div class="form-group">
                                                            <div class="form-group">
                                                                <label for="videoLink">Location</label>
                                                                <input type="text" placeholder="Location" id="autocomplete-input" name="location" value="{{ $storyBoared->location }}" class="form-control">
                                                            </div>

                                                            <input type="text" id="locationLat" name="latitude" class="form-control d-none" value="{{ $storyBoared->latitude }}" name="lat">
                                                            <input type="text" id="locationLng" name="longitude" class="form-control d-none" value="{{ $storyBoared->longitude }}" name="lng">
                                                        </div>

                                                    </div>

                                                    <div class="ic-button-submit">
                                                        <button class="btn btn-primary mr-2">Update</button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div> --}}

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@include('admin.storyboard.email_model.p_model')
@include('admin.storyboard.email_model.v_model')
@include('admin.storyboard.email_model.f_model')
@include('admin.storyboard.email_model.m_model')
@include('admin.storyboard.email_model.pa_model')

@endsection

@section('css')
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
@endsection

@section('js')
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
<script id="api-key" defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB1taAMFjjJDItj7VVzlvsTvVrixJHHNqc&callback=initMap&libraries=places"></script>
@endsection

@section('script')

<script>
    var clientEmail='{{ $storyBoared->user->email }}';

    $(document).ready(function() {
      $('#aboutProperty').summernote();
    });

    function removeFile(e,file_id,name){
      e.preventDefault();
      Swal.fire({
        title: 'Are you sure?',
        text: '',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, keep it'
      }).then((result) => {
        if (result.value) {
          $.ajax({
            url:"{{ route('admin.storyboard.delete-file') }}",
            method:"GET",
            data:{
                file_id:file_id,
                file_name:name
            },
            success:function(response){
                if (response.message) {
                    toastr.success(response.message);
                    setTimeout(function(){
                        location.reload();
                    }, 2000);
                }else{
                    toastr.error("Something is Problem");
                }
            },
            error:function(error){
                console.log(error);
            }
          });
        }
      });
    }


    function deleteStoryBoardFile(e,story_board_id,field_name){
        e.preventDefault();
        Swal.fire({
          title: 'Are you sure?',
          text: '',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Yes, delete it!',
          cancelButtonText: 'No, keep it'
        }).then((result) => {
          if (result.value) {
            $.ajax({
              url:"{{ route('admin.storyboard.own-delete-file') }}",
              method:"GET",
              data:{
                  story_board_id:story_board_id,
                  field_name:field_name
              },
              success:function(response){
                    console.log(response);
                  if (response.message) {
                      toastr.success(response.message);
                      setTimeout(function(){
                          location.reload();
                      }, 2000);
                  }else{
                      toastr.error("Something is Problem");
                  }
              },
              error:function(error){
                  console.log(error);
              }
            });
          }
        });
    }


    // Google autocomplete
    window.onload = function() {
       initAutocomplete();
    }

    var autocomplete;
    function initAutocomplete(){
        autocomplete = new google.maps.places.Autocomplete(
        document.getElementById('autocomplete-input'), {types: ['geocode']});
        autocomplete.addListener('place_changed', getAddressDetails);
    }
    function getAddressDetails(){
        var place = autocomplete.getPlace();
        window.lat = place.geometry.location.lat();
        window.long = place.geometry.location.lng();
        console.log( +'-'+window.long);
        $('#locationLat').val(window.lat);
        $('#locationLng').val(window.long);
    }

    function geolocate(){
      if (navigator.geolocation){
        navigator.geolocation.getCurrentPosition(function(position){
          var geolocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
            var circle = new google.maps.Circle(
            {center: geolocation, radius: position.coords.accuracy});
            autocomplete.setBounds(circle.getBounds());
        });
      }
    }

    // Select client
    function selectClient(client_id)
    {

        clientEmail=$('#selectUser option:selected').attr('data-email');
        // $('#themeColor').html('');
        // if (client_id) {
        //     $.ajax({
        //         url:"{{ route('admin.theme.color') }}",
        //         method:'GET',
        //         data:{'client_id':client_id},
        //         success:function(response){
        //             console.log(response.theme_color)
        //             // let theme=[];
        //             // theme.push({id:'', text: 'Select Theme'});
        //             for (var i = 0; i < response.theme_color.length; i++) {
        //                 $('#themeColor').append(`<li class="mt-2"><input type="radio" name="theme_color" value="${response.theme_color[i].color}">&nbsp;&nbsp;&nbsp;<input type="color" value="${response.theme_color[i].color}" disabled ></li>`);
        //                 // theme.push({id:response.theme_color[i].id, text: response.theme_color[i].color});
        //             }
        //             // $(".select-theme").html('').select2({data: theme});
        //         },
        //         error:function(error){
        //             console.log(error);
        //         }
        //     });
        // }else{
        //     console.log('not found');
        // }
    }


    // Add Panorama Photo Funcaiton
    let i=1;
    function addMorePanorama()
    {
        // console.log('abcd')
        $('#panoramaPhoto').append(`
                    <div class="ic-panorama-photo row pRow${i}">
                        <div class="col-md-4">
                            <div class="form-group">
                                <select name="p_room_name[]" id="" class="form-control select2-tag" style="width:100%;">
                                    <option selected >Select Room Type</option>
                                    @foreach($room_names as $key=>$room_name)
                                        <option value="{{ $room_name }}">{{ $room_name }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <input type="file" class="form-control" name="panorama[]">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <button type="button" onclick="reomvePanoramaPhoto(${i})" class="btn btn-danger btn-sm mt-2">Remove</button>
                            </div>
                        </div>
                    </div>`);
        i++;
        select2tags();
    }

    function select2tags()
    {
        $('.select2-tag').select2({
            tags: true,
            dropdownCssClass : 'bigdrop'
        });
    }

    function reomvePanoramaPhoto(i)
    {
        // console.log(i);
        $(`.pRow${i}`).remove();
    }

    function sendPEmail()
    {
        if (clientEmail.length>0) {
            $('#p-send-email').html('Loading...');

            var form = new FormData();
            form.append("file", $(".p_file")[0].files[0]);
            form.append("file_mls", $(".mls_file")[0].files[0]);
            form.append("storyboard_id", '{{ $storyBoared->id }}');
            $.ajax({
                url:"{{ route('admin.storyboard.send.photo') }}",
                enctype: 'multipart/form-data',
                method:'POST',
                data:form,
                processData: false,
                contentType: false,
                cache: false,
                success:function(response){
                    console.log(response)
                    toastr.success("Email Send Successfully");
                    $('#p-send-email').html('Sent');
                },
                error:function(error){
                   console.log(error);
                   $('#p-send-email').html('Send');
                }
            })
        }else{
            toastr.error("Please Select A Client");
            $('#p-send-email').html('Send');
        }

    }

    function sendVideoEmail()
    {
        if (clientEmail.length>0) {
            $('#v-send-email').html('Loading...');
            var form = new FormData();
            form.append("video_link", $("input[name=p_video_link]").val());
            form.append("download_link", $("input[name=p_download_link]").val());
            form.append("embed_code", $(".v-embed-code").val());
            form.append("storyboard_id", '{{ $storyBoared->id }}');
            $.ajax({
                url:"{{ route('admin.storyboard.send.video') }}",
                method:'POST',
                data:form,
                processData: false,
                contentType: false,
                cache: false,
                success:function(response){
                    toastr.success("Email Send Successfully");
                    $('#v-send-email').html('Sent');
                },
                error:function(error){
                   console.log(error);
                   $('#v-send-email').html('Send');
                }
            })
        }else{
            toastr.error("Please Select A Client");
            $('#v-send-email').html('Send');
        }
    }

    function sendFloorEmail()
    {
        if (clientEmail.length>0) {
            $('#f-send-email').html('Loading...');
            var form = new FormData();
            form.append("image_one", $(".image_one")[0].files[0]);
            form.append("image_two", $(".image_two")[0].files[0]);
            form.append("pdf_file", $(".pdf_file")[0].files[0]);
            form.append("storyboard_id", '{{ $storyBoared->id }}');

            $.ajax({
                url:"{{ route('admin.storyboard.send.floor') }}",
                method:'POST',
                data:form,
                processData: false,
                contentType: false,
                cache: false,
                success:function(response){
                    toastr.success("Email Send Successfully");
                    $('#f-send-email').html('Sent');
                },
                error:function(error){
                   console.log(error);
                   $('#f-send-email').html('Send');
                }
            })
        }else{
            toastr.error("Please Select A Client");
            $('#f-send-email').html('Send');
        }
    }

    function sendMetterEmail()
    {
        if (clientEmail.length>0) {

            $('#m-send-email').html('Loading...');
            var form = new FormData();
            form.append("p_metterport", $(".p-metterport").val());
            form.append("storyboard_id", '{{ $storyBoared->id }}');
            $.ajax({
                url:"{{ route('admin.storyboard.send.metter') }}",
                method:'POST',
                data:form,
                processData: false,
                contentType: false,
                cache: false,
                success:function(response){
                    toastr.success("Email Send Successfully");
                    $('#m-send-email').html('Sent');
                },
                error:function(error){
                   console.log(error);
                   $('#m-send-email').html('Send');
                }
            })

        }else{
            toastr.error("Please Select A Client");
        }
    }

    function sendPanoramaEmail()
    {
       if (clientEmail.length>0) {
           $('#pa_email_send').html('Loading...');
           var form = new FormData();
           form.append("storyboard_id", '{{ $storyBoared->id }}');

           $.ajax({
               url:"{{ route('admin.storyboard.send.panaroma') }}",
               method:'POST',
               data:form,
               processData: false,
               contentType: false,
               cache: false,
               success:function(response){
                   toastr.success("Email Send Successfully");
                   $('#pa_email_send').html('Sent');
               },
               error:function(error){
                  console.log(error);
                  $('#pa_email_send').html('Send');
               }
           })
       }else{
           toastr.error("Please Select A Client");
       }
    }

    // Get Embed Cide
    function getEmbedCode(url){
        $.ajax({
            url:"{{ route('admin.storyboard.get-embed-code') }}",
            method:"POST",
            data:{url:url,'story_board_id':{{ $storyBoared->id }} },
            success:function(response){
                $('.v-embed-code').val(response.embed);
            },
            error:function(error){
                console.log(error);
            }
        });
    }
</script>


@endsection
