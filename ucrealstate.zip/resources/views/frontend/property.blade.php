@extends('frontend.layouts.master')




@section('content')

<!-- preloader Area Start -->
{{-- <div class="ic-preloader">
    <div class="loading-wrapper">
        <div class="nb-spinner"></div>
    </div>
</div> --}}
<!-- preloader Area end -->


    <!-- navbar start -->
    <nav class="navbar navbar-expand-lg ic-navbar-start d-lg-block">
        <div class="container">
            <a class="ic-main-logo" href="{{ route('agent.profile',[$user->user_name]) }}">
                @if ($user->logo)
                    <img src="{{ Storage::url($user->logo) }}" alt="logo">
                @else
                    <h4 style="color:#000">{{ $storyBoard->user->full_name }}</h4>
                @endif
            </a>


            <div class="ic-collapsenavbar-nav collapse-navber-collapse nav-wrap" id="navbarSupportedContent">
                <nav id="onepage-nav">
                    <ul class="navbar-nav mr-auto" id='ic-navbar'>

                        <li class="nav-item"><a class="page-scroll scroll active" href="#home">Home</a></li>
                        @if ($storyBoard->show_about==1)
                            <li class="nav-item"><a class="page-scroll scroll" href="#about">About Property</a></li>
                        @endif
                        <li class="nav-item"><a class="page-scroll scroll" href="#video-tour">Home Tour</a></li>
                        @if ($storyBoard->p_floor_plan)
                        <li class="nav-item"><a class="page-scroll scroll" href="#floor-plan">Floor Plan</a></li>
                        @endif
                        <li class="nav-item"><a class="page-scroll scroll" href="#location">Location</a></li>
                        <li class="nav-item"><a class="page-scroll scroll" href="#contact">Contact</a></li>

                    </ul>
                </nav>
            </div>

            <div class="ic-mobile-menu-open bg-color-secondary bg-color-secondary-hover"><i class="flaticon-menu"></i></div>
        </div>
    </nav>
    <!-- navbar end -->

    <!-- mobile-nav start -->
    <div class="ic-mobile-menu-overlay">
    </div>

    <div class="offcanvas_menu d-block d-lg-none ic_mobile_nav_head">
        <div class="container">
            <div class="ic-mobile-menu-wrapper">
                <div class="ic-menu-close">
                    <a href="javascript:void(0)"><i class="flaticon-close"></i></a>
                </div>
                <div id="menu" class="text-left ">
                    <ul class="offcanvas_main_menu">
                        <li class="nav-item active"><a class="page-scroll" href="{{ route('show.property',['user_name'=>$user->user_name,'story_board'=>$storyBoard->slug]) }}">Home</a></li>
                        @if ($storyBoard->show_about==1)
                        <li class="nav-item"><a class="page-scroll" href="#about">About Property</a></li>
                        @endif
                        <li class="nav-item"><a class="page-scroll" href="#video-tour">Home TOUR</a></li>
                        @if ($storyBoard->p_floor_plan)
                        <li class="nav-item"><a class="page-scroll" href="#floor-plan">Floor Plan</a></li>
                        @endif
                        <li class="nav-item"><a class="page-scroll" href="#location">Location</a></li>
                        <li class="nav-item"><a class="page-scroll" href="#contact">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- mobile-nav end -->


<!-- slider part start -->
<section class="ic-top-slider-wrap" id="home">

  <div class="ic-top-slider-inner">

    <div class="ic-slider-list-inner">
        <div class="ic-slider-list-content" style="background-color: rgba(101, 149, 191, 0.5);"> <!-- change for theme color -->
            <!-- <div class="ic-slider-text">
                {{-- <div class="ic-short-title">James ho</div> --}}
                <p class="secondary">{{ $storyBoard->property_address_line }}</p>
                <a href="{{ route('contact.user',[$user->user_name]) }}" class="ic-default-btn">contact us</a>
            </div> -->
        </div>
    </div>



    <div class="ic-slider-box">
    @if (count($flickr_photos)>0)
         @php
            $i=1;
        @endphp
        @foreach ($flickr_photos as $key=>$flickr_photo)
            @if($i%3==1)
                <div class="ic-slider-list" style="background-image: url({{ $flickr_photo}})"></div>
            @endif
            @php
                $i++;
            @endphp
        @endforeach
      @else
        <div class="ic-slider-list" style="background-image: url({{ Storage::url(Settings::get('default_bg')) }})"></div>
      @endif

    </div>
  </div>
  <h1 class="ic-main-slider-text bg-color-secondary">{{ $storyBoard->property_address }}</h1>
</section>
<!-- slider part end -->

@if($storyBoard->show_about==1)
<!-- about property start -->
<section class="ic-common-height ic-pt-80 ic-pb-80 ic-about-wrap" id="about">
  <div class="ic-about-inner">
    <div class="container">
        <div class="ic-about-row">
            <div class="ic-about-title-col"><h2 class="about-title main-color">About <strong>Property</strong></h2></div>

            <div class="ic-about-image-col">
                <div class="about-image-wrap">
                    <div class="about-image-inner" style="background-image: url({{ Storage::url($storyBoard->property_image) }})"></div>
                </div>
            </div>

            <div class="ic-about-text-col">
                <div class="ic-about-text">
                    <h2 class="about-price main-color">${{ number_format($storyBoard->property_price) }}</h2>
                    {!! $storyBoard->about_property !!}
                </div>

            </div>
        </div>

        <div class="ic-about-property-wrap" data-aos="fade-up" data-aos-anchor-placement="top-bottom">
            <div class="row">
                <div class="col-md-3 col-sm-6 col-6">
                    <div class="ic-about-property-box">
                        <i class="flaticon-architecture"></i>
                        <h3 class="main-color">{{ $storyBoard->year }}</h3>
                        <p>Year Built</p>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-6" data-aos="fade-up" data-aos-duration="200" data-aos-anchor-placement="top-bottom">
                    <div class="ic-about-property-box">
                        <i class="flaticon-square-ruler"></i>
                        <h3 class="main-color">{{ number_format($storyBoard->square_feets) }}</h3>
                        <p>Square Feet</p>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-6">
                    <div class="ic-about-property-box">
                        <i class="flaticon-double-bed"></i>
                        <h3 class="main-color">{{ $storyBoard->bedroom }}</h3>
                        <p>Bedroom{{ $storyBoard->bedroom >1?'s':'' }}</p>
                    </div>
                </div>

                <div class="col-md-3 col-sm-6 col-6" data-aos="fade-up" data-aos-duration="200" data-aos-anchor-placement="top-bottom">
                    <div class="ic-about-property-box">
                        <i class="flaticon-bathroom"></i>
                        <h3 class="main-color">{{ $storyBoard->bathroom }}</h3>
                        <p>Bathroom{{ $storyBoard->bathroom >1?'s':'' }}</p>
                    </div>
                </div>

            </div>
        </div>
    </div>
  </div>
</section>
<!-- about property end -->
@endif



<!-- home tour start -->
@if (($storyBoard->p_video_link) || ($flickr_photos) || ($storyBoard->panoramas) || ($storyBoard->p_metterport))


<section class="ic-common-height ic-pt-80 ic-pb-80 ic-home-tour-wrap" id="video-tour">
    <div class="container">
    <div class="ic-home-tour-inner">
        <div class="ic-header">
            <h2><strong class="main-color">home </strong> tour</h2>
        </div>

        <div class="ic-home-tour-body">

            <ul class="ic-tour-tab-list nav nav-pills mb-3" id="pills-tab" role="tablist">

                @if ($storyBoard->p_video_link)
                    <li class="nav-item"><a class="nav-link active" id="tour-tab" data-toggle="pill" href="#tour" role="tab" aria-controls="tour" aria-selected="true">VIDEO TOUR<i class="flaticon-video-camera"></i></a></li>
                @endif

                @if(count($flickr_photos)>0)
                        <li class="nav-item"><a class="nav-link StopVideo {{ $storyBoard->p_video_link==null?'active':'' }}" id="photo-gallery-tab" data-toggle="pill" href="#photo-gallery" role="tab" aria-controls="photo-gallery" aria-selected="false">GALLERY<i class="flaticon-gallery"></i></a></li>
                @endif

                @if (count($storyBoard->panoramas)>0)
                    <li class="nav-item" onclick="showPanorma()"><a class="nav-link StopVideo {{ (count($flickr_photos)==0) && ($storyBoard->p_video_link==null)?'active':'' }}" id="pills-contact-tab" data-toggle="pill" href="#panorama-tour" role="tab" aria-controls="panorama-tour" aria-selected="false">VIRTUAL TOUR <i class="flaticon-degree"></i></a></li>
                @endif

                @if($storyBoard->p_metterport)
                    <li class="nav-item ic-3d-tour-image">
                        <a class="nav-link StopVideo" id="virtual-tour-tab" data-toggle="pill" href="#virtual-tour" role="tab" aria-controls="virtual-tour" aria-selected="false">
                            3D TOUR
                            <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="146.000000pt" height="165.000000pt" viewBox="0 0 146.000000 165.000000" preserveAspectRatio="xMidYMid meet"><g transform="translate(0.000000,165.000000) scale(0.100000,-0.100000)" fill="#000000" stroke="none"><path d="M382 1422 l-342 -197 0 -400 0 -400 337 -194 c185 -107 342 -194 348 -194 7 0 163 87 348 194 l337 194 0 400 0 400 -277 160 c-152 88 -307 177 -343 197 l-66 37 -342 -197z m656 -46 c161 -93 291 -170 290 -171 -11 -9 -598 -345 -603 -345 -5 0 -590 335 -603 345 -7 6 595 345 608 343 9 -2 147 -79 308 -172z m-621 -405 l283 -163 0 -350 0 -349 -57 32 c-32 18 -168 97 -303 175 l-245 142 -3 352 -2 352 22 -14 c13 -8 150 -88 305 -177z m936 -512 c-7 -6 -361 -213 -545 -318 l-58 -32 0 349 0 350 303 174 302 175 3 -345 c1 -190 -1 -349 -5 -353z"/><path d="M700 1480 c0 -25 4 -30 25 -30 21 0 25 5 25 30 0 25 -4 30 -25 30 -21 0 -25 -5 -25 -30z"/><path d="M700 1370 c0 -25 4 -30 25 -30 21 0 25 5 25 30 0 25 -4 30 -25 30 -21 0 -25 -5 -25 -30z"/><path d="M700 1260 c0 -25 4 -30 25 -30 21 0 25 5 25 30 0 25 -4 30 -25 30 -21 0 -25 -5 -25 -30z"/><path d="M700 1150 c0 -25 4 -30 25 -30 21 0 25 5 25 30 0 25 -4 30 -25 30 -21 0 -25 -5 -25 -30z"/><path d="M700 1045 c0 -20 5 -25 25 -25 20 0 25 5 25 25 0 20 -5 25 -25 25 -20 0 -25 -5 -25 -25z"/><path d="M700 935 c0 -20 5 -25 25 -25 20 0 25 5 25 25 0 20 -5 25 -25 25 -20 0 -25 -5 -25 -25z"/><path d="M611 791 c-8 -5 -11 -16 -6 -30 7 -23 17 -26 46 -11 16 9 17 14 6 30 -13 22 -25 24 -46 11z"/><path d="M516 737 c-16 -12 -17 -16 -5 -35 16 -26 18 -26 42 -8 15 12 16 18 7 35 -13 25 -20 26 -44 8z"/><path d="M425 684 c-15 -11 -17 -18 -9 -31 14 -23 27 -26 48 -10 17 12 17 14 -1 35 -16 19 -20 20 -38 6z"/><path d="M328 629 c-14 -8 -15 -14 -6 -34 13 -29 16 -29 41 -11 15 12 16 18 7 35 -12 23 -17 25 -42 10z"/><path d="M237 576 c-15 -12 -16 -18 -7 -35 12 -24 15 -25 40 -11 17 9 18 14 8 35 -13 29 -16 29 -41 11z"/><path d="M136 517 c-17 -12 -17 -14 1 -35 16 -19 20 -20 38 -6 15 11 17 18 9 31 -14 23 -27 26 -48 10z"/><path d="M793 780 c-11 -16 -10 -21 6 -30 29 -15 39 -12 46 11 12 37 -32 53 -52 19z"/><path d="M890 729 c-9 -17 -8 -23 7 -35 24 -18 26 -18 42 8 12 19 11 23 -5 35 -24 18 -31 17 -44 -8z"/><path d="M992 687 c-21 -28 -22 -36 -2 -47 39 -21 68 24 31 47 -15 9 -21 9 -29 0z"/><path d="M1080 619 c-9 -17 -8 -23 7 -35 25 -18 28 -18 41 11 10 21 9 26 -8 35 -25 14 -28 13 -40 -11z"/><path d="M1172 565 c-10 -21 -9 -26 8 -35 25 -14 28 -13 40 11 9 17 8 23 -7 35 -25 18 -28 18 -41 -11z"/><path d="M1272 518 c-17 -17 -15 -31 8 -45 16 -11 21 -9 35 10 14 20 14 23 -2 34 -21 16 -26 16 -41 1z"/></g></svg>
                        </a>
                    </li>

                @endif

            </ul>
            <div class="tab-content ic-tab-content" id="pills-tabContent">
                @if ($storyBoard->p_video_link)
                    <div class="tab-pane ic-tab-pane ic-tour-tab fade show active fade" id="tour" role="tabpanel" aria-labelledby="tour-tab">
                        <div class="ic-video-tour-wrap">
                            <div class="ic-video-tour-inner">
                                <div class="ic-video-tour-video">
                                    {{-- <button class="ic-video-player"><i class="flaticon-pause-button"></i></button> --}}
                                    {{-- {!! $storyBoard->p_video_link !!} --}}
                                {{-- <iframe id="ic-video-tour-iframe" src="{{ $storyBoard->p_video_link }}" style="overflow:hidden;height:100%;width:100%" width="100%" height="100%" frameborder="0" allow="picture-in-picture" allowfullscreen></iframe> --}}
                                    <div id="vimeoWrap">
                                        {!! $storyBoard->p_video_iframe !!}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

                @if (count($flickr_photos)>0)
                <div class="tab-pane ic-tab-pane ic-photo-gallery-tab {{ $storyBoard->p_video_link==null?'show active':'' }} fade" id="photo-gallery" role="tabpanel" aria-labelledby="photo-gallery-tab">
                    <!-- image gallery start -->
                    <div class="container">
                        <div class="ic-image-gallery-body">
                            <div class="row">
                                @foreach ($flickr_photos as $key=>$flickr_photo)
                                <div class="col-lg-3 col-sm-6 col-6 {{ $key>11?'ic-hide-div':'' }}">

                                    <a href="{{ $flickr_photo }}" class="ic-team-img-gallery-wrap" data-lightbox="roadtrip">
                                        <img src="{{ $flickr_photo }}" class="img-fluid w-100 ic-team-img-gallery" alt="">
                                    </a>
                                </div>
                                @endforeach

                            </div>

                            @if (count($flickr_photos)>16)
                            <div class="ic-view-all ic-image-gallery-more">
                                <div class="ic-buttons-text">
                                    <p class="loading" style="display: none;">Loading....</p>
                                    <a href="javascript:void(0)" class="ic-secondary-btn view-more-bth ic-view-more-btn bg-color-secondary bg-color-secondary-hover" tabindex="0">view more</a>
                                </div>
                            </div>
                            @endif

                        </div>
                    </div>
                    <!-- image gallery end -->
                </div>
                @endif
                @if ($storyBoard->panoramas)
                <div class="tab-pane ic-tab-pane ic-panorama-tour-tab fade {{ (count($flickr_photos)==0) && ($storyBoard->p_video_link==null)?'show active':'' }}" id="panorama-tour" role="tabpanel" aria-labelledby="panorama-tour-tab">

                <ul>
                    @foreach ($storyBoard->panoramas as $key=>$panorma)
                        <li><a href="javascript:void(0)" class="panormaButton{{ $key }}" onclick="selectimage({{ $panorma->id }})">{{ $panorma->p_room_name }}</a></li>
                    @endforeach
                </ul>


                @foreach ($storyBoard->panoramas as $key=>$panorma)
                    <div class="d-none" id="niceslider{{ $panorma->id }}" style="width: 100vw; height: 100vh;"></div>
                @endforeach
                </div>

                @endif

                 @if ($storyBoard->p_metterport)
                <div class="tab-pane ic-tab-pane ic-3d-tour-tab fade" id="virtual-tour" role="tabpanel" aria-labelledby="virtual-tour-tab">
                    <!-- image panorama start -->
                    <div class="container">
                        <div class="ic-3d-tour-box">
                            <div class="ic-3d-tour-inner">
                                @if (strlen($storyBoard->p_metterport)>60)
                                    {!! $storyBoard->p_metterport !!}
                                @else
                                    <iframe width='853' height='480' src="{{ $storyBoard->p_metterport }}" frameborder='0' allowfullscreen allow='xr-spatial-tracking'></iframe>
                                @endif
                            </div>
                        </div>

                    </div>
                    <!-- image panorama end -->
                </div>
                @endif
            </div>

        </div>

    </div>
    </div>
</section>
<!-- home tour end -->
@endif


@if ($storyBoard->p_floor_plan)
<!-- Floor plan part start -->
<section class="ic-common-height ic-pt-80 ic-pb-80 ic-floor-wrap" id="floor-plan">
    <div class="container">
    <div class="ic-floor-inner">
        <div class="ic-header">
            <h2><strong class="main-color">Floor</strong> plan</h2>
        </div>

        <div class="ic-floor-body">


            @if (strpos($storyBoard->p_floor_plan, 'pdf') !== false)

                    <embed src="{{ Storage::url('story_file') }}/{{ $storyBoard->p_floor_plan }}"  frameborder="0">

            @else
            <!-- Zomm area -->
            <div class="ic-maps-zoom-wrap" style="overflow: auto;">
                <img src="{{ Storage::url('story_file') }}/{{ $storyBoard->p_floor_plan }}" alt="World map"/>
            </div>
            <!-- <div class="ic-maps-zoom-wrap maps-container unselectable" style="overflow: auto;">
                <img src="{{ Storage::url('story_file') }}/{{ $storyBoard->p_floor_plan }}" alt="World map"/>
                <div class="map-full-view"><i class="flaticon-full-size main-color"></i> </div>
                <div class="map-control map-control-zoomin"><i class="flaticon-plus main-color"></i></div>
                <div class="map-control map-control-zoomout"><i class="flaticon-remove main-color"></i></div>



                <div class="maps-container-inner zoomedElement zoomedElement414" style="transform: scale(4.54782); left: -379.615px; top: 334.1px;">

                    <div class="ic-map-container-wrap maps-zoomed-container">
                        <div class="map-image" id="map-all" style="display:block;">
                            <img src="{{ Storage::url('story_file') }}/{{ $storyBoard->p_floor_plan }}" alt="World map"/>

                        </div>
                    </div>
                </div> -->
            </div>
            @endif
        </div>

    </div>
    </div>

</section>
<!-- Floor plan part end -->
@endif

{{-- @if ($storyBoard->p_floor_plan)
<div class="floor-plan-full-view">
<a href="javascript:void(0)" class="map-full-view-close"><i class="flaticon-close"></i></a>
    <div class="container">
        <div class="floor-plan-full-view-inner">
            <div class="maps-container unselectable" style="overflow: auto;">

                <div class="map-control map-control-zoomin"><i class="flaticon-plus main-color"></i></div>
                <div class="map-control map-control-zoomout"><i class="flaticon-remove main-color"></i></div>

                <!-- container-inner -->
                <div class="maps-container-inner zoomedElement zoomedElement414" style="transform: scale(4.54782); left: -379.615px; top: 334.1px;">
                    <!-- zoomed-container -->
                    <div class="maps-zoomed-container">

                        <div class="map-image" id="map-all" style="display:block;">
                            <img src="{{ Storage::url('story_file') }}/{{ $storyBoard->p_floor_plan }}" alt="World map"/>
                        </div>


                        <div class="testpoint"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endif --}}

@if (($storyBoard->location))
<!-- Location start -->
<section class="ic-pt-80 ic-pb-80 ic-location-wrap" id="location">
    <div class="container">
    <div class="ic-location-inner">
        <div class="ic-header">
            <h2><strong class="main-color">Location</strong></h2>
        </div>

        <div class="ic-location-body">
            <div class="ic-location-map">
                <div id="map_canvas" style="width:100%; height:850px"></div>
                {{-- <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7296.9489909298245!2d90.416468372094!3d23.87278743811659!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c5c5849459a3%3A0x627da4ef9bc6539a!2sUttar%20Khan%2C%20Dhaka%201230!5e0!3m2!1sen!2sbd!4v1617796845516!5m2!1sen!2sbd"
                    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe> --}}
            </div>
            {{-- <div class="row">
                <div class="col-md-4 col-sm-6 col-6">
                    <div class="ic-walk-wrap location-text-wrap">
                        <div class="ic-icon"><i class="flaticon-walking"></i></div>
                        <div class="ic-text"><span id="walkableTag"></span>/Hr</div>
                        <h2>very walkable</h2>
                        <p>Walk Score</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-6">
                    <div class="ic-transit-wrap location-text-wrap">
                        <div class="ic-icon"><i class="flaticon-public-transport"></i></div>
                        <div class="ic-text"><span id="transitTag"></span>/Hr</div>
                        <h2>good transit</h2>
                        <p>Transit Score</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-6">
                    <div class="ic-bike-wrap location-text-wrap">
                        <div class="ic-icon"><i class="flaticon-bicycle"></i></div>
                        <div class="ic-text"><span id="bikeableTag"></span>/Hr</div>
                        <h2>very bikeable</h2>
                        <p>Bike Score</p>
                    </div>
                </div>
            </div> --}}
        </div>
    </div>
    </div>

</section>
<!-- Location end -->
@endif

<!-- contact part start -->
<section class="ic-pt-80 ic-pb-80 ic-contact-wrap" id="contact">
    <div class="container">
        <div class="ic-contact-inner">
            <div class="ic-header">
                <h2>contact <strong class="main-color">{{ $user->display_name }}</strong></h2>
            </div>

            <div class="ic-contact-body">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="ic-contact-text-wrap">
                            @if($user->photo)
                                <div class="ic-contact-image" style="background-image: url({{ Storage::url($user->photo) }})"></div>
                            @else
                                <div class="ic-contact-image" style="background-image: url({{ Storage::url(Settings::get('default_profile')) }})"></div>
                            @endif

                            <div class="ic-address ic-user-contact-address">
                                <!-- <h2><strong>{{ $user->display_name }} </strong></h2>
                                        <p>{{ $user->title }}</p> -->
                                <p>
                                    <strong>{{ $user->display_name }}</strong>
                                @if ($user->title)
                                    <b class="surname">{{ $user->title }}</b>
                                @endif

                                @if ($user->phone)
                                    <span class="main-color">Phone:</span>{{ $user->phone }}<br />
                                @endif

                                @if ($user->email)
                                    <span class="main-color">Email:</span>{{ $user->email }}<br />
                                @endif

                                <input type="hidden" class="ic-sign-up-name" name="address" value="{{ $storyBoard->address }}" placeholder="Listing Address"><!-- change for theme color -->


                                @if ($user->website)
                                <span class="main-color">WEB:</span> <a href="{{ $user->website }}" target="_blank">{{ $user->website }}</a>
                                @endif
                                </p>
                            </div>

                            <ul class="ic-social-icon">
                                @if ($user->facebook)
                                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->facebook }}" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                @endif
                                @if ($user->twitter)
                                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->twitter }}" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                @endif
                                @if ($user->linkdin)
                                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->linkdin }}" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                @endif
                                @if ($user->instragram)
                                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->instragram }}" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                @endif
                                @if ($user->youtube)
                                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->youtube }}" target="_blank"><i class="fab fa-youtube"></i></a></li>
                                @endif
                            </ul>


                        </div>
                    </div>

                    <div class="col-lg-7">
                        <div class="ic-contacts-form">
                            <form action="{{ route('send_message') }}" method="POST">
                                @csrf

                                <input type="hidden"  value="{{ $user->email }}" name="to_email">

                                <div class="row ic-form-group">
                                    <div class="col-lg-12">
                                        <input class="ic-sign-up-name" type="name" name="name" placeholder="Name">
                                        @error('name')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                        <input type="email" name="from_email" placeholder="Email Address">
                                        @error('from_email')
                                            <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>

                                    <div class="col-lg-6 col-md-6">
                                        <input class="ic-sign-up-name" type="text" name="phone_number"
                                            placeholder="Enter Phone Number">
                                    </div>

                                    <div class="col-lg-12">
                                        <input type="hidden" value="{{ $storyBoard->property_address }}" class="ic-sign-up-name" name="address" placeholder="Listing Address"><!-- change for theme color -->
                                    </div>

                                    <div class="col-lg-12">
                                        <textarea rows="5" type="text" name="message" placeholder="Message Here"></textarea>
                                    </div>
                                </div>
                                <button type="submit" class="ic-default-btn bg-color-secondary bg-color-secondary-hover">Send Message Now</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
</section>

    <!-- contact part end -->
@if (count($AllStoryBoards)>0)
    <!-- image gallery start -->
    <section class="ic-pt-40 ic-pb-80 ic-image-gallery-wrap ic-home-image-gallery-wrap">
        <div class="container">
            <div class="ic-image-gallery-inner">
                <div class="ic-image-gallery-header">
                    <h2>Featured Listings</h2>
                </div>

                <div class="ic-image-gallery-body">
                    <div class="row">
                        @foreach ($AllStoryBoards as $key=>$AllStoryBoard)
                                    <div class="col-lg-3 col-sm-6 col-6">
                                        {{-- <a href="#" class="ic-edit-this"><i class="flaticon-edit-button"></i></a> --}}
                                        <a href="{{ route('show.property',['user_name'=>$user->user_name,'story_board'=>$AllStoryBoard->slug]) }}" class="ic-team-box-card">
                                            <div class="ic-team-card">
                                                <div class="ic-team-img">

                                                    <div class="ic-team-img-inner" style="background-image: url({{ $AllStoryBoard->flickr_first_photo?? Storage::url(Settings::get('default_bg')) }})">
                                                    </div>
                                                </div>
                                                <div class="ic-team-info">
                                                    <h6>{{ $AllStoryBoard->property_address }}</h6>
                                                    <p>{{ $AllStoryBoard->property_address_line }}</p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                        @endforeach
                    </div>

                <a href="{{ route('agent.profile',[$user->user_name]) }}" class="ic-secondary-btn ic-view-all bg-color-secondary bg-color-secondary-hover" tabindex="0">view all</a>
                </div>

            </div>
        </div>
    </section>
@endif




@endsection

@section('js')
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyB1taAMFjjJDItj7VVzlvsTvVrixJHHNqc&callback=initMap&libraries=places"></script>
@endsection

@section('script')

    <script>
        // panorma
        $(function(){
            setTimeout(() => {
                $(`.panormaButton0`).click();
            }, 2000);
        });

        @if (($storyBoard->p_video_link==null) && (count($storyBoard->panoramas)==0) && (count($flickr_photos)==0) && (count($storyBoard->panoramas)==0))
        $('#virtual-tour-tab').click();
        @endif

        let data=[
            @if($storyBoard->panoramas)
                @foreach ($storyBoard->panoramas as $panorma)
                    {id:'{{ $panorma->id }}',image:'{{ asset(Storage::url($panorma->panorama_photo)) }}' },
                @endforeach
            @endif
        ];

        @if($storyBoard->panoramas)
            @foreach ($storyBoard->panoramas as $panorma)
                $(`#niceslider{{ $panorma->id }}`).css({'width':'100% !important'});
            @endforeach
        @endif




        function showPanorma(id){
            setTimeout(() => {
                $(`.panormaButton0`).click();
            }, 500);
        }



        function selectimage(id){




            for (let index = 0; index < data.length; index++) {

                $(`#niceslider${data[index].id}`).addClass('d-none');

                if(id.toString()==data[index].id.toString()){
                    console.log('equal id',id);
                    $(`#niceslider${data[index].id}`).removeClass('d-none');
                }else{
                    console.log('not id',id);
                    $(`#niceslider${data[index].id}`).addClass('d-none');
                }
            }

            data.map(data=>{
                if(id.toString()==data.id){

                    $(`#niceslider${id}`).html(' ');
                    let viewer=new PhotoSphereViewer.Viewer({
                        panorama: data.image,
                        container: `niceslider${id}`,
                        loadingImg: 'https://photo-sphere-viewer.js.org/assets/photosphere-logo.gif',
                        // mousemove: false,
                        defaultZoomLvl:0,
                        defaultLat: 0.3,
                        autorotateDelay: 1000,
                        autorotateSpeed: '1rpm',
                        touchmoveTwoFingers: true,
                        mousewheelCtrlKey: true,
                        navbar:['fullscreen']
                    });
                }
            });

        }



    </script>

    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

       var map;
       var geocoder;
       var from_location = {lat:'', lng:''};
       var to_location = {lat:{{ $storyBoard->latitude }}, lng:{{ $storyBoard->longitude }}};
       var marker;
       function loadMap() {
           // Using the lat and lng of Dehradun.
           var latitude = {{ $storyBoard->latitude }};
           var longitude = {{ $storyBoard->longitude }};
           var latlng = new google.maps.LatLng(latitude,longitude);
           var feature = {
               zoom: 12,
               center: latlng,
               mapTypeId: google.maps.MapTypeId.ROADMAP
           };
           map = new google.maps.Map(document.getElementById("map_canvas"), feature);
           geocoder = new google.maps.Geocoder();
           marker = new google.maps.Marker({
               position: latlng,
               map: map,
               title: "Test for Location"
           });
           locate();
       }

       function locate(){
        if ("geolocation" in navigator){
            navigator.geolocation.getCurrentPosition(function(position){
                var currentLatitude = position.coords.latitude;
                var currentLongitude = position.coords.longitude;
                getDistance(currentLatitude,currentLongitude);
            });

        }else{
            console.log("Geolocation is not supported by this browser.")
        }
       }

       function getDistance(location_lat,location_long)
       {

        from_location.lat=location_lat;
        from_location.lng=location_long;

        var latlng_2 = new google.maps.LatLng(location_lat,location_long);
            var marker_2 = new google.maps.Marker({
               position: latlng_2,
               map: map,
               title: "Test for Location"
           });

        var line = new google.maps.Polyline({path: [from_location, to_location], map: map});
        var distance = haversine_distance(marker, marker_2);

        //    console.log(location_lat,location_long);
        // $.ajax({
        //     url:"{{ route('get.distance') }}",
        //     method:'POST',
        //     data:{
        //         location_lat:location_lat,
        //         location_long:location_long,
        //         property_lat:{{ $storyBoard->latitude }},
        //         property_long:{{ $storyBoard->longitude }}
        //     },
        //     success:function(response)
        //     {
        //         // console.log(response);

        //         if (response.walk) {
        //             $('#walkableTag').html(response.walk);
        //         }
        //         if (response.driving) {
        //             $('#transitTag').html(response.driving);
        //         }
        //         if (response.cycle) {
        //             $('#bikeableTag').html(response.cycle);
        //         }
        //     },
        //     error:function(error){
        //         console.log(error);
        //     }
        // })
       }

       function haversine_distance(mk1, mk2) {
            var R = 6371.0710; // Radius of the Earth in kilometers
            var rlat1 = mk1.position.lat() * (Math.PI/180); // Convert degrees to radians
            var rlat2 = mk2.position.lat() * (Math.PI/180); // Convert degrees to radians
            var difflat = rlat2-rlat1; // Radian difference (latitudes)
            var difflon = (mk2.position.lng()-mk1.position.lng()) * (Math.PI/180); // Radian difference (longitudes)

            var d = 2 * R * Math.asin(Math.sqrt(Math.sin(difflat/2)*Math.sin(difflat/2)+Math.cos(rlat1)*Math.cos(rlat2)*Math.sin(difflon/2)*Math.sin(difflon/2)));
            // console.log(d);
        }

        // Driving destence

        // let directionsService = new google.maps.DirectionsService();
        // let directionsRenderer = new google.maps.DirectionsRenderer();
        // directionsRenderer.setMap(map); // Existing map object displays directions
        // // Create route from existing points used for markers

        // const route = {
        //     origin: {lat:23.8680597, lng:90.4148968},
        //     destination: {lat:25.9362732, lng:88.8407037},
        //     travelMode: 'WALKING'
        // }


        // directionsService.route(route,
        //     function(response, status) { // anonymous function to capture directions
        //         console.log(response);
        //     if (status !== 'OK') {
        //         alert('Directions request failed due to ' + status);
        //         return;
        //     } else {
        //         directionsRenderer.setDirections(response); // Add route to the map
        //         var directionsData = response.routes[0].legs[0]; // Get data about the mapped route
        //         if (!directionsData) {
        //         alert('Directions request failed');
        //         return;
        //         }
        //         else {
        //             alert(directionsData.distance.text);
        //         // document.getElementById('msg').innerHTML += " Driving distance is " + directionsData.distance.text + " (" + directionsData.duration.text + ").";
        //         }
        //     }
        //     });


        // ifrem video push
        $('.StopVideo').click(function() {
            vimeoWrap = $('#vimeoWrap');
            vimeoWrap.html(vimeoWrap.html());
        });



    </script>

@endsection
