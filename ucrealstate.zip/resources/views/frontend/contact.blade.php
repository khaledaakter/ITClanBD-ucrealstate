@extends('frontend.layouts.master')


@section('content')

<!-- inner banner start -->
@if($user->background_image)
    <section class="ic-inner-page-banner" style="background-image: url('{{ Storage::url($user->background_image) }}')"></section>
@else
    <section class="ic-inner-page-banner" style="background-image: url({{ Storage::url(Settings::get('default_bg')) }})"></section>
@endif
<!-- inner banner end -->

<!-- user cover section start -->
<section class="ic-user-cover-section">
    <div class="container">
        <div class="ic-user-cover-inner">

            <div class="ic-user-cover-text">
                @if($user->photo)
                    <div class="ic-contact-image" style="background-image: url({{ Storage::url($user->photo) }})"></div>
                @else
                    <div class="ic-contact-image" style="background-image: url({{ Storage::url(Settings::get('default_profile')) }})"></div>
                @endif
                <div class="ic-user-cover-text-content">
                    <h2><strong>{{ $user->display_name }} </strong></h2>
                    <p>{{ $user->title }}</p>
                </div>
            </div>

            <ul class="ic-social-icon">
                @if ($user->facebook)
                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->facebook }}" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                @endif
                @if ($user->twitter)
                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->twitter }}" target="_blank"><i class="fab fa-twitter"></i></a></li>
                @endif
                @if ($user->linkdin)
                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->linkdin }}" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                @endif
                @if ($user->instragram)
                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->instragram }}" target="_blank"><i class="fab fa-instagram"></i></a></li>
                @endif
                @if ($user->youtube)
                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->youtube }}" target="_blank"><i class="fab fa-youtube"></i></a></li>
                @endif
            </ul>
        </div>
    </div>
</section>
<!-- user cover section end -->

<!-- <div class="container">
    <ul class="ic-user-propety-tab">
        <li class="ic-user-properties active"><a href="javascript:void(0)">Single properties</a></li>
        <li class="ic-user-contact"><a href="javascript:void(0)">Contact mike</a></li>
    </ul>
</div> -->


<!-- contact part start -->
<section class="ic-user-contact-wrap ic-contact-wrap">
    <div class="container">
    <div class="ic-contact-inner">

        <div class="ic-contact-body">
            <div class="row">
                <div class="col-lg-5">
                    <div class="ic-contact-text-wrap">

                        <div class="ic-address ic-user-contact-address">
                            <p>
                                <!-- <strong>{{ $user->display_name }}</strong>
                        	@if ($user->title)
                        		<b class="surname">{{ $user->title }}</b>
                        	@endif -->

                            @if ($user->phone)
                                <a href="tel:{{ $user->phone }}" class="main-color">Phone:{{ $user->phone }}</a><br />
                            @endif
                            @if ($user->office->phone)
                            	<span class="main-color">office:</span>{{ $user->office->phone }}<br />
                            @endif

                            @if ($user->email)
                            	<span class="main-color">Email:</span>{{ $user->email }}<br />
                            @endif
                            @if ($user->website)
                                <span class="main-color">Web:</span><a href="{{ $user->website }}" target="_blank">{{ $user->website }}</a>
                            @endif
                            </p>
                        </div>

                    </div>
                </div>

                <div class="col-lg-7">
                    <div class="ic-contacts-form">
                        <form action="{{ route('send_message') }}" method="POST">
                            @csrf

                            <input type="hidden"  value="{{ $user->email }}" name="to_email">

                            <div class="row ic-form-group">
                                <div class="col-lg-12">
                                    <input class="ic-sign-up-name" type="name" name="name" placeholder="Name">
                                    @error('name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <input type="email" name="from_email" placeholder="Email Address">
                                    @error('from_email')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>

                                <div class="col-lg-6 col-md-6">
                                    <input class="ic-sign-up-name" type="text" name="phone_number"
                                        placeholder="Enter Phone Number">
                                </div>

                                <div class="col-lg-12">
                                    <input type="hidden" class="ic-sign-up-name" name="address" placeholder="Listing Address"><!-- change for theme color -->
                                </div>

                                <div class="col-lg-12">
                                    <textarea rows="5" type="text" name="message" placeholder="Message Here"></textarea>
                                </div>
                            </div>
                            <button type="submit" class="ic-default-btn bg-color-secondary bg-color-secondary-hover">Send Message Now</button>

                        </form>
                    </div>
                </div>
            </div>
            @if(isset($user->location))
                <div class="row mt-3 mb-3">
                    <div class="col-lg-12">
                        <div class="ic-contacts-location-map">
                            {{-- <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7296.9489909298245!2d90.416468372094!3d23.87278743811659!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c5c5849459a3%3A0x627da4ef9bc6539a!2sUttar%20Khan%2C%20Dhaka%201230!5e0!3m2!1sen!2sbd!4v1617796845516!5m2!1sen!2sbd"
                                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe> --}}
                                <div class="ic-location-map">
                                    {{-- {!! $storyBoard->location !!} --}}
                                    <div id="map_canvas" style="width:100%; height:850px"></div>
                                </div>
                        </div>
                    </div>
                </div>
            @endif
        </div>

    </div>
    </div>
</section>

@endsection

@section('js')
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyB1taAMFjjJDItj7VVzlvsTvVrixJHHNqc&callback=initMap&libraries=places"></script>
@endsection

@section('script')

    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

       var map;
       var geocoder;
       function loadMap() {
           // Using the lat and lng of Dehradun.
           var latitude = {{ $user->latitude }};
           var longitude = {{ $user->longitude }};
           var latlng = new google.maps.LatLng(latitude,longitude);
           var feature = {
               zoom: 12,
               center: latlng,
               mapTypeId: google.maps.MapTypeId.ROADMAP
           };
           map = new google.maps.Map(document.getElementById("map_canvas"), feature);
           geocoder = new google.maps.Geocoder();
           var marker = new google.maps.Marker({
               position: latlng,
               map: map,
               title: "Test for Location"
           });
       }

    </script>

@endsection
