@extends('frontend.layouts.master')


@section('content')

{{-- login nav bar --}}
@include('frontend.common_nav.nav')

<!-- inner banner start -->
@if($user->background_image)
    <section class="ic-inner-page-banner" style="background-image: url('{{ Storage::url($user->background_image) }}')"></section>
@else
    <section class="ic-inner-page-banner" style="background-image: url({{ Storage::url(Settings::get('default_bg')) }})"></section>
@endif

<!-- inner banner end -->

<!-- user cover section start -->
<section class="ic-user-cover-section">
    <div class="container">
        <div class="ic-user-cover-inner">

            <div class="ic-user-cover-text">
                @if($user->photo)
                    <div class="ic-contact-image" style="background-image: url({{ Storage::url($user->photo) }})"></div>
                @else
                    <div class="ic-contact-image" style="background-image: url({{ Storage::url(Settings::get('default_profile')) }})"></div>
                @endif

                <div class="ic-user-cover-text-content">
                    <h2><strong>{{ $user->display_name }}</strong></h2>
                    <p>{{ $user->title }}</p>
                </div>
            </div>
            <ul class="ic-social-icon">
                @if ($user->facebook)
                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->facebook }}" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                @endif
                @if ($user->twitter)
                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->twitter }}" target="_blank"><i class="fab fa-twitter"></i></a></li>
                @endif
                @if ($user->linkdin)
                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->linkdin }}" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                @endif
                @if ($user->instragram)
                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->instragram }}" target="_blank"><i class="fab fa-instagram"></i></a></li>
                @endif
                @if ($user->youtube)
                    <li><a class="bg-color-secondary bg-color-secondary-hover" href="{{ $user->youtube }}" target="_blank"><i class="fab fa-youtube"></i></a></li>
                @endif
            </ul>
        </div>
    </div>
</section>
<!-- user cover section end -->

<!-- <div class="container">
    <ul class="ic-user-propety-tab">
        <li class="ic-user-properties active"><a href="javascript:void(0)">Single properties</a></li>
        <li class="ic-user-contact"><a href="javascript:void(0)">Contact mike</a></li>
    </ul>
</div> -->


<!-- image gallery start -->
<section class="ic-user-properties-wrap active">
    <div class="ic-properties-image-gallery">
        <div class="ic-image-gallery-inner">
            <div class="container">
                <div class="ic-user-properties-header">
                    <h2>Explore <strong class="main-color">Properties</strong></h2>
                </div>
            </div>

            <div class="ic-image-gallery-body">
                <div class="ic-image-gallery-body-inner row">
                    @foreach ($user->storyBoards as $key=>$storyboard)
                        <div class="col-lg-3 ic-team-item-card {{ $key>6?'ic-hide-div':'' }}">
                            @if (auth()->check())
                               {{-- @if (auth()->user()->user_type==1)
                                   <a href="{{ route('admin.storyboard.edit',[$storyboard->id]) }}" target="_blank" ><i class="fas fa-edit"></i></a>
                               @elseif((auth()->user()->user_type==0) && ($storyboard->user_id==auth()->user()->id))
                                    <a href="{{ route('client.storyboard.edit',[$storyboard->slug]) }}" target="_blank" ><i class="fas fa-edit"></i></a>
                               @else
                               @endif --}}
                               <a href="javascript:void(0)" data-toggle="modal" onclick="editProperty({{ json_encode($storyboard) }})" data-target="#editStoryBoard" class="ic-edit-this ic-ssn-btn"><i class="flaticon-edit-button"></i></a>
                            @endif


                            <a href="{{ route('show.property',['user_name'=>$user->user_name,'story_board'=>$storyboard->slug]) }}" class="ic-team-box-card">
                                <div class="ic-team-card">
                                    <div class="ic-team-img">
                                        <div class="ic-team-img-inner" style="background-image: url('{{ count($storyboard->boardGalleries)>0?Storage::url($storyboard->boardGalleries[0]->image):'' }}')">
                                        </div>
                                    </div>
                                    <div class="ic-team-info">
                                        <h6>{{ $storyboard->property_address }}</h6>
                                        <p>{{ $storyboard->property_address_line }}</p>
                                    </div>
                                </div>
                            </a>

                        </div>
                    @endforeach
                </div>
                @if (count($user->storyBoards)>6)
                    <div class="ic-view-all">
                        <div class="ic-buttons-text">
                            <p class="loading" style="display: none;">Loading....</p>
                            <a href="javascript:void(0)" class="ic-secondary-btn view-more-bth" tabindex="0">view more</a>
                        </div>
                    </div>
                @endif

            </div>
        </div>
    </div>
</section>



@endsection

@section('js')
<script src="https://cdn.tiny.cloud/1/bv4pyu6ub1by8idjsr8gydy6ckw8m1xnmqy5yhmjjzwl044g/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
@endsection

@section('script')

<script>
    function editProperty(storyboard)
    {
        console.log(storyboard.about_property)

        $("#storyBoardAboutProperty").val(storyboard.about_property);

        tinymce.init({
          selector: "#storyBoardAboutProperty"
        });

        $("input[name='storyboard_slug']").val(storyboard.slug);
        $('#editStoryBoardLabel').html(storyboard.property_address)
        $("input[name='property_price']").val('$'+addCommas(storyboard.property_price));

        $("input[name='build_year']").val(storyboard.year);
        $("input[name='square_feets']").val(addCommas(storyboard.square_feets));
        $("input[name='bedroom']").val(storyboard.bedroom);
        $("input[name='bathroom']").val(storyboard.bathroom);
        if (storyboard.show_about==1) {
            $("#aboutShow").prop("checked", true);
        }
    }

    $('#editStoryBoard').on('hidden.bs.modal', function () {
      // console.log('remove')
      $("#storyBoardAboutProperty").val(" ");
      tinymce.remove("#storyBoardAboutProperty");
    });

    function addCommas(nStr)
    {
        if(nStr!=null){
            nStr += '';
            x = nStr.split('.');
            x1 = x[0];
            x2 = x.length > 1 ? '.' + x[1] : '';
            var rgx = /(\d+)(\d{3})/;
            while (rgx.test(x1)) {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            }
            return x1 + x2;
        }else{
            return 0;
        }
    }


</script>

@endsection
