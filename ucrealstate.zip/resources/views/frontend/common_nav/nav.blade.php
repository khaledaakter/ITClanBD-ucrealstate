
<section class="ic-user-header-section">
    <div class="ic-container">
        <div class="ic-user-header-inner">
            <a class="ic-main-logo" href="{{ route('agent.profile',[$user->user_name]) }}">
                @if (isset($user->logo))
                  <img src="{{ asset(Storage::url($user->logo)) }}" alt="">
                 @else
                   <h4 style="color: #000">{{ $user->full_name }}</h4> 
                @endif
            </a>

            <ul class="ic-user-icons">
                  @if(auth()->check())
                    @if (auth()->user()->user_type==1)
                      <li>
                        <a href="{{ route('admin.edit-profile',[auth()->user()->id]) }}" class="nav-link"><i class="far fa-user"></i> &nbsp;Edit Profile</a>
                      </li>
                    @endif
                    @if (auth()->user()->user_type==0)
                      <li>
                        <a href="{{ route('client.edit_profile') }}" class="nav-link"><i class="far fa-user"></i> &nbsp;Edit Profile</a>
                      </li>
                    @endif


                    <li>
                      <a href="{{ route('logout.frontend') }}" class="nav-link"><i class="fas fa-power-off text-danger"></i> &nbsp;Log Out</a>
                    </li>
                  @else
                    <li>
                        <a data-toggle="modal" data-target="#loginModal" class="nav-link"><i class="fas fa-sign-in-alt"></i> &nbsp;Login</a>
                      </li>
                  @endif
            </ul>
           
        </div>
    </div>
</section>



{{-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">
    @if (isset($user->logo))
      <img src="{{ asset(Storage::url($user->logo)) }}" alt="">
     @else
       <h4>{{ $user->full_name }}</h4> 
    @endif
  </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>


  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      
      	@if(auth()->check())
      		@if (auth()->user()->user_type==1)
      			<li class="nav-item">
  		    		<a href="{{ route('admin.edit-profile',[auth()->user()->id]) }}" class="nav-link"><i class="far fa-user"></i> &nbsp;Edit Profile</a>
  		    	</li>
      		@endif
  	    	@if (auth()->user()->user_type==0)
            <li class="nav-item">
              <a href="{{ route('client.edit_profile') }}" class="nav-link"><i class="far fa-user"></i> &nbsp;Edit Profile</a>
            </li>
          @endif


  	    	<li class="nav-item">
  	    		<a href="{{ route('logout.frontend') }}" class="nav-link"><i class="fas fa-power-off text-danger"></i> &nbsp;Log Out</a>
  	    	</li>
      	@else
  	    	<li class="nav-item">
  	      		<a data-toggle="modal" data-target="#loginModal" class="nav-link"><i class="fas fa-sign-in-alt"></i> &nbsp;Login</a>
  	      	</li>
        @endif
      
    </ul>
  </div>

</nav> --}}


{{-- Login Modal --}}

<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Login</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="{{ route('system.login') }}" method="POST">
        	@csrf
        	<div class="form-group">
        		<input type="email" name="email" class="form-control" placeholder="Email">
        	</div>
        	<div class="form-group">
        		<input type="password" name="password" class="form-control" placeholder="Password">
        	</div>

        	<button type="submit" class="btn btn-primary">Login</button>

        	<p class="mb-2 text-muted">Forgot password? <a href="{{ route('reset.password') }}" class="f-w-400">Reset</a></p>
        </form>
      </div>
    </div>
  </div>
</div>


{{-- Story Board Edit Modal --}}
<div class="modal fade" id="editStoryBoard" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editStoryBoardLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="{{ route('storyboard.update') }}" method="POST">
          @csrf
 
            <input type="hidden" name="storyboard_slug" value="">

            <div class="row">
              <div class="col-md-12">
                <div class="form-group float-right">
                    <input type="checkbox" name="show_about" class="" value="1" id="aboutShow">
                    <label class="" for="">Show</label>
                </div>

                <div class="form-group">
                  <label for="">Property price</label> 
                  <input type="text" name="property_price" class="form-control" placeholder="Property price">
                </div>

                <div class="form-group">
                  <label for="">About Property</label>
                  <textarea name="about_property" class="form-control" id="storyBoardAboutProperty" cols="30" rows="10"></textarea>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <label for="">Year Built</label>
                  <input type="number" name="build_year" class="form-control" placeholder="Year Built">
                </div>
              </div>
              <div class="col-md-3">
                
                <div class="form-group">
                  <label for="">Square Feet</label>
                  <input type="text" name="square_feets" class="form-control" placeholder="Square Feet">
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label for="">Bedroom(s)</label>
                  <input type="number" name="bedroom" class="form-control" placeholder="Bedrooms">
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label for="">Bathroom(s)</label>
                  <input type="number" name="bathroom" class="form-control" placeholder="Bathrooms">
                </div>
              </div>
            </div>

            <button type="submit" class="btn btn-success">Update</button>
        </form>
      </div>
    </div>
  </div>
</div>