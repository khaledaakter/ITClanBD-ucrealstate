<!-- <script src="assets/js/jquery-3.6.0.min.js"></script> -->
<script src="{{ asset('frontend/assets/js/jquery-1.11.0.min.js') }}"></script>
<script src="{{ asset('frontend/assets/js/onepageNav.js') }}"></script>
<!-- image zoom Js -->
<!-- <script src="{{ asset('frontend/assets/js/zoom.jquery.js') }}"></script> -->
<script src="{{ asset('frontend/assets/js/jquery.panorama_viewer.js') }}"></script><!-- 360 image js -->
<script src="{{ asset('frontend/assets/js/aos.js') }}"></script><!-- aos animation js -->
<!-- <script src="assets/js/wow.js"></script>wow animation js -->
<script src="{{ asset('frontend/assets/js/bootstrap.min.js') }}"></script><!-- bootstrap slider -->
<script src="{{ asset('frontend/assets/js/slick.min.js') }}"></script><!-- slick slider -->
<script src="{{ asset('frontend/assets/js/lightbox.js') }}"></script><!-- lightbox Js -->

<script src="https://cdn.jsdelivr.net/npm/three/build/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/uevent@2/browser.min.js"></script>
{{-- <script src="https://cdn.jsdelivr.net/npm/photo-sphere-viewer@4/dist/photo-sphere-viewer.min.js"></script> --}}
<script src="{{ asset('frontend/assets/js/photo-sphere-viewer.min.js') }}"></script><!-- lightbox Js -->



{{-- Toster Notification --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script>
	@if(Session::has('success'))
	    toastr.success("{{ Session::get('success') }}");
	@endif
	@if(Session::has('error'))
	  toastr.error("{{ Session::get('error') }}");
	@endif
</script>

<script src="{{ asset('frontend/assets/js/custom.js') }}"></script><!-- custom js -->

@yield('js')

@yield('script')
