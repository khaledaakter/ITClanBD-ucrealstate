    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    @if(isset($page_title))
        <title>{{ $page_title }}</title>
    @elseif (Settings::get('title'))
        <title>{{ Settings::get('title') }}</title>
    @else
        <title>Uplan.co</title>
    @endif
    <!-- Google fonts -->
    @if (Settings::get('fabicon'))
    <link rel="icon" href="{{Storage::url(Settings::get('fabicon'))}}" type="image/x-icon">
    @else
    <link rel="icon" href="{{asset('dashboard/assets/images/favicon.svg')}}" type="image/x-icon">
    @endif
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&display=swap" rel="stylesheet">
    <!-- <link rel="stylesheet" href="{{ asset('frontend/assets/css/zoom.css') }}"> -->
    <link rel="stylesheet" href="{{ asset('frontend/assets/css/lightbox.css') }}"><!--lightbox Css-->
    <link rel="stylesheet" href="{{ asset('frontend/assets/fontawesome/css/fontawesome-all.min.css') }}">
    <link href="{{ asset('frontend/assets/css/aos.css') }}" rel="stylesheet"> <!-- aos animation -->
    <link href="{{ asset('frontend/assets/css/animate.css') }}" rel="stylesheet"><!-- animate for wow -->
    <link href="{{ asset('frontend/assets/css/bootstrap.min.css') }}" rel="stylesheet"><!-- bootstrap -->
    <link href="{{ asset('frontend/assets/css/slick.css') }}" rel="stylesheet"><!-- slick slider -->
    <link href="{{ asset('frontend/assets/webfonts/font/flaticon.css') }}" rel="stylesheet"><!-- Ico Font -->
    <link href="{{ asset('frontend/assets/css/custom.css') }}" rel="stylesheet"><!-- custom Style -->
    <link href="{{ asset('frontend/assets/css/style.css') }}" rel="stylesheet"><!-- custom Style -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/photo-sphere-viewer@4/dist/photo-sphere-viewer.min.css"/>
    {{-- toster Notification --}}
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">


    <style>
        /*new css*/
        ul.navbar-nav li.nav-item.active a,
        ul.navbar-nav li.nav-item a:hover,
        ul.navbar-nav li.nav-item.active a:hover,
        .ic-team-box-card:hover .ic-team-card .ic-team-info h6,
        #onepage-nav li a.scroll.active,
        .color-secondary-hover:hover,
        .main-color {
            color: {{ $theme_colors?$theme_colors[0]->color:'#6595BF' }};
        }
        .secondary {
            color: {{ $theme_colors?$theme_colors[1]->color:'#82B8D9' }};
        }
        ul.navbar-nav li.nav-item .page-scroll.active::after,
        ul.navbar-nav li.nav-item a:hover::after,
        .slick-dots li.slick-active,
        .slick-dots li:hover,
        .bg-color-secondary-hover:hover,
        .ic-tour-tab-list.nav-pills a.nav-link:hover,
        .bg-main-color {
            background-color: {{$theme_colors?$theme_colors[0]->color:'#6595BF' }};
        }
        .ic-tour-tab-list li a:hover,
        .ic-tour-tab-list.nav-pills .nav-link.active,
        .ic-tour-tab-list.nav-pills .show>.nav-link,
        .bg-color-secondary {
            background-color: {{ $theme_colors?$theme_colors[1]->color:'#82B8D9' }};
        }
        .bg-color-footer {
            background-color: {{ $theme_colors?$theme_colors[3]->color:'#6595BF' }};
        }
        .darkBlue1 {
            color: {{ $theme_colors?$theme_colors[0]->color:'#3B5998' }};
        }
        .lightBlue {
            color: {{ $theme_colors?$theme_colors[0]->color:'#55ACEE' }};
        }

        
        .ic-default-btn:hover,
        .ic-secondary-btn:hover,
        .bg-color-secondary-hover:hover,
        .bg-color-secondary-hover,
        /* .ic-tour-tab-list.nav-pills .nav-link.active, */
        /* .ic-tour-tab-list.nav-pills .nav-link.active i, */
        .ic-tour-tab-list.nav-pills .show > .nav-link,
        .ic-tour-tab-list .nav-item a:hover,
        .ic-tour-tab-list .nav-item a:hover i,
        .ic-tour-tab-list .nav-item a,
        .ic-tour-tab-list.nav-pills .nav-link,
        .ic-tour-tab-list.nav-pills .nav-link i,
        /* .ic-tour-tab-list li a i, */
        /* .ic-tour-tab-list li a:hover i, */
        .ic-main-slider-text {
            color: {{ $theme_colors?$theme_colors[2]->color:'#55ACEE' }};
        }
        .ic-tour-tab-list.nav-pills .show > .nav-link svg path,
        .ic-tour-tab-list.nav-pills .show > .nav-link svg rect,
        .ic-tour-tab-list .nav-item a:hover svg rect,
        .ic-tour-tab-list .nav-item a:hover svg path,
        .ic-tour-tab-list.nav-pills .nav-link.active svg path,
        .ic-tour-tab-list.nav-pills .nav-link.active svg rect,
        .ic-tour-tab-list li a:hover svg path,
        .ic-tour-tab-list li a:hover svg rect {
            fill: {{ $theme_colors?$theme_colors[2]->color:'#55ACEE' }};
        }
        /* .ic-tour-tab-list.nav-pills .nav-link svg path{
            fill: {{ $theme_colors?$theme_colors[2]->color:'#55ACEE' }};
        } */

        /* ul.navbar-nav li.nav-item.active a,
        ul.navbar-nav li.nav-item a:hover,
        ul.navbar-nav li.nav-item.active a:hover,
        .ic-team-box-card:hover .ic-team-card .ic-team-info h6,
        #onepage-nav li a.scroll.active,
        .color-secondary-hover:hover,
        .main-color {
            color: {{ $theme_colors?$theme_colors[0]->color:'#6595BF' }};
        }
        .secondary {
            color: {{ $theme_colors?$theme_colors[1]->color:'#82B8D9' }};
        }
        ul.navbar-nav li.nav-item .page-scroll.active::after,
        ul.navbar-nav li.nav-item a:hover::after,
        .slick-dots li.slick-active,
        .slick-dots li:hover,
        .bg-color-secondary-hover:hover,
        .ic-tour-tab-list.nav-pills a.nav-link:hover,
        .bg-main-color {
            background-color: {{$theme_colors?$theme_colors[0]->color:'#6595BF' }};
        }
        .ic-tour-tab-list li a:hover,
        .ic-tour-tab-list.nav-pills .nav-link.active,
        .ic-tour-tab-list.nav-pills .show>.nav-link,
        .bg-color-secondary {
            background-color: {{ $theme_colors?$theme_colors[1]->color:'#82B8D9' }};
        }

        .bg-color-footer {
            background-color: {{ $theme_colors?$theme_colors[3]->color:'#6595BF' }};
        }

        .darkBlue1 {
            color: {{ $theme_colors?$theme_colors[0]->color:'#3B5998' }};
        }


        .lightBlue {
            color: {{ $theme_colors?$theme_colors[0]->color:'#55ACEE' }};
        }

        .ic-default-btn:hover,
        .ic-secondary-btn:hover,
        .bg-color-secondary-hover,
        .ic-tour-tab-list.nav-pills .show > .nav-link,
        .ic-tour-tab-list .nav-item a:hover,
        .ic-main-slider-text {
            color: {{ $theme_colors?$theme_colors[2]->color:'#55ACEE' }};
        }



        .ic-tour-tab-list.nav-pills .show > .nav-link svg path,
        .ic-tour-tab-list.nav-pills .show > .nav-link svg rect,
        .ic-tour-tab-list .nav-item a:hover svg rect,
        .ic-tour-tab-list .nav-item a:hover svg path,
        .ic-tour-tab-list.nav-pills .nav-link.active svg path,
        .ic-tour-tab-list.nav-pills .nav-link.active svg rect,
        .ic-tour-tab-list li a:hover svg path,
        .ic-tour-tab-list li a:hover svg rect {
            fill: {{ $theme_colors?$theme_colors[2]->color:'#55ACEE' }};
        } */

        


    </style>

    @yield('css')
