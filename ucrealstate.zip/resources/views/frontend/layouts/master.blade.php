<!doctype html>
<html lang="en">

<head>
    @include('frontend.layouts._head')
</head>

<body data-spy="scroll" data-target="#navbar-example" data-offset="50" onload="loadMap()">


<div class="ic-user-contact-button"><a class="bg-color-secondary bg-color-secondary-hover" href="{{ route('contact.user',[$user->user_name]) }}" target="blank">Contact {{ $user->first_name }}</a></div>
    

@yield('content')

<!-- first footer start -->

<section class="ic-footer-main-wrap bg-color-footer">
    <div class="ic-footer-inner">
        {{-- <a href="index.php"><img src="{{ Storage::url($user->logo) }}" alt=""></a> --}}
        <a href="https://uplan.co/"><img src="{{ Storage::url(Settings::get('logo')) }}" alt=""></a>
        <p class="ic-copyright">Copyright ⓒ 2021 Uplan Photography & Measuring. All Rights Reserved.</p>
    </div>
</section>
{{-- <section class="ic-footer-main-wrap">
    <div class="ic-footer-inner">
        <a href="index.php"><img src="{{ Storage::url($user->logo) }}" alt=""></a>
        <p class="ic-copyright">Copyright ⓒ 2021 Uplan Photography & Measuring. All Rights Reserved.</p>
    </div>
</section> --}}
<!-- first footer end -->

@include('frontend.layouts._script')
</body>

</html>