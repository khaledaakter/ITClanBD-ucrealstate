
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  @include('admin.layouts._head')
</head>
<body>
  <form method="POST" action="{{ route('set.password',['uuid'=>$uu_id]) }}">
    @csrf

    <div class="auth-wrapper">
      <div class="auth-content container">
        <div class="card">
          <div class="row align-items-center">
            <div class="col-md-6">
              <div class="card-body">
                @if (Settings::get('logo'))
                    <img src="{{ Storage::url('Settings') }}/{{ Settings::get('logo') }}" alt="" class="img-fluid mb-4">
                @else
                    <img src="{{ asset('dashboard/assets/images/logo.svg') }}" alt="" class="img-fluid mb-4">
                @endif
                <h4 class="mb-3 f-w-400">Change your password</h4>
                <div class="form-group mb-2">
                  <label class="form-label">New Password</label>
                  <input type="password" name="password" class="form-control" placeholder="New Password">
                  @error('password')
                    <span class="text-danger">{{ $message }}</span>
                  @enderror
                </div>
                <div class="form-group mb-2">
                  <label class="form-label">Re-Type New Password</label>
                  <input type="password" name="password_confirmation" class="form-control" placeholder="Re-Type New Password">
                </div>
                <button class="btn btn-primary mb-4">Change Password</button>
              </div>
            </div>
            <div class="col-md-6 d-none d-md-block">
              @if (Settings::get('login_image'))
                  <img src="{{ Storage::url('Settings') }}/{{ Settings::get('login_image') }}" alt="" class="img-fluid">
              @else
                  <img src="{{ asset('dashboard/assets/images/login.jpg') }}" alt="" class="img-fluid">
              @endif
            </div>
          </div>
        </div>
      </div>
    </div>
  </form>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
  <script type="text/javascript">
    $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
    @if(Session::has('success'))
        toastr.success("{{ Session::get('success') }}");
      @endif
    @if(Session::has('error'))
      toastr.error("{{ Session::get('error') }}");
    @endif
  </script>  
  @include('admin.layouts._script')
</body>
</html>
