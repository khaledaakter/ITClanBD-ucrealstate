<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/clear', function() {
    \Illuminate\Support\Facades\Artisan::call('cache:clear');
    \Illuminate\Support\Facades\Artisan::call('config:clear');
    \Illuminate\Support\Facades\Artisan::call('config:cache');
    \Illuminate\Support\Facades\Artisan::call('view:clear');
    \Illuminate\Support\Facades\Artisan::call('route:clear');
    \Illuminate\Support\Facades\Artisan::call('optimize:clear');
    return "Cleared!";
});

Route::get('/migrate', function() {
    \Illuminate\Support\Facades\Artisan::call('migrate');
    return "migrate!";
});

Route::get('/seed', function() {
    \Illuminate\Support\Facades\Artisan::call('db:seed');
    return "seeder!";
});


// Route::get('/', function () {
//     return view('welcome');
// });
// Auth::routes();



Route::get('/','LoginController@login')->name('home');
Route::post('/login','LoginController@submitLogin')->name('login');
Route::post('/system/login','LoginController@systemSubmitLogin')->name('system.login');

Route::get('logout','LoginController@logout')->name('logout');
Route::get('logout-frontend','LoginController@logoutfrontend')->name('logout.frontend');

// View Client Profile
Route::get('/{user:user_name}','FrontendController@profile')->name('agent.profile');
Route::get('/{user:user_name}/contact','FrontendController@contact')->name('contact.user');
Route::get('/{user_name}/{story_board}','FrontendController@property')->name('show.property');
// Reset Password
Route::get('reset/password/show','FrontendController@viewReset')->name('reset.password');
Route::post('reset/password/send','LoginController@resetPassword')->name('send.reset.password');
Route::get('set/new/password/{uuid}','LoginController@setNewPassword')->name('set.new.password');
Route::post('set/password/{uuid}','LoginController@createNewPassword')->name('set.password');

// Get location
Route::post('get-distance','FrontendController@getDistance')->name('get.distance');
// Send message route
Route::post('send-message','FrontendController@sendMessage')->name('send_message');


Route::middleware(['auth'])->group(function(){
    Route::post('storyboard-update','FrontendController@updateStoryBoard')->name('storyboard.update');
});
// Update Story Board


