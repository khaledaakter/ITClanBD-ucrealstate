<?php

use Illuminate\Support\Facades\Route;

Route::middleware(['admin','web'])->group(function () {
	Route::get('/dashboard','LoginController@dashboard')->name('dashboard');
	// Get Office
	Route::get('office/select-country','OfficeController@setCountry')->name('office.select-country');
	Route::get('office/select-state','OfficeController@setState')->name('office.select-state');

	Route::get('client/check-url','ClientController@checkUrl')->name('client.check-url');

	Route::get('profile','LoginController@editProfile')->name('edit-profile');
	Route::post('profile/update','LoginController@updateProfile')->name('profile.update');

	Route::get('client/trashed','ClientController@trashedList')->name('client.trashed');
	Route::post('client/restore/{id}','ClientController@restore')->name('client.restore');

	Route::get('office/trashed','OfficeController@trashedList')->name('office.trashed');
	Route::post('office/restore/{id}','OfficeController@restore')->name('office.restore');

	Route::get('user/trashed','UserController@trashedList')->name('user.trashed');
	Route::post('user/restore/{id}','UserController@restore')->name('user.restore');

	Route::get('storyboard/trashed','StoryBoardController@trashedList')->name('storyboard.trashed');
	Route::post('storyboard/restore/{id}','StoryBoardController@restore')->name('storyboard.restore');
	Route::get('storyboard/delete-file','StoryBoardController@deleteFile')->name('storyboard.delete-file');
	Route::get('storyboard/own-delete-file','StoryBoardController@StoryBoardDeleteFile')->name('storyboard.own-delete-file');
	Route::get('client/theme-color','StoryBoardController@clientThemeColor')->name('theme.color');
	Route::get('storyboard/update-invoice','StoryBoardController@updateInvoice')->name('storyboard.update_invoice');
	Route::get('storyboard/update-favorite','StoryBoardController@updateFavorite')->name('storyboard.update_favorite');
    // Storyboard Email
	Route::post('storyboard/send/photo','StoryBoardController@sendPhoto')->name('storyboard.send.photo');
	Route::post('storyboard/send/video','StoryBoardController@sendVideo')->name('storyboard.send.video');
	Route::post('storyboard/send/floor','StoryBoardController@sendFloor')->name('storyboard.send.floor');
	Route::post('storyboard/send/metter','StoryBoardController@sendMetter')->name('storyboard.send.metter');
	Route::post('storyboard/send/panaroma','StoryBoardController@sendPanaroma')->name('storyboard.send.panaroma');
	Route::post('storyboard/get-embed-code','StoryBoardController@getEmbedCode')->name('storyboard.get-embed-code');

	Route::resources([
		'office'		=>OfficeController::class,
		'client'		=>ClientController::class,
		'role'			=>RoleController::class,
		'user'			=>UserController::class,
		'setting'		=>SettingController::class,
		'note'			=>NoteController::class,
		'storyboard'	=>StoryBoardController::class,
		'widget'		=>WidgetController::class
	]);




});
