<?php

use Illuminate\Support\Facades\Route;

Route::middleware(['client','web'])->group(function () {
	Route::get('/home','LoginController@dashboard')->name('dashboard');
	Route::get('edit-profile','LoginController@editProfile')->name('edit_profile');
	Route::post('profile/update','LoginController@updateProfile')->name('profile.update');

	// StoryBoard
	Route::get('storyboard','StoryBoardController@index')->name('storyboard.index');
	Route::get('storyboard/edit/{slug}','StoryBoardController@edit')->name('storyboard.edit');
	Route::get('storyboard/delete-file','StoryBoardController@StoryBoardDeleteFile')->name('storyboard.delete-file');
	Route::post('storyboard/update/{slug}','StoryBoardController@updateStoryBoard')->name('storyboard.update');


	Route::get('show/gallery/{slug}','StoryBoardController@showGallery')->name('property.gallery');
	Route::get('show/video/{slug}','StoryBoardController@showVideo')->name('property.video');
	Route::get('show/property-plan/{slug}','StoryBoardController@showPropertyPlan')->name('property.property_plan');


	Route::get('note/trashed','NoteController@trashedList')->name('note.trashed');
	Route::post('note/restore/{id}','NoteController@restore')->name('note.restore');
	Route::resources([
		'note'=>NoteController::class
	]);



	
});