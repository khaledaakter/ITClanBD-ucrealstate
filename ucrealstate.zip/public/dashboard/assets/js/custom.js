/*==============================
		custom js
============================== */
$(document).ready(function () {
    // [ Single Select ]
    if($(".js-example-basic-single").length > 0){
        $(".js-example-basic-single").select2();
    }


    var uppy = Uppy.Core()
    .use(Uppy.Dashboard, {
      inline: true,
      target: '#drag-drop-area'
    })
    .use(Uppy.Tus, {endpoint: 'https://tusd.tusdemo.net/files/'})

    uppy.on('complete', (result) => {
        console.log('Upload complete! We’ve uploaded these files:', result.successful)
    })
    
});