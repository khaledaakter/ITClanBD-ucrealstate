/*==============================
		custom datatable js
============================== */

$(document).ready(function () {
    var total;
    var table = $('#colum-rendr').DataTable({
    language: {
        searchPlaceholder: "Search Here",
        search: '<i class="feather icon-search"></i>',
        paginate: {
                next: '<i class="feather icon-arrow-right"></i>',
                previous: '<i class="feather icon-arrow-left"></i>',

        }
    }
});
$('.dataTable').wrap('<div class="table-responsive"></div>');
});