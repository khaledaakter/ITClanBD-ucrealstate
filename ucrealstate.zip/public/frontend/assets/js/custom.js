(function($) {
    'use strict'

    $('[data-toggle="tooltip"]').tooltip();

    /*========================================
        Scroll  top button
    ========================================*/

    // var scrollTop = $('.ic-scroll-top');
    // $(window).scroll(function () {
    //     if ($(this).scrollTop() > 500) {
    //      scrollTop.show();
    //         scrollTop.css({
    //             'bottom': '24%',
    //             'opacity': '1',
    //             'transition': 'all .5s ease-in-out'
    //         });
    //     } else {
    //         scrollTop.css({
    //             'bottom': '-15%',
    //             'opacity': '0',
    //             'transition': 'all .5s ease-in-out'
    //         })
    //     }
    // });
    // scrollTop.on('click', function () {
    //     $('html, body').animate({
    //         scrollTop: 0
    //     }, 500);
    //     return false;
    // });  
    
    // =======================
    // WOW js
    // =======================

    // new WOW().init();

    // =======================
    // lightbox js
    // =======================

    // var gallery = $('.ic-image-gallery-body a').simpleLightbox({
    //     widthRatio: 0.8,
    //     heightRatio: 0.9,    
    // });
        

    lightbox.option({
        positionFromTop: 0,
        wrapAround:true,
        loop:true,
    });

    // =======================
    //  AOS js
    // =======================

    AOS.init();

    // =======================
    //  360 image js
    // =======================
    // $(".panorama").panorama_viewer({
    //     repeat: true,
    //     autoRotate: true,
    // });

    


    // ========================================
    // ic-top-slider
    // ========================================

    $('.ic-slider-box').slick({
        dots: true,
        arrows: false,
        infinite: true,
        speed: 700,
        slidesToShow: 1,
        slidesToScroll: 1,
        // autoplay: true,
        // autoplaySpeed: 1500,
    });

    // ========================================
    // ic-panorama-slider
    // ========================================

    
    // $('.slider-for').slick({
    //     slidesToShow: 1,
    //     slidesToScroll: 1,
    //     arrows: false,
    //     dots: false,
    //     fade: true,
    //     asNavFor: '.slider-nav'
    // });

    // $('.slider-nav').slick({
    //     slidesToShow: 3,
    //     // slidesToScroll: 1,
    //     asNavFor: '.slider-for',
    //     dots: false,
    //     arrows: false,
    //     centerMode: false,
    // // focusOnSelect: true
    // });

    $('.carousel').carousel({
        interval: 2000,
        autoplay:false,
        slideSpeed: 2000,
        paginationSpeed: 2000,
        autoplayTimeout:2000,
        loop:false,
        fade: true,
        interval: false,
    });



    /*========================================
    Preloader/relode
    ========================================*/

    $(window).on('load', function () {
        $(".ic-preloader").fadeOut(500);
    });
    


    /*========================================
    Ic Mobile menu activation
    ========================================*/

    var $navOpen = $(".offcanvas_main_menu li a");  

    $('.ic-mobile-menu-open,.ic-mobile-menu-overlay').on('click', function () {
        $('.ic-mobile-menu-wrapper,.ic-mobile-menu-overlay').addClass('active')
    });
    $('.ic-menu-close,.ic-mobile-menu-overlay').on('click', function () {
        $('.ic-mobile-menu-wrapper,.ic-mobile-menu-overlay').removeClass('active')
    }); 
    // mobile menu hide in any menu click 
    $navOpen.on('click', function(){
        $('.ic-mobile-menu-wrapper,.ic-mobile-menu-overlay').removeClass("active");
    }); 
    // single page menu active  
    // $(".nav-item").on("click", function(e){
    //     $("li.nav-item").removeClass("active");
    //     $(this).addClass("active");
    // });

    
    

    /*========================================
        sticky header
    ========================================*/

    $(window).on('scroll', function() {
        var scrolling = $(this).scrollTop();
        if (scrolling > 50) {
            $('.navbar').addClass('sticky-menu');
        } else {
            $('.navbar').removeClass('sticky-menu');
        }

    });

    /*========================================
        smoothly scrool by menu
    ========================================*/   


    $(document).on('click', '.page-scroll', function (event) {

        if (this.hash !== "") {
            event.preventDefault();
    
            var hash = this.hash;
            $('html').animate({
                scrollTop: $(hash).offset().top - 74
            }, 0);
        }
    });

    /*========================================
        video-player play pause
    ========================================*/
   
    let playerButton = $('.ic-video-player');

    playerButton.on('click',function(){
        if(playerButton.hasClass('play-this')){
            $('.ic-video-player').removeClass('play-this');
            $('#ic-video-tour').get(0).pause();
            $('#ic-video-tour-iframe').get(0).pause();

        } else {
            $('.ic-video-player').addClass('play-this');
            $('#ic-video-tour').get(0).play();
            $('#ic-video-tour-iframe').get(0).play();
        };
    });


    // $('.ic-view-more-btn').on('click',function{
    //     $('.ic-view-all').addClass('hide');
    // });
    

    
    // ========================================
    // hide-div show
    // ========================================

    $('.ic-hide-div').hide();
    $('.loading').hide();
    $('.view-more-bth').on('click', function(){
        $(this).hide();
        $('.ic-hide-div').show('slow');
        $('.loading').show();
        setTimeout(function(){
            // $('.view-more-bth').show();
            $('.loading').hide();
        }, 1000);
    });

    // ========================================
    // image zoom 
    // ========================================

    // function activateMaps() {

    //     let zoomMap = $('.maps-container-inner').ZoomArea({
    //         zoomLevel: 1,
    //         minZoomLevel: 1,
    //         maxZoomLevel: 15,
    //         parentOverflow: 'auto',
    //         exceptionsZoom: ['marker-all'],
    //         hideWhileAnimate: ['map-area', 'marker-all'],
    //         externalIncrease: '.map-control-zoomin',
    //         externalDecrease: '.map-control-zoomout',
    //         virtualScrollbars: false,
    //         usedAnimateMethod: 'jquery'
    //     });
    
    //     resizeFilterPanel();
    // }
    
    // function resizeFilterPanel() {
    //     // $('.map-filter').removeAttr('style');
    //     if (parseInt($('.measurement').css('max-width'), 10) > 768) {
    //         // $('.map-filter').css('height', $('.maps-container').outerHeight() + 'px');
    //     }
    // }
    
    
    // $(window).on("load", function () {
    //     activateMaps();
    // });
    
    // $(window).on("resize", function () {
    //     resizeFilterPanel();
    // });

    // ==========================================
    // image full screen like lightbox
    // ==========================================


    // $('.map-full-view').on('click',function(){
    //     $('.floor-plan-full-view').addClass('hide');
    // });

    // $('.map-full-view-close').on('click',function(){
    //     $('.floor-plan-full-view').removeClass('hide');
    // });

    $(document).ready(function ($) {
        $('.cycle').cyclotron();
        // autoplay: true,
    });

    // ==========================================
    // footer fixing on bottom
    // ==========================================

    var footerHeight = document.querySelector('.ic-footer-main-wrap').offsetHeight;
    document.querySelector('body').style.paddingBottom = footerHeight + "px";

    // ==========================================
    // 3:2 image and Panorama ratio
    // ==========================================

    $(window).on('resize load', function(){

        var imageTag = $('.ic-team-img').width();
        var imageCalcHeight = ((imageTag/3)*2);
        $('.ic-team-img').height(imageCalcHeight + 'px');    
   
        var panoramaBox = $('.ic-panorama-tour-tab').width();
        var panoramaHeight = ((panoramaBox/3)*2);
        $('.ic-panorama-tour-tab').height(panoramaHeight + 'px');
        // $('.ic-team-card,.ic-team-img').css({"height": "75%"});
    });

    



      
})(jQuery);






