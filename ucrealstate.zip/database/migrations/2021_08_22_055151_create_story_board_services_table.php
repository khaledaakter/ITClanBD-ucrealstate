<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStoryBoardServicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('story_board_services', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('story_board_id');
            $table->unsignedBigInteger('client_id');
            $table->integer('service_p')->default(0);
            $table->integer('service_v')->default(0);
            $table->integer('service_f')->default(0);
            $table->integer('service_m')->default(0);
            $table->integer('service_pa')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('story_board_services');
    }
}
