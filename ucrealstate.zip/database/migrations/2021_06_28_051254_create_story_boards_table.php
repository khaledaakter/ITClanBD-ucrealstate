<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStoryBoardsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('story_boards', function (Blueprint $table) {
            $table->id();
            $table->string('property_name')->nullable();
            $table->string('property_address')->nullable();
            $table->string('property_address_line')->nullable();
            $table->string('unit')->nullable();
            $table->string('road_number')->nullable();
            $table->string('road_name')->nullable();
            $table->string('road_type')->nullable();
            $table->string('city')->nullable();

            $table->integer('show_about')->default(0);
            $table->integer('property_price')->nullable();
            $table->text('about_property')->nullable();
            $table->string('property_image')->nullable();

            $table->integer('year')->nullable();
            $table->integer('square_feets')->nullable();
            $table->integer('bedroom')->nullable();
            $table->integer('bathroom')->nullable();

            $table->text('p_high_resolution')->nullable();
            $table->text('p_lms')->nullable();
            $table->text('p_video_link')->nullable();
            $table->text('p_video_iframe')->nullable();
            $table->string('p_download_link')->nullable();
            $table->string('p_floor_plan')->nullable();
            $table->string('p_metterport')->nullable();
            $table->string('panorama')->nullable();
            $table->string('p_room_name')->nullable();

            $table->text('location')->nullable();
            $table->string('latitude')->nullable();
            $table->string('longitude')->nullable();

            $table->string('walkable')->nullable();
            $table->string('transit')->nullable();
            $table->string('bikeable')->nullable();
            
            $table->string('slug')->unique();
            $table->index('slug');

            $table->string('theme_color')->nullable();
            $table->integer('status')->nullable()->command('0=incompleted,1=completed');
            $table->unsignedBigInteger('user_id')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            
            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            
            $table->integer('p_email')->default(0)->commend('o email not send,1 email send');
            $table->integer('v_email')->default(0)->commend('o email not send,1 email send');
            $table->integer('f_email')->default(0)->commend('o email not send,1 email send');
            $table->integer('m_email')->default(0)->commend('o email not send,1 email send');
            $table->integer('pa_email')->default(0)->commend('o email not send,1 email send');
            
            $table->softDeletes();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('story_boards');
    }
}
