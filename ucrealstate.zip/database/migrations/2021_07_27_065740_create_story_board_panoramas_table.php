<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStoryBoardPanoramasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('story_board_panoramas', function (Blueprint $table) {
            $table->id();
            $table->string('p_room_name')->nullable();
            $table->string('panorama_photo')->nullable();
            $table->unsignedBigInteger('story_board_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('story_board_panoramas');
    }
}
