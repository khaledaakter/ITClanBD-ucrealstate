<?php

namespace Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class PermissionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $parentPermissions = [
            'Property',
        	'Client',
            'Office',
            'Note',
            'Administration',
            'Settings',
            'Client StoryBoard',
            'Client Note'
        ];

        $childPermissions=
            [
            	'Property' =>
                    array(
                        0 => 'Add Property',
                        1 => 'Edit Property',
                        2 => 'Show Property',
                        3 => 'Delete Property',
                        4 => 'Trashed Property'
                    ),

                'Client' =>
                    array(
                        0 => 'Add Client',
                        1 => 'Edit Client',
                        2 => 'Show Client',
                        3 => 'Delete Client',
                        4 => 'Trashed Client'
                    ),
                'Office'=>
                    array(
                        0 => 'Add Office',
                        1 => 'Edit Office',
                        2 => 'Show Office',
                        3 => 'Delete Office',
                        4 => 'Trashed Office'
                    ),
                'Note'=>
                    array(
                        0 => 'Note List'
                    ),
                'Administration'=>
                    array(
                        0 =>'Add Role',
                        1 =>'Edit Role',
                        2 =>'Show Role',
                        3 =>'Delete Role',
                        4 =>'Add User',
                        5 =>'Edit User',
                        6 =>'Show User',
                        7 =>'Delete User',
                        8 =>'Trashed User'     
                    ),
                'Settings'=>
                    array(
                        0 =>'Edit Settings'
                    ),         
                'Client StoryBoard'=>
                    array(
                        0 => 'Client Edit StoryBoard',
                        1 => 'Client Show StoryBoard'
                    ),
                'Client Note'=>
                    array(
                        0 =>'Client Add Note',
                        1 =>'Client Edit Note',
                        2 =>'Client Show Note',
                        3 =>'Client Delete Note',
                        4 =>'Client Trashed Note'
                    )    
            ];

        Permission::query()->delete();
        
        Role::updateOrCreate(['name'=>'Admin'],[
            'name'=>'Admin',
            'guard_name'=>'web'
        ]);

        foreach ($parentPermissions as $parentPermission) {
            $parentInsert = Permission::create([
                'name' => $parentPermission,
                'parent_id' => '',
                'guard_name' => 'web'
            ]);
            if (array_key_exists($parentPermission, $childPermissions)) {
                foreach ($childPermissions[$parentPermission] as $childPermission) {
                    $perm = Permission::create([
                        'name' => $childPermission,
                        'parent_id' => $parentInsert->id,
                        'guard_name' => 'web'
                    ]);

                    $perm->assignRole('Admin');
                }
            }
        }
    }
}
