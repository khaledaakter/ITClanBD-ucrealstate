<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Robiussani152\Settings\Models\Settings;

class SettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $settings=['title','logo','fabicon','login_image','default_bg','default_profile'];

        foreach($settings as $key=>$setting){
        	Settings::create([
        		'setting_key'=>$setting,
        		'setting_value'=>null
        	]);
        }
    }
}
