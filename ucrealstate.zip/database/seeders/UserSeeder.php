<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Traits\syncRoles;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user=User::whereEmail('admin@app.com')->first();
        if (isset($user)) {
        	User::whereEmail('admin@app.com')->update([
        		'first_name'=>'admin',
                'last_name'=>'admin',
                'display_name'=>'admin',
                'user_name'=>'admin-admin',
        		'email'=>'admin@app.com',
        		'password'=>Hash::make('password'),
        		'user_type'=>1
        	]);
            $user->syncRoles('Admin');
        }else{
        	$user=User::create([
        		'first_name'=>'admin',
                'last_name'=>'admin',
                'display_name'=>'admin',
                'user_name'=>'admin-admin',
                'email'=>'admin@app.com',
                'password'=>Hash::make('password'),
                'user_type'=>1
        	]);
            $user->syncRoles('Admin');
        }

        return 'success';
    }
}
